import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IUpdateAppsFromExcelFileWebPartProps {
    description: string;
}
export default class UpdateAppsFromExcelFileWebPart extends BaseClientSideWebPart<IUpdateAppsFromExcelFileWebPartProps> {
    onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}

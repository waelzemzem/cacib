/// <reference types="react" />
import * as React from 'react';
import { IUpdateAppsFromExcelFileProps } from './IUpdateAppsFromExcelFileProps';
export default class UpdateAppsFromExcelFile extends React.Component<IUpdateAppsFromExcelFileProps, {}> {
    constructor(props: IUpdateAppsFromExcelFileProps);
    render(): React.ReactElement<IUpdateAppsFromExcelFileProps>;
    mypnpcheck(): void;
}

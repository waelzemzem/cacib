export interface IUpdateAppsFromExcelFileProps {
    description: string;
}

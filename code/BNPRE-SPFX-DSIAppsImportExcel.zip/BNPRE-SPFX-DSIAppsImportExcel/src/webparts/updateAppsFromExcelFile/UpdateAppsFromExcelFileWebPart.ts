import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';

import * as strings from 'UpdateAppsFromExcelFileWebPartStrings';
import UpdateAppsFromExcelFile from './components/UpdateAppsFromExcelFile';
import { IUpdateAppsFromExcelFileProps } from './components/IUpdateAppsFromExcelFileProps';
import { sp } from '@pnp/sp';
import { setup as pnpSetup } from "@pnp/common";
import { override } from '@microsoft/decorators';
import { initializeIcons } from 'office-ui-fabric-react/lib/Icons';

export interface IUpdateAppsFromExcelFileWebPartProps {
  description: string;
}

export default class UpdateAppsFromExcelFileWebPart extends BaseClientSideWebPart<IUpdateAppsFromExcelFileWebPartProps> {

  @override
  public onInit(): Promise<void> {

      initializeIcons();
      return super.onInit().then(_ => {
        pnpSetup({
          spfxContext: this.context
        });
      });
    }



  public render(): void {
    sp.setup({  
      spfxContext: this.context  
  });

    const element: React.ReactElement<IUpdateAppsFromExcelFileProps > = React.createElement(
      UpdateAppsFromExcelFile,
      {
        description: this.properties.description
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}

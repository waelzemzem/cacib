/* tslint:disable */
require('./UpdateAppsFromExcelFile.module.css');
const styles = {
  updateAppsFromExcelFile: 'updateAppsFromExcelFile_ed484250',
  container: 'container_ed484250',
  row: 'row_ed484250',
  column: 'column_ed484250',
  'ms-Grid': 'ms-Grid_ed484250',
  title: 'title_ed484250',
  subTitle: 'subTitle_ed484250',
  description: 'description_ed484250',
  button: 'button_ed484250',
  label: 'label_ed484250',
};

export default styles;
/* tslint:enable */
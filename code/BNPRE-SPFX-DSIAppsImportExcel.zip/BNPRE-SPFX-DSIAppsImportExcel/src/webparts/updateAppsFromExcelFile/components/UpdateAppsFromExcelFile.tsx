import * as React from 'react';
import styles from './UpdateAppsFromExcelFile.module.scss';
import { IUpdateAppsFromExcelFileProps } from './IUpdateAppsFromExcelFileProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as XLSX from 'xlsx';
import { sp 
} from "@pnp/sp"; 


export default class UpdateAppsFromExcelFile extends React.Component < IUpdateAppsFromExcelFileProps, {} > {

constructor(props: IUpdateAppsFromExcelFileProps){
  super(props);
  this.mypnpcheck();
}
  public render(): React.ReactElement<IUpdateAppsFromExcelFileProps> {
    return(
      <div className = { styles.updateAppsFromExcelFile } >
          <h1> Hello Application </h1>
      </div >
    );
  }


  public mypnpcheck()  {  
    sp.web.getFileByServerRelativeUrl("/sites/DocsDSI/Shared%20Documents/Referentiel Cartographie Applicative WIP6.6.3_Sharepoint_20220329.xlsx")
    .getBuffer().then((buffer: ArrayBuffer) => {  
      var workbook = XLSX.read(buffer, {  
            type: "buffer"  
        });  
        var first_sheet_name = workbook.SheetNames[0];  
        var worksheet = workbook.Sheets[first_sheet_name];  
        var headers = {};  
        var data = [];  
        let z: any;  

        for (z in worksheet) {  
         
            if (z[0] === '!') continue;  
            var tt = 0;  
            for (var i = 0; i < z.length; i++) {  
                if (!isNaN(z[i])) {  
                    tt = i;  
                    break;  
                }  
            }  
            var col = z.substring(0, tt);  
            var row = parseInt(z.substring(tt));  
            var value = worksheet[z].v;  
           
            //store header names  
            if (row == 1 && value) {  
                headers[col] = value;  
                continue;  
            }  
            if (!data[row]) data[row] = {};  
            data[row][headers[col]] = value;  
        }  
    
         console.dir(data)  
        data.forEach(async element => {
          // console.log(element["ID"])
         // let val = element["ID"];
         const items: any[]= await sp.web.lists.getByTitle("Applications patrimony").items.filter(`IDApp eq '${element["ID"]}'`)[0].update({
          Title: "Updated Title",
        });

       
   
          console.dir(items); 
          
        });
    });  
}  
}

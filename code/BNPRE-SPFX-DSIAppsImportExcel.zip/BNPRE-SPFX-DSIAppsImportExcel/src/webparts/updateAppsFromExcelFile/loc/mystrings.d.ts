declare interface IUpdateAppsFromExcelFileWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'UpdateAppsFromExcelFileWebPartStrings' {
  const strings: IUpdateAppsFromExcelFileWebPartStrings;
  export = strings;
}

export default interface ISideNavProps {}

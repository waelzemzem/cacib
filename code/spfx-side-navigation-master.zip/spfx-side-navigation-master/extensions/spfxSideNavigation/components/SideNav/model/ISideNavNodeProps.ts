import ISideNavNode from "./ISideNavNode";

export default interface ISideNavNodeProps extends ISideNavNode {
}

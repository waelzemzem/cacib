export default interface ISideNavNodeState {
    isOpened: boolean;
 }
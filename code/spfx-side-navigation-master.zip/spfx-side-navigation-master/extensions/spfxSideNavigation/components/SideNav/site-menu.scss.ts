/* tslint:disable */
require('./site-menu.css');

/* tslint:enable */
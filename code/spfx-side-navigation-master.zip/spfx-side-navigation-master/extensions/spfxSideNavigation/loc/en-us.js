define([], function() {
  return {
    "Title": "SpfxSideNavigationApplicationCustomizer"
  }
});
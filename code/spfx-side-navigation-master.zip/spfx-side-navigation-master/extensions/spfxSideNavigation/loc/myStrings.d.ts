declare interface ISpfxSideNavigationApplicationCustomizerStrings {
  Title: string;
}

declare module 'SpfxSideNavigationApplicationCustomizerStrings' {
  const strings: ISpfxSideNavigationApplicationCustomizerStrings;
  export = strings;
}

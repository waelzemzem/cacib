﻿using BNPPI.RE.Audit.Platform.Constants;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.Audit.Platform.TimerJob
{
    class AuditFarmCsvTimerJob : SPJobDefinition
    {
        public const string JOB_NAME = "AuditExportCSVallSitesCollSubSitesAutorizationsToCSVTimerJob";

        public AuditFarmCsvTimerJob() : base() { }

        //public AuditFarmCsvTimerJob(string jobName, SPService service) : base(JOB_NAME, service, null, SPJobLockType.None)
        //{
        //    // Assign the title
        //    this.Title = "Audit - Export all sites coll, sub-sites,autorizations, Quota to CSV file Timer JOB";
        //}
        //public AuditFarmCsvTimerJob(SPWebApplication webApp): base(JOB_NAME, webApp, null, SPJobLockType.ContentDatabase)
        //{
        //    // Assign the title

        //}

        public AuditFarmCsvTimerJob(string jobName, SPService service) : base(JOB_NAME, service, null, SPJobLockType.None)
        {
            // Assign the title
            this.Title = "Audit - Export all sites coll, sub-sites,autorizations, Quota to CSV file Timer JOB";
        }


        public AuditFarmCsvTimerJob(string jobName, SPWebApplication webapp) : base(JOB_NAME, webapp, null, SPJobLockType.ContentDatabase)
        {
            this.Title = "Audit - Export all sites coll, sub-sites,autorizations, Quota to CSV file Timer JOB";
        }


        public override void Execute(Guid targetInstanceId)
        {
            //base.Execute(targetInstanceId);


            try
            {
                SPWebApplication webApplication = this.Parent as SPWebApplication;
                ASCIIEncoding enc = new ASCIIEncoding();

                using (SPSite site = new SPSite(Sites.SITE_URL_DEV))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPFile spfile = currentWeb.GetFile(Sites.LIB_URL_DEV);

                        foreach (SPSite sc in webApplication.Sites)
                        {
                            foreach (SPWeb web in sc.AllWebs)
                            {
                                foreach (SPGroup group in web.Groups)
                                {
                                    foreach (SPRole role in web.Roles)
                                    {
                                        foreach (SPUser userG in group.Users)
                                        {
                                            var newLine = string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8}", sc.Url, "", web.Url, web.Title, web.LastItemModifiedDate, group.Name, role.ID, userG.Name);
                                            BindingtoCSV(spfile, enc, newLine);
                                        }
                                    }
                                }
                            }
                        }


                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Audit - Export all sites coll, sub site , groups SharePoint ,Quota to CSV file Timer Job", ex.Message);
            }
        }


        /// <summary>
        /// Loger le traitement dans un fichier txt
        /// </summary>
        /// <param name="logFile"></param>
        /// <param name="enc"></param>
        /// <param name="logMessage"></param>
        private void BindingtoCSV(SPFile logFile, ASCIIEncoding enc, string logMessage)
        {
            try
            {
                byte[] fileContentsStart = logFile.OpenBinary();
                string newContentsStartFormat = enc.GetString(fileContentsStart) + Environment.NewLine + logMessage;
                logFile.SaveBinary(enc.GetBytes(newContentsStartFormat));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

}

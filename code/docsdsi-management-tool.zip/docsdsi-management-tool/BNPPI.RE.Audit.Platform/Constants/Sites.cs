﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.Audit.Platform.Constants
{
    public static class Sites
    {
        public const string SITE_URL_DEV = "http://pars402i2701.bnppi.priv/sites/DocsDSI";
        public const string LIB_URL_DEV = "http://pars402i2701.bnppi.priv/sites/DocsDSI/Shared%20Documents/SharePoint_Audit.csv";


        public const string SITE_URL_UAT = "https://sharepoint-uat-realestate.staging.echonet/sites/DocsDSI";
        public const string LIB_URL_UAT = "http://pars402i2701.bnppi.priv/sites/DocsDSI/Shared%20Documents/SharePoint_Audit.csv";


        public const string SITE__URL_STAGING = "https://sharepoint-realestate.staging.echonet/sites/DocsDSI";
        public const string LIB_URL_STAGING = "http://pars402i2701.bnppi.priv/sites/DocsDSI/Shared%20Documents/SharePoint_Audit.csv";


        public const string SITE__URL_PROD = "https://sharepoint-realestate.is.echonet/sites/docsdsi";
        public const string LIB_URL_PROD = "http://pars402i2701.bnppi.priv/sites/DocsDSI/Shared%20Documents/SharePoint_Audit.csv";

    }
}

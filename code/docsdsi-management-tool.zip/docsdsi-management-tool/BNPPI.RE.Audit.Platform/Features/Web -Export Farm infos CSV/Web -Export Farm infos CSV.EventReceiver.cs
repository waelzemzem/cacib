using BNPPI.RE.Audit.Platform.TimerJob;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace BNPPI.RE.Audit.Platform.Features.Web__Export_Farm_infos_CSV
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("3e6ddd5c-0e51-4910-a101-6e3144ed4f46")]
    public class Web__Export_Farm_infos_CSVEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        const string JOB_NAME = "AuditExportCSVallSitesCollSubSitesAutorizationsToCSVTimerJob";
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    SPWebApplication parentWebApp = (SPWebApplication)properties.Feature.Parent;
                    SPSite site = properties.Feature.Parent as SPSite;
                    DeleteExistingJob(JOB_NAME, parentWebApp);
                    CreateJob(parentWebApp);
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }



            //// create the timer job when the feature is activated
            //SPWebApplication webApp = properties.Feature.Parent as SPWebApplication; // get the web application reference

            //// Delete the job, If its already created
            //foreach (SPJobDefinition job in webApp.JobDefinitions)
            //    if (job.Name == JOB_NAME)
            //    {
            //        job.Delete();
            //    }

            ////Create the timer job by creating the instance of the class we have created
            //AuditFarmCsvTimerJob customTimerJob = new AuditFarmCsvTimerJob(webApp);

            //// Create a schedule interval for timer job
            //SPMinuteSchedule customSchedule = new SPMinuteSchedule();  // You can create Hourly, Daily,  Weekly schedules as well
            //customSchedule.BeginSecond = 0;
            //customSchedule.EndSecond = 59;
            //customSchedule.Interval = 15;  //Run every 15 minutes

            //// assign the schedule to the timer job
            //customTimerJob.Schedule = customSchedule;
            //customTimerJob.Update();
        }


        private bool CreateJob(SPWebApplication site)
        {
            bool jobCreated = false;
            try
            {
                AuditFarmCsvTimerJob job = new AuditFarmCsvTimerJob(JOB_NAME, site);
                SPMinuteSchedule schedule = new SPMinuteSchedule();
                schedule.BeginSecond = 0;
                schedule.EndSecond = 59;
                schedule.Interval = 5;
                job.Schedule = schedule;
                job.Update();
            }
            catch (Exception)
            {
                return jobCreated;
            }
            return jobCreated;
        }
        public bool DeleteExistingJob(string jobName, SPWebApplication site)
        {
            bool jobDeleted = false;
            try
            {
                foreach (SPJobDefinition job in site.JobDefinitions)
                {
                    if (job.Name == jobName)
                    {
                        job.Delete();
                        jobDeleted = true;
                    }
                }
            }
            catch (Exception)
            {
                return jobDeleted;
            }
            return jobDeleted;
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {

            lock (this)
            {
                try
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate ()
                    {
                        SPWebApplication parentWebApp = (SPWebApplication)properties.Feature.Parent;
                        DeleteExistingJob(JOB_NAME, parentWebApp);
                    });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }



        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

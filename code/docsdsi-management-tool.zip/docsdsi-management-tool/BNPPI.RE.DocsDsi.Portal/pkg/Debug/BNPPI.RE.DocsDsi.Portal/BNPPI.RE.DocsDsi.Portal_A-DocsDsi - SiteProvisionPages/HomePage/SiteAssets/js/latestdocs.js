﻿
var DocsData;
var DocsDsi = function () {
    this.Init();
    this.InitEvent();
};

DocsDsi.prototype.Init = function () {
}

DocsDsi.prototype.InitEvent = function () {

}

var ViewModel = function () {
    var self = this;
    self.ID = ko.observable();
    self.FileLeafRef = ko.observable();
    self.Created = ko.observable();
    self.Author = ko.observable();
    self.Modified = ko.observable();
    self.Editor = ko.observable();
    self.FileRef = ko.observable();
    self.ProjectName = ko.observable();
    self.LibraryName = ko.observable();
    self.ParentFolder = ko.observable();
    self.IconUrl = ko.observable();
};
var docsDSIViewModel;
function getTheLatestUploadedDocuments(NumberOfDays) {
    var serviceUri = _spPageContextInfo.webAbsoluteUrl + "/_vti_bin/DocsDsi/HomeService.svc/GetTheLatestUploadedDocumentsHomePage";

    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: serviceUri + "/" + NumberOfDays,
        dataType: "json",
        success:
            function (response) {
                BindValuesData(response);
                ko.applyBindings(docsDSIViewModel);
                $('#message').html("<a href=" + serviceUri + ">" + serviceUri + "</a>");
            },
        error:
            function (err) {
                alert(err);
            }
    });
}
function BindValuesData(response) {
    var data = JSON.parse(response.GetTheLatestUploadedDocumentsHomePageResult);
    docsDSIViewModel = new ViewModel();
    if (data != null) {
        DocsData = data;
        if (data.length > 0) {
            ko.utils.arrayForEach(data, function (item) {
                if (item != "") {

                    if (item.FileLeafRef != null) {
                        docsDSIViewModel.FileLeafRef(item.FileLeafRef);
                    } else {
                        docsDSIViewModel.FileLeafRef(null);
                    }


                    if (item.Created != null) {
                        docsDSIViewModel.Created(item.Created);
                    } else {
                        docsDSIViewModel.Created(null);
                    }
                    if (item.Author != null) {
                        docsDSIViewModel.Author(item.Author);
                    } else {
                        docsDSIViewModel.Author(null);
                    }

                    if (item.Modified != null) {
                        docsDSIViewModel.Modified(item.Modified);
                    } else {
                        docsDSIViewModel.Modified(null);
                    }
                    if (item.Editor != null) {
                        docsDSIViewModel.Editor(item.Editor);
                    } else {
                        docsDSIViewModel.Editor(null);
                    }

                    if (item.FileRef != null) {
                        docsDSIViewModel.FileRef(item.FileRef);
                    } else {
                        docsDSIViewModel.FileRef(null);
                    }

                    if (item.ProjectName != null) {
                        docsDSIViewModel.ProjectName(item.ProjectName);
                    } else {
                        docsDSIViewModel.ProjectName(null);
                    }

                    if (item.LibraryName != null) {
                        docsDSIViewModel.LibraryName(item.LibraryName);
                    } else {
                        docsDSIViewModel.LibraryName(null);
                    }

                    if (item.ParentFolder != null) {
                        docsDSIViewModel.ParentFolder(item.ParentFolder);
                    } else {
                        docsDSIViewModel.ParentFolder(null);
                    }
                    if (item.IconUrl != null) {
                        docsDSIViewModel.IconUrl(item.IconUrl);
                    } else {
                        docsDSIViewModel.IconUrl(null);
                    }
                }
            });
        }
    }
}

$(document).ready(function () {
    var myET = $('.demo1').easyTicker({
        direction: 'up',
        easing: 'swing',
        speed: 'slow',
        interval: 2000,
        height: 'auto',
        visible: 2,
        mousePause: true,
        controls: {
            up: '.up',
            down: '.down',
            toggle: '.toggle',
            stopText: 'Stop !!!'
        }
    }).data('easyTicker');
    getTheLatestUploadedDocuments(10);
});



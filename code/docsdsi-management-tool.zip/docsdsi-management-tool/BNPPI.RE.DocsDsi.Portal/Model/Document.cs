﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Model
{
    [DataContract]
    public class Document
    {
        [DataMember]
        public string ID { get; set; }

        [DataMember]
        public string FileLeafRef { get; set; }

        [DataMember]
        public string Created { get; set; }

        [DataMember]
        public string CreatedTitle { get; set; }

        [DataMember]
        public string Author { get; set; }
       
        [DataMember]
        public string AuthorTitle { get; set; }

        [DataMember]
        public string Modified { get; set; }
        [DataMember]
        public string ModifiedTitle { get; set; }


        [DataMember]
        public string Editor { get; set; }
        [DataMember]
        public string EditorTitle { get; set; }

        [DataMember]
        public string FileRef { get; set; }

        [DataMember]
        public string ProjectName { get; set; }

        [DataMember]
        public string LibraryName { get; set; }

        [DataMember]
        public string ParentFolder { get; set; }

        [DataMember]
        public string IconUrl { get; set; }
        
    }
}

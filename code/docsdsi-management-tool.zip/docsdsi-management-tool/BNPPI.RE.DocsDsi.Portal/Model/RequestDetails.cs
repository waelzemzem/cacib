﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Model
{
    public class RequestDetails
    {
        public string InternalNameLibraries{ get; set; }
    }
}

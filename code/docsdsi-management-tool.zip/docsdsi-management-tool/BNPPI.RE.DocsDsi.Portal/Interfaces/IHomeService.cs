﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Runtime.Serialization;
using BNPPI.RE.DocsDsi.Portal.Model;

namespace BNPPI.RE.DocsDsi.Portal
{
    [ServiceContract]
    interface IHomeService
    {
        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped, ResponseFormat = WebMessageFormat.Json, UriTemplate = "/getTime")]
        string getTime();

        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped, ResponseFormat = WebMessageFormat.Json, UriTemplate = "/GetLatestUploadedDocsByLibraryInternalNameAndNumberOfDays/{libraryInternalName}/{NumberOfDays}")]
        string GetLatestUploadedDocsByLibraryInternalNameAndNumberOfDays(string libraryInternalName, string NumberOfDays);

        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped, ResponseFormat = WebMessageFormat.Json, UriTemplate = "/GetTheLatestUploadedDocumentsHomePage/{NumberOfDays}")]
        string GetTheLatestUploadedDocumentsHomePage(string NumberOfDays);

        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped, ResponseFormat = WebMessageFormat.Json, UriTemplate = "/GetTheLatestUploadedDocumentsProjects/{NumberOfDays}")]
        string GetTheLatestUploadedDocumentsProjects(string NumberOfDays);
    }
}

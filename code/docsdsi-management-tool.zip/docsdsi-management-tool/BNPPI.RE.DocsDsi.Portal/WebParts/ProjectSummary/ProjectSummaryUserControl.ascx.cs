﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using System.Collections.Generic;
using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using BNPPI.RE.DocsDsi.Portal.Localization;
using Microsoft.SharePoint.Utilities;
using BNPPI.RE.DocsDsi.Portal.Model;
using BNPPI.RE.DocsDsi.Portal.DataManagers;
using System.Linq;
using System.Globalization;

namespace BNPPI.RE.DocsDsi.Portal.WebParts.ProjectSummary
{
    public partial class ProjectSummaryUserControl : UserControl
    {
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            listFieldIterator.Visible = false;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            this.btnCancel.Click += btnCancel_Click;

            btnCancel.Text = Localization.Localization.Current.GetResource("ApplicationPage_ButtonCancelValue", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
            btnGenerateDocuments.Text = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_btnGenerateDocumentsValue", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
            LiteralProjectLibrariesTitle.Text = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_LiteralProjectLibrariesTitle", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);


            if (!Page.IsPostBack)
            {
                try
                {
                    SPWeb web = SPContext.Current.Web;
                    string colTitleNameStr = Localization.Localization.Current.GetResource("ApplicationPage_DisplayAppLibraryTitle", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
                    string colTitleDescriptionStr = Localization.Localization.Current.GetResource("ApplicationPage_DisplayAppLibraryDescription", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);

                    //Primary Cards
                    SPDocumentLibrary projectsOtherDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_OTHER_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsBalanceSheetDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_BALANCE_SHEET_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsC2IDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_C2I_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsCMATDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_CMAT_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsCOMITDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_COMIT_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsCvitDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_CVIT_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsDeliveryCardsDocsList = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_DELIVERY_CARDS_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsDemandsDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_DEMANDS_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsIRPPDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_IRPP_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsMinutesOfMeetingDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_MINUTES_OF_METTING_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsReleaseNotesDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_RELEASE_NOTES_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsSpecificationsDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_SPECIFICATION_DOCS_NAME)) as SPDocumentLibrary;
                    SPDocumentLibrary projectsTestsBookDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_TEST_BOOK_DOCS_NAME)) as SPDocumentLibrary;
                
                    SPDocumentLibrary projectsCopilDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_COPIL_DOCS_NAME)) as SPDocumentLibrary;
                    // SVC
                    SPDocumentLibrary projectsSVCDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_SVC_DOCS_NAME)) as SPDocumentLibrary;


                    // ID CARD
                    SPDocumentLibrary projectsIDCardDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_IDCARD_DOCS_NAME)) as SPDocumentLibrary;


                    int itemID = (int)listFieldIterator.ListItem[Fields.SP_FIELDS_ID_INTERNALNAME];

                    string urlIDCard = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_IDCARD_INTERNALNAME].ToString())).Url;


                    string urlCOPIL = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_COPIL_INTERNALNAME].ToString())).Url;
                  
                    string url4 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_COMIT_INTERNALNAME].ToString())).Url;
                    string urlSVC = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_SVC_INTERNALNAME].ToString())).Url;


                    string url3 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_CMAT_INTERNALNAME].ToString())).Url;
                    string url5 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_CVIT_INTERNALNAME].ToString())).Url;
                    string url2 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_C2I_INTERNALNAME].ToString())).Url;
                    string url8 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_IRPP_INTERNALNAME].ToString())).Url;
                    string url7 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_DEMANDS_INTERNALNAME].ToString())).Url;
                    string url6 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_DELIVERY_CARDS_INTERNALNAME].ToString())).Url;
                    string url12 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_SPECIFICATION_INTERNALNAME].ToString())).Url;
                    string url11 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_RELEASE_NOTES_INTERNALNAME].ToString())).Url;
                    string url13 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_TESTS_BOOK_INTERNALNAME].ToString())).Url;
                    string url9 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_MINUTES_INTERNALNAME].ToString())).Url;
                    string urlOtherDocs = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_OtherDOCS_INTERNALNAME].ToString())).Url;

                    string url1 = new SPFieldUrlValue((listFieldIterator.ListItem[Fields.PROJET_FIELDS_BALANCESHEET_INTERNALNAME].ToString())).Url;
                    List<ProjectLibraries> RunLibrariesList = new List<ProjectLibraries>();
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_OTHER_DOCS_NAME, LibraryName = projectsOtherDocsLibrary.Title, LibraryDescription = projectsOtherDocsLibrary.Description, LinkProjectDocSetToLibrary = urlOtherDocs });
                    // ID CArd
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_IDCARD_DOCS_NAME, LibraryName = projectsIDCardDocsLibrary.Title, LibraryDescription = projectsIDCardDocsLibrary.Description, LinkProjectDocSetToLibrary = urlIDCard });

                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_COPIL_DOCS_NAME, LibraryName = projectsCopilDocsLibrary.Title, LibraryDescription = projectsCopilDocsLibrary.Description, LinkProjectDocSetToLibrary = urlCOPIL });

                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_COMIT_DOCS_NAME, LibraryName = projectsCOMITDocsLibrary.Title, LibraryDescription = projectsCOMITDocsLibrary.Description, LinkProjectDocSetToLibrary = url4 });

                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_SVC_DOCS_NAME, LibraryName = projectsSVCDocsLibrary.Title, LibraryDescription = projectsSVCDocsLibrary.Description, LinkProjectDocSetToLibrary = urlSVC });


                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_CMAT_DOCS_NAME, LibraryName = projectsCMATDocsLibrary.Title, LibraryDescription = projectsCMATDocsLibrary.Description, LinkProjectDocSetToLibrary = url3 });
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_CVIT_DOCS_NAME, LibraryName = projectsCvitDocsLibrary.Title, LibraryDescription = projectsCvitDocsLibrary.Description, LinkProjectDocSetToLibrary = url5 });
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_C2I_DOCS_NAME, LibraryName = projectsC2IDocsLibrary.Title, LibraryDescription = projectsC2IDocsLibrary.Description, LinkProjectDocSetToLibrary = url2 });
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_IRPP_DOCS_NAME, LibraryName = projectsIRPPDocsLibrary.Title, LibraryDescription = projectsIRPPDocsLibrary.Description, LinkProjectDocSetToLibrary = url8 });
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_DEMANDS_DOCS_NAME, LibraryName = projectsDemandsDocsLibrary.Title, LibraryDescription = projectsDemandsDocsLibrary.Description, LinkProjectDocSetToLibrary = url7 });
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_DELIVERY_CARDS_DOCS_NAME, LibraryName = projectsDeliveryCardsDocsList.Title, LibraryDescription = projectsDeliveryCardsDocsList.Description, LinkProjectDocSetToLibrary = url6 });
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_SPECIFICATION_DOCS_NAME, LibraryName = projectsSpecificationsDocsLibrary.Title, LibraryDescription = projectsSpecificationsDocsLibrary.Description, LinkProjectDocSetToLibrary = url12 });
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_RELEASE_NOTES_DOCS_NAME, LibraryName = projectsReleaseNotesDocsLibrary.Title, LibraryDescription = projectsReleaseNotesDocsLibrary.Description, LinkProjectDocSetToLibrary = url11 });
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_TEST_BOOK_DOCS_NAME, LibraryName = projectsTestsBookDocsLibrary.Title, LibraryDescription = projectsTestsBookDocsLibrary.Description, LinkProjectDocSetToLibrary = url13 });
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_MINUTES_OF_METTING_DOCS_NAME, LibraryName = projectsMinutesOfMeetingDocsLibrary.Title, LibraryDescription = projectsMinutesOfMeetingDocsLibrary.Description, LinkProjectDocSetToLibrary = url9 });
                    RunLibrariesList.Add(new ProjectLibraries { LibraryInternalName = Lists.PROJECT_LIB_BALANCE_SHEET_DOCS_NAME, LibraryName = projectsBalanceSheetDocsLibrary.Title, LibraryDescription = projectsBalanceSheetDocsLibrary.Description, LinkProjectDocSetToLibrary = url1 });

                    rptApplicationsList.DataSource = RunLibrariesList;
                    rptApplicationsList.ItemDataBound += rptApplicationsList_ItemDataBound;
                    rptApplicationsList.DataBind();
                }
                catch (Exception ex)
                {
                    LogManager.LogError("Feature Web_SwapMasterpage : Error IN Create COMIT Docs Set - " + ex.ToString());
                }
            }
        }


        void btnCancel_Click(object sender, EventArgs e)
        {
            string sourceUrl = Request.QueryString["Source"];
            if (!string.IsNullOrEmpty(sourceUrl))
            {
                Response.Redirect(sourceUrl);
            }
            else
            {
                Response.Redirect(SPContext.Current.Web.Url + "/Lists/ProjectsList");
            }
          

        }

        void rptApplicationsList_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
        {
            if (e.Item.DataItem != null)
            {
            }
        }

        protected void chk_filter_Changed(object sender, EventArgs e)
        {
            bool isAllChecked = true;
            foreach (RepeaterItem item in rptApplicationsList.Items)
            {
                if (!(item.FindControl("checkboxId") as CheckBox).Checked)
                {
                    isAllChecked = false;
                    break;
                }
            }
            chkAll.Checked = isAllChecked;
        }

        protected void Check_UnCheckAll(object sender, EventArgs e)
        {
            foreach (RepeaterItem item in rptApplicationsList.Items)
            {
                (item.FindControl("checkboxId") as CheckBox).Checked = chkAll.Checked;
            }
        }

        protected void btnGenerateDocuments_Click(object sender, EventArgs e)
        {
            bool itemisselected = false;
            bool itemisNotselected = false;
            string itemTitle = listFieldIterator.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();

            List<Document> listOfDocumentsProjects = new List<Document>();


            foreach (RepeaterItem item in rptApplicationsList.Items)
            {
                HyperLink id = item.FindControl("LibraryName") as HyperLink;
                Label listInternalName = item.FindControl("lbl_LibraryInternalName") as Label;
                //No items found
                bool isChecked = ((item.FindControl("checkboxId") as CheckBox).Checked);
                if (isChecked)
                {
                    // Templates documents
                    List<Document> itemsDocuments = LibraryDataManager.getListDocumentsByIDandLibrary(listInternalName.Text, itemTitle);

                    foreach (Document itemDocs in itemsDocuments)
                    {
                        // Mettre à jour le nom d'affichage / à la langue
                        itemDocs.AuthorTitle = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_LiteralAuthorTitle", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
                        itemDocs.CreatedTitle = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_LiteralCreatedTitle", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
                        itemDocs.EditorTitle = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_LiteralEditorTitle", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
                        itemDocs.ModifiedTitle = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_LiteralModifiedTitle", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
                        itemDocs.FileRef = itemDocs.FileRef + "?web=1";
                        listOfDocumentsProjects.Add(itemDocs);
                    }
                    itemisNotselected = true;
                }
                else
                {
                    itemisselected = false;

                }

            }

            rpt_ListOfDocumentsProject.DataSource = listOfDocumentsProjects;
            rpt_ListOfDocumentsProject.ItemDataBound += rpt_ListOfDocumentsProject_ItemDataBound;
            rpt_ListOfDocumentsProject.DataBind();


            Control FooterTemplate = rpt_ListOfDocumentsProject.Controls[rpt_ListOfDocumentsProject.Controls.Count - 1].Controls[0];
         
            Label lblRepeaterEmptyData = FooterTemplate.FindControl("lblRepeaterEmptyData") as Label;
            lblRepeaterEmptyData.Text = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_lblRepeaterEmptyDataMessage", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);

            if (listOfDocumentsProjects.Count > 0)
            {
                FooterTemplate.Visible = false;
            }
            else
            {
                FooterTemplate.Visible = true;
            }
        
        }



        void rpt_ListOfDocumentsProject_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
        {
            if (e.Item.DataItem != null)
            {
                var literal = e.Item.FindControl("AuthorLiteral") as Literal;

            }
        }
    }
    public class ProjectLibraries
    {
        public string LibraryName { get; set; }
        public string LibraryInternalName { get; set; }
        public string LibraryDescription { get; set; }

        public string LinkProjectDocSetToLibrary { get; set; }
    }


}

﻿using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.DataManagers;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using BNPPI.RE.DocsDsi.Portal.Model;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BNPPI.RE.DocsDsi.Portal.WebParts.AppSummary
{
    public partial class AppSummaryUserControl : UserControl
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            //applicationID.ExcludeFields = "ID";
            //applicationID.ExcludeFields = "Title";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            btnCancel.Click += btnCancel_Click;
            btnUpdateFromExcel.Click += BtnUpdateFromExcel_Click;

            btnCancel.Text = Localization.Localization.Current.GetResource("ApplicationPage_ButtonCancelValue", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
            btnGenerateDocuments.Text = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_btnGenerateDocumentsValue", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
            LiteralProjectLibrariesTitle.Text = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_LiteralProjectLibrariesTitle", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
            LiteralProjectsFromApplication.Text = Localization.Localization.Current.GetResource("ApplicationPage_ApplicationSummary_LiteralProjectsFromApplication", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);

            if (!Page.IsPostBack)
            {
                try
                {
                    string colTitleNameStr = Localization.Localization.Current.GetResource("ApplicationPage_DisplayAppLibraryTitle", "BNPPI.RE.DocsDSI.portal", SPContext.Current.Web.Language);
                    string colTitleDescriptionStr = Localization.Localization.Current.GetResource("ApplicationPage_DisplayAppLibraryDescription", "BNPPI.RE.DocsDSI.portal", SPContext.Current.Web.Language);

                    string RunFileArchitectureSchemeListName = Localization.Localization.Current.GetResource("ListInstances_RunFileArchitectureSchemeListName", "BNPPI.RE.DocsDSI.portal", SPContext.Current.Web.Language);
                    string RunFileSchemeOfExploitationListName = Localization.Localization.Current.GetResource("ListInstances_RunFileSchemeOfExploitationListName", "BNPPI.RE.DocsDSI.portal", SPContext.Current.Web.Language);
                    string RunFileSchemeOfInstallationListName = Localization.Localization.Current.GetResource("ListInstances_RunFileSchemeOfInstallationListName", "BNPPI.RE.DocsDSI.portal", SPContext.Current.Web.Language);
                    string RunNonRegressionTestsBookListName = Localization.Localization.Current.GetResource("ListInstances_RunNonRegressionTestsBookListName", "BNPPI.RE.DocsDSI.portal", SPContext.Current.Web.Language);
                    string RunSanityCheckApplicationListName = Localization.Localization.Current.GetResource("ListInstances_RunSanityCheckApplicationListName", "BNPPI.RE.DocsDSI.portal", SPContext.Current.Web.Language);
                    string RunSecurityDocumentListName = Localization.Localization.Current.GetResource("ListInstances_RunSecurityDocumentListName", "BNPPI.RE.DocsDSI.portal", SPContext.Current.Web.Language);
                    string RunSupportDocumentationListName = Localization.Localization.Current.GetResource("ListInstances_RunSupportDocumentationListName", "BNPPI.RE.DocsDSI.portal", SPContext.Current.Web.Language);
                    string RunUserGuideListName = Localization.Localization.Current.GetResource("ListInstances_RunUserGuideListName", "BNPPI.RE.DocsDSI.portal", SPContext.Current.Web.Language);


                    SPDocumentLibrary RunFileArchitectureSchemeList = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, "RunFileArchitectureSchemeLibrary")) as SPDocumentLibrary;
                    SPDocumentLibrary RunFileSchemeOfExploitationList = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, "RunFileSchemeOfExploitationLibrary")) as SPDocumentLibrary;
                    SPDocumentLibrary RunFileSchemeOfInstallationList = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, "RunFileSchemeOfInstallationLibrary")) as SPDocumentLibrary;
                    SPDocumentLibrary RunNonRegressionTestsBookList = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, "RunNonRegressionTestsBookLibrary")) as SPDocumentLibrary;

                    SPDocumentLibrary RunSanityCheckApplicationList = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, "RunSanityCheckApplicationLibrary")) as SPDocumentLibrary;
                    SPDocumentLibrary RunSecurityDocumentList = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, "RunSecurityDocumentLibrary")) as SPDocumentLibrary;
                    SPDocumentLibrary RunSupportDocumentationList = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, "RunSupportDocumentationLibrary")) as SPDocumentLibrary;
                    SPDocumentLibrary RunUserGuideList = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, "RunUserGuideLibrary")) as SPDocumentLibrary;

                    // Autres 
                    SPDocumentLibrary RunOtherDocsLibraryList = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, "RunOtherDocsLibrary")) as SPDocumentLibrary;

                    SPWeb oWeb = SPContext.Current.Web;
                    lblApplicationName.Text = applicationID.ListItem["Title"].ToString();
                    int itemID = (int)applicationID.ListItem["ID"];

                    // Other
                    string urlRunOtherFile = "";
                    if (applicationID.ListItem["UrlRunOtherDocuments"] != null)
                    {
                        urlRunOtherFile = new SPFieldUrlValue((applicationID.ListItem["UrlRunOtherDocuments"].ToString())).Url;
                    }

                    string urlRunArchitectureSchemeFile = "";
                    if (applicationID.ListItem["UrlRunArchitectureSchemeFile"] != null)
                    {
                        urlRunArchitectureSchemeFile = new SPFieldUrlValue((applicationID.ListItem["UrlRunArchitectureSchemeFile"].ToString())).Url;
                    }

                    string urlRunSchemeOfExploitationFile = "";
                    if (applicationID.ListItem["UrlRunSchemeOfExploitationFile"] != null)
                    {
                        urlRunSchemeOfExploitationFile = new SPFieldUrlValue((applicationID.ListItem["UrlRunSchemeOfExploitationFile"].ToString())).Url;
                    }
                    string urlRunSchemeOfInstallationFile = "";
                    if (applicationID.ListItem["UrlRunSchemeOfInstallationFile"] != null)
                    {
                        urlRunSchemeOfInstallationFile = new SPFieldUrlValue((applicationID.ListItem["UrlRunSchemeOfInstallationFile"].ToString())).Url;
                    }
                    string urlRunNonRegressionTestsBookFile = "";
                    if (applicationID.ListItem["UrlRunNonRegressionTestsBookFile"] != null)
                    {
                        urlRunNonRegressionTestsBookFile = new SPFieldUrlValue((applicationID.ListItem["UrlRunNonRegressionTestsBookFile"].ToString())).Url;
                    }

                    string urlRunSanityCheckApplicationFile = "";
                    if (applicationID.ListItem["UrlRunSanityCheckApplicationFile"] != null)
                    {
                        urlRunSanityCheckApplicationFile = new SPFieldUrlValue((applicationID.ListItem["UrlRunSanityCheckApplicationFile"].ToString())).Url;
                    }

                    string urlRunSecurityDocumentFile = "";
                    if (applicationID.ListItem["UrlRunSecurityDocumentFile"] != null)
                    {
                        urlRunSecurityDocumentFile = new SPFieldUrlValue((applicationID.ListItem["UrlRunSecurityDocumentFile"].ToString())).Url;
                    }

                    string urlRunSupportDocumentationFile = "";
                    if (applicationID.ListItem["UrlRunSupportDocumentationFile"] != null)
                    {
                        urlRunSupportDocumentationFile = new SPFieldUrlValue((applicationID.ListItem["UrlRunSupportDocumentationFile"].ToString())).Url;
                    }


                    string urlRunUserGuideFile = "";

                    if (applicationID.ListItem["UrlRunUserGuideFile"] != null)
                    {
                        urlRunUserGuideFile = new SPFieldUrlValue((applicationID.ListItem["UrlRunUserGuideFile"].ToString())).Url;
                    }



                    List<RunLibraries> RunLibrariesList = new List<RunLibraries>();
                    // Other
                    RunLibrariesList.Add(new RunLibraries { LibraryInternalName = Lists.RUN_LIB_OTHER_DOCS_NAME, LibraryName = RunOtherDocsLibraryList.Title, LibraryDescription = RunOtherDocsLibraryList.Description, LinkApplicationDocSet = urlRunOtherFile });


                    RunLibrariesList.Add(new RunLibraries { LibraryInternalName = Lists.RUN_LIB_FILE_ARCHITECTURE_SCHEMA_DOCS_NAME, LibraryName = RunFileArchitectureSchemeList.Title, LibraryDescription = RunFileArchitectureSchemeList.Description, LinkApplicationDocSet = urlRunArchitectureSchemeFile });
                    RunLibrariesList.Add(new RunLibraries { LibraryInternalName = Lists.RUN_LIB_FILE_SCHEMA_OF_EXPLOITATION_DOCS_NAME, LibraryName = RunFileSchemeOfExploitationList.Title, LibraryDescription = RunFileSchemeOfExploitationList.Description, LinkApplicationDocSet = urlRunSchemeOfExploitationFile });
                    RunLibrariesList.Add(new RunLibraries { LibraryInternalName = Lists.RUN_LIB_FILE_SCHEMA_OF_INSTALATION_DOCS_NAME, LibraryName = RunFileSchemeOfInstallationList.Title, LibraryDescription = RunFileSchemeOfInstallationList.Description, LinkApplicationDocSet = urlRunSchemeOfInstallationFile });
                    RunLibrariesList.Add(new RunLibraries { LibraryInternalName = Lists.RUN_LIB_NON_REGRESSION_TESTS_BOOK_DOCS_NAME, LibraryName = RunNonRegressionTestsBookList.Title, LibraryDescription = RunNonRegressionTestsBookList.Description, LinkApplicationDocSet = urlRunNonRegressionTestsBookFile });

                    RunLibrariesList.Add(new RunLibraries { LibraryInternalName = Lists.RUN_LIB_SANITY_CHECK_APPLICATION_DOCS_NAME, LibraryName = RunSanityCheckApplicationList.Title, LibraryDescription = RunSanityCheckApplicationList.Description, LinkApplicationDocSet = urlRunSanityCheckApplicationFile });
                    RunLibrariesList.Add(new RunLibraries { LibraryInternalName = Lists.RUN_LIB_SECURITY_DOCS_NAME, LibraryName = RunSecurityDocumentList.Title, LibraryDescription = RunSecurityDocumentList.Description, LinkApplicationDocSet = urlRunSecurityDocumentFile });
                    RunLibrariesList.Add(new RunLibraries { LibraryInternalName = Lists.RUN_LIB_SUPPORT_DOCS_NAME, LibraryName = RunSupportDocumentationList.Title, LibraryDescription = RunSupportDocumentationList.Description, LinkApplicationDocSet = urlRunSupportDocumentationFile });
                    RunLibrariesList.Add(new RunLibraries { LibraryInternalName = Lists.RUN_LIB_USER_GUIDE_DOCS_NAME, LibraryName = RunUserGuideList.Title, LibraryDescription = RunUserGuideList.Description, LinkApplicationDocSet = urlRunUserGuideFile });

                    rptApplicationsList.DataSource = RunLibrariesList;
                    rptApplicationsList.ItemDataBound += rptApplicationsList_ItemDataBound;
                    rptApplicationsList.DataBind();

                    // Get List of projects
                    SPList listProjects = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, "Lists/ProjectsList"));
                    SPQuery qry = new SPQuery();
                    qry.Query =
                    String.Format(@"<Where>
                              <Eq>
                                 <FieldRef Name='RelatedApplications' LookupId='True' />
                                 <Value Type='LookupMulti'>{0}</Value>
                              </Eq>
                           </Where>
                           <OrderBy>
                              <FieldRef Name='Title' />
                           </OrderBy>", applicationID.ListItem["ID"]);
                    qry.ViewFields = @"<FieldRef Name='LinkTitle' />
                                        <FieldRef Name='LinkTitleNoMenu' /> 
                                        <FieldRef Name='BusinessLineAndFunction' />
                                        <FieldRef Name='CountriesConcerned' />
                                        <FieldRef Name='ProjectStatus' />
                                        <FieldRef Name='ToContact' />";
                    SPListItemCollection listItems = listProjects.GetItems(qry);

                    List<ProjectsInApps> listprj = new List<ProjectsInApps>();
                    foreach (SPListItem oListItem in listItems)
                    {
                        ProjectsInApps itemDocs = new ProjectsInApps();
                        itemDocs.ProjectName = oListItem["Title"].ToString();
                        itemDocs.ProjectLink = listProjects.DefaultDisplayFormUrl + "?ID=" + oListItem.ID;
                        listprj.Add(itemDocs);
                    }
                    RepeaterfProjectsFromApplication.DataSource = listprj;
                    RepeaterfProjectsFromApplication.DataBind();
                }
                catch (Exception ex)
                {
                    LogManager.LogError("Feature Web_SwapMasterpage : Error IN Create COMIT Docs Set - " + ex.ToString());
                }
            }
        }

        /// <summary>
        /// Button to import csv file ref apply to application list
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnUpdateFromExcel_Click(object sender, EventArgs e)
        {
            insertOrUpdateAppsFromCsv();
            string parseCellValue = string.Empty;
            SPFile file = SPContext.Current.Web.GetFile("http://pars402i2701.bnppi.priv/sites/DocsDSI/Shared%20Documents/Sharepoint_20220329.csv");
            using (Stream dataStream = file.OpenBinaryStream())
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void insertOrUpdateAppsFromCsv()
        {
            char[] splitter = { ';' };
            SPFile spfile = SPContext.Current.Web.GetFile("http://pars402i2701.bnppi.priv/sites/DocsDSI/Shared%20Documents/Sharepoint_20220329.csv");
            if (spfile.Exists)
            {
                using (StreamReader sr = new StreamReader(spfile.OpenBinaryStream()))
                {
                    string currentLine;
                    while ((currentLine = sr.ReadLine()) != null)
                    {
                        String[] Array = currentLine.ToString().Split(splitter);
                        try
                        {
                            SPList myList = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, "Lists/AppsList"));


                            #region Data CSV
                            // ID // 9790;
                            // Application Name;// ABC ITA;
                            // Description; // Vendor management. Hosting in SaaS;
                            // Production version; // ;
                            // Internet - Facing;// Yes;
                            // Contains Personal Data; // Yes;
                            // Confidentiality; // 2 - Internal;
                            // Integrity; // 2 - Standard;
                            // Availability;// 1 - Minimum Service;
                            // Traceability; // 3 - Simple;
                            // RTO; // > 24h;
                            // RPO;// > 24h;
                            // Last CIAT Review;// 2020 - 05 - 07 00:00:00;
                            // Class; // Class 3;
                            // Authentification; // Internal - Application;
                            // Hosting Type;  // External;
                            // Cloud Service Model;// SaaS;
                            // Hosting Provider; // ;
                            // Indice app managée; // 0;
                            // Status; // Live;
                            // IT responsible // Italy 
                            #endregion

                            #region GetOrUpdate File


                            SPItem itemToUpdate = GetItemListIfExist(SPContext.Current.Web, "AppsList", "IDApp", Array[0]);
                            if (itemToUpdate != null)
                            {
                                itemToUpdate["Title"] = Array[1];
                                itemToUpdate["AppDescription"] = Array[2];
                                itemToUpdate["AppVersion"] = Array[3];
                                itemToUpdate["AppInternetFacing"] = Array[4];
                                itemToUpdate["AppPersonalData"] = Array[5];
                                itemToUpdate["AppConfidentiality"] = Array[6];
                                itemToUpdate["AppIntegrity"] = Array[7];
                                itemToUpdate["AppAvaibility"] = Array[8];
                                itemToUpdate["AppTraceability"] = Array[9];
                                itemToUpdate["AppRTO"] = Array[10];
                                itemToUpdate["AppRPO"] = Array[11];

                                DateTime newdate;
                                if (DateTime.TryParse(Array[12].ToString().Trim(), System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out newdate))
                                {
                                    itemToUpdate["AppLastCIAT"] = newdate;
                                }
                                itemToUpdate["AppClass"] = Array[13];
                                itemToUpdate["AppAuthentification"] = Array[14];
                                itemToUpdate["AppHostingType"] = Array[15];
                                itemToUpdate["AppCloudServiceModel"] = Array[16];
                                itemToUpdate["AppHostingProvider"] = Array[17];
                                itemToUpdate["AppManagedApplication"] = Array[18];
                                itemToUpdate["Status"] = Array[19];

                                int LookupIDitemToUpdate = GetLookupIDFromList(SPContext.Current.Web, "ParamITResponsibleList", "Title", Array[20]);
                                if (LookupIDitemToUpdate > 0)
                                {
                                    SPFieldLookupValue spflv = new SPFieldLookupValue(LookupIDitemToUpdate, Array[20]);
                                    itemToUpdate["AppITResponsible"] = spflv;
                                }
                                itemToUpdate.Update();

                            }
                            else
                            {
                                // Create the new application 
                                // Add new Item
                                SPItem item = myList.Items.Add();
                                item["IDApp"] = Array[0];
                                item["Title"] = Array[1];
                                item["AppDescription"] = Array[2];
                                item["AppVersion"] = Array[3];
                                item["AppInternetFacing"] = Array[4];
                                item["AppPersonalData"] = Array[5];
                                item["AppConfidentiality"] = Array[6];
                                item["AppIntegrity"] = Array[7];
                                item["AppAvaibility"] = Array[8];
                                item["AppTraceability"] = Array[9];
                                item["AppRTO"] = Array[10];
                                item["AppRPO"] = Array[11];

                                DateTime date;
                                if (DateTime.TryParse(Array[12].ToString().Trim(), System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date))
                                {
                                    item["AppLastCIAT"] = date;
                                }
                                item["AppClass"] = Array[13];
                                item["AppAuthentification"] = Array[14];
                                item["AppHostingType"] = Array[15];
                                item["AppCloudServiceModel"] = Array[16];
                                item["AppHostingProvider"] = Array[17];
                                item["AppManagedApplication"] = Array[18];
                                item["Status"] = Array[19];

                                int LookupID = GetLookupIDFromList(SPContext.Current.Web, "ParamITResponsibleList", "Title", Array[20]);
                                if (LookupID > 0)
                                {
                                    SPFieldLookupValue spflv = new SPFieldLookupValue(LookupID, Array[20]);
                                    item["AppITResponsible"] = spflv;
                                }

                                item.Update();
                            }

                            #endregion
                        }
                        catch (Exception ex)
                        {

                            // Log the Error un the output file
                            LogManager.LogError("Feature Web_SwapMasterpage : Upload csv- " + ex.Message.ToString());
                        }
                    }
                }
            }
        }

        private SPItem GetItemListIfExist(SPWeb web, string strListName, string idAppColumnName, string csvValue)
        {
            try
            {
                SPList list = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, "Lists/" + strListName));

                string strCAMLQuery = "<Where><Eq><FieldRef Name='" + idAppColumnName + "' /><Value Type='Text'>" + System.Web.HttpContext.Current.Server.HtmlEncode(csvValue) + "</Value></Eq></Where>";

                SPQuery query = new SPQuery();
                query.Query = strCAMLQuery;
                query.ViewFields = string.Concat(
                                        "<FieldRef Name='ID' />",
                                        "<FieldRef Name='" + idAppColumnName + "' />");


                SPListItemCollection items = list.GetItems(query);

                if (items.Count > 0)
                {
                    return items[0];
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static int GetLookupIDFromList(SPWeb web, string strListName, string strLookupColumnName, string strLookupValue)
        {
            try
            {
                SPList list = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, "Lists/" + strListName));

                string strCAMLQuery = "<Where><Eq><FieldRef Name='" + strLookupColumnName + "' /><Value Type='Text'>" + System.Web.HttpContext.Current.Server.HtmlEncode(strLookupValue) + "</Value></Eq></Where>";

                SPQuery query = new SPQuery();
                query.Query = strCAMLQuery;
                query.ViewFields = string.Concat(
                                        "<FieldRef Name='ID' />",
                                        "<FieldRef Name='" + strLookupColumnName + "' />");


                SPListItemCollection items = list.GetItems(query);

                if (items.Count > 0)
                {
                    int iRet = items[0].ID;
                    return iRet;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWeb"></param>
        /// <param name="applicationID"></param>
        /// <param name="runLibraryListstr"></param>
        /// <returns></returns>
        private string GetLinkRunLibrary(SPWeb oWeb, ListFieldIterator applicationID, string runLibraryListstr)
        {
            SPDocumentLibrary runLibraryList = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, runLibraryListstr)) as SPDocumentLibrary;
            string CONTRACT_TEAM_HISTORY_SP_QUERY = @"<View><Query><Where>
                                                                   <And>
                                                                        <Eq>
                                                                        <FieldRef Name='ContentType' LookupId='True' />
                                                                            <Value Type='Computed'>{0}</Value>
                                                                        </Eq>
                                                                       <Eq>
                                                                            <FieldRef Name='RelatedApplications' LookupId='True' />
                                                                            <Values>
                                                                                <Value Type='Lookup'>{1}</Value>
                                                                            </Values>
                                                                       </Eq>
                                                                    </And>
                                                               </Where></Query></View>";

            string fileURL = null;
            if (runLibraryList != null)
            {
                SPQuery spQueryRun = new SPQuery();
                spQueryRun.Query = string.Format(CONTRACT_TEAM_HISTORY_SP_QUERY, applicationID.ListItem["Title"], (int)applicationID.ListItem["ID"]);
                SPListItemCollection runUrlLIbrary = runLibraryList.GetItems(spQueryRun);

                SPListItem item = runUrlLIbrary[0];
                fileURL = SPUrlUtility.CombineUrl(oWeb.ServerRelativeUrl, item.Folder.Url);
            }
            return fileURL;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void rptFormalPropertiesList_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
        {

            if (e.Item.DataItem != null)
            {
                //VascoUserProfileProperty item = e.Item.DataItem as VascoUserProfileProperty;
                try
                {
                    //    if (item.PropertyType == "Person" || item.PropertyName == "PreferredName")
                    //    {
                    //        SPUser user = null;
                    //        if (item.PropertyName == "PreferredName")
                    //        {
                    //            user = GetSPUserFromLogin(accountname);
                    //        }
                    //        else if (item.PropertyType == "Person")
                    //        {
                    //            ((ProfilePropertyValue)e.Item.FindControl("ProfilePropertyValue")).Visible = false;
                    //            UserProfileManager upm = new UserProfileManager(SPServiceContext.GetContext(SPContext.Current.Site));
                    //            UserProfile up = upm.GetUserProfile(accountname);
                    //            UserProfileValueCollection userLogin = up[item.PropertyName];

                    //            if (userLogin.Value != null)
                    //            {
                    //                user = GetSPUserFromLogin(userLogin.Value.ToString());
                    //            }
                    //        }
                    //        ((HtmlGenericControl)e.Item.FindControl("ProfilePropertyContainer")).InnerHtml = GetPresenceHTMLFromUser(SPContext.Current.Site, user);
                    //    }
                }
                catch (Exception ex)
                {
                    LogManager.LogError(ex);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnCancel_Click(object sender, EventArgs e)
        {
            string sourceUrl = Request.QueryString["Source"];
            if (!string.IsNullOrEmpty(sourceUrl))
            {
                Response.Redirect(sourceUrl);
            }
            else
            {
                Response.Redirect(SPContext.Current.Web.Url + "/Lists/AppsList");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void rptApplicationsList_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
        {
            if (e.Item.DataItem != null)
            {
                //ApplicationLink row = e.Item.DataItem as ApplicationLink;
                //((HtmlInputCheckBox)e.Item.FindControl("ChkbxIsSelected")).Checked = row.Selected;
                //((HtmlGenericControl)e.Item.FindControl("ChkbxlblIsSelected")).Attributes["for"] = ((HtmlInputCheckBox)e.Item.FindControl("ChkbxIsSelected")).ClientID;

                //if (string.IsNullOrEmpty(row.PictoUrl))
                //    ((HtmlImage)e.Item.FindControl("imgAppPicto")).Visible = false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void chk_filter_Changed(object sender, EventArgs e)
        {
            bool isAllChecked = true;
            foreach (RepeaterItem item in rptApplicationsList.Items)
            {
                if (!(item.FindControl("checkboxId") as CheckBox).Checked)
                {
                    isAllChecked = false;
                    break;
                }
            }
            chkAll.Checked = isAllChecked;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Check_UnCheckAll(object sender, EventArgs e)
        {
            foreach (RepeaterItem item in rptApplicationsList.Items)
            {
                (item.FindControl("checkboxId") as CheckBox).Checked = chkAll.Checked;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnGenerateDocuments_Click(object sender, EventArgs e)
        {
            bool itemisselected = false;
            bool itemisNotselected = false;
            string itemTitle = applicationID.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();

            List<Document> listOfDocumentsProjects = new List<Document>();
            foreach (RepeaterItem item in rptApplicationsList.Items)
            {
                Label listInternalName = item.FindControl("lbl_LibraryInternalName") as Label;
                //No items found
                bool isChecked = ((item.FindControl("checkboxId") as CheckBox).Checked);
                if (isChecked)
                {
                    // Templates documents
                    List<Document> itemsDocuments = LibraryDataManager.getListDocumentsByIDandLibrary(listInternalName.Text, itemTitle);

                    foreach (Document itemDocs in itemsDocuments)
                    {
                        // Mettre à jour le nom d'affichage / à la langue
                        itemDocs.AuthorTitle = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_LiteralAuthorTitle", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
                        itemDocs.CreatedTitle = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_LiteralCreatedTitle", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
                        itemDocs.EditorTitle = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_LiteralEditorTitle", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
                        itemDocs.ModifiedTitle = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_LiteralModifiedTitle", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);
                        itemDocs.FileRef = itemDocs.FileRef + "?web=1";
                        listOfDocumentsProjects.Add(itemDocs);
                    }
                    itemisNotselected = true;
                }
                else
                {
                    itemisselected = false;
                }
            }

            rpt_ListOfDocumentsProject.DataSource = listOfDocumentsProjects;
            rpt_ListOfDocumentsProject.ItemDataBound += rpt_ListOfDocumentsProject_ItemDataBound;
            rpt_ListOfDocumentsProject.DataBind();

            System.Web.UI.Control FooterTemplate = rpt_ListOfDocumentsProject.Controls[rpt_ListOfDocumentsProject.Controls.Count - 1].Controls[0];
            Label lblRepeaterEmptyData = FooterTemplate.FindControl("lblRepeaterEmptyData") as Label;
            lblRepeaterEmptyData.Text = Localization.Localization.Current.GetResource("ApplicationPage_ProjectSummary_lblRepeaterEmptyDataMessage", "BNPPI.RE.DocsDSI.portal", (uint)CultureInfo.CurrentUICulture.LCID);

            if (listOfDocumentsProjects.Count > 0)
            {
                FooterTemplate.Visible = false;
            }
            else
            {
                FooterTemplate.Visible = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void rpt_ListOfDocumentsProject_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
        {
            if (e.Item.DataItem != null)
            {
                var literal = e.Item.FindControl("AuthorLiteral") as Literal;
            }
        }
    }

    public class RunLibraries
    {
        public string LibraryDescription { get; set; }
        public string LibraryName { get; set; }
        public string LibraryInternalName { get; set; }
        public string LinkApplicationDocSet { get; set; }
    }

    public class ProjectsInApps
    {
        public string ProjectName { get; set; }
        public string ProjectLink { get; set; }

    }
}
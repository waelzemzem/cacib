﻿using BNPPI.RE.DocsDsi.Portal.Model;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Utilities
{
    public class ConvertItem
    {
        public static Document ItemConfigToEntity(SPListItem item, string spLibraryTitle)
        {
            Document entite = new Document();
            //ID file
            if (item["ID"] != null)
            {
                entite.ID = item["ID"].ToString();
            }

            // FileLeafRef file name
            if (item["FileLeafRef"] != null)
            {
                entite.FileLeafRef = item["FileLeafRef"].ToString();
            }
            //Created
            if (item["Created"] != null)
            {
                
                entite.Created = item["Created"].ToString();
            }
            //Author
            if (item["Author"] != null)
            {
                entite.Author = (new SPFieldUserValue(SPContext.Current.Web, item["Author"].ToString()).User).Name;
            }
            //Modified
            if (item["Modified"] != null)
            {
                entite.Modified = item["Modified"].ToString();
            }
            //Editor
            if (item["Editor"] != null)
            {
                entite.Editor = (new SPFieldUserValue(SPContext.Current.Web, item["Editor"].ToString()).User).Name;
            }

            // FileRef (file URl)
            if (item["FileRef"] != null)
            {
                entite.FileRef = item["FileRef"].ToString();
            }

            // Library Title

            if (spLibraryTitle != null)
            {
                entite.LibraryName = spLibraryTitle;
            }
         

            // Parent folder 
            if (item.File.ParentFolder != null)
            {
                entite.ParentFolder = item.File.ParentFolder.ToString();
            }

            // UrlIcon folder 
            if (item.File.IconUrl != null)
            {
                if (item.File.IconUrl.ToString().Remove(0, 2) == "txt.gif")
                {
                    entite.IconUrl = "/_layouts/15/next/odspnext/odsp-media/images/itemtypes/48_2x/txt.png";
                }
                else
                {
                    entite.IconUrl = "/_layouts/15/next/odspnext/odsp-media/images/itemtypes/48_2x/" + item.File.IconUrl.ToString().Remove(0, 2);
                }
            }


            return entite;
        }
    }
}

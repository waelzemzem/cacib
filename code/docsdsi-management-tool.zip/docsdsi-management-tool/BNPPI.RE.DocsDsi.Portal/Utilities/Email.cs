﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Specialized;
using System.Net.Mail;

namespace BNPPI.RE.DocsDsi.Portal.Utilities
{
    public static class Email
    {
        public static void SendEmail(string to, string cc, string subject, string messageBody, SPWeb web)
        {
            StringDictionary messageHeaders = new StringDictionary();
            messageHeaders.Add("Content-type", "text/html");
            messageHeaders.Add("from", web.Site.WebApplication.OutboundMailReplyToAddress);
            messageHeaders.Add("To", to);
            messageHeaders.Add("Cc", cc);
            messageHeaders.Add("Subject", subject);
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPUtility.SendEmail(web, messageHeaders, messageBody);
            });
        }

        public static void SendMailV2(SPWeb web, SPUser recipient, string subject, string body)
        {
            try
            {
                string smtpAdress = Microsoft.SharePoint.Administration.SPAdministrationWebApplication.Local.OutboundMailServiceInstance.Server.Address;
                SmtpClient smtp = new SmtpClient(smtpAdress);
                string from = web.Site.WebApplication.OutboundMailReplyToAddress;
                MailMessage message = new MailMessage(from, recipient.Email, subject, body);
                message.IsBodyHtml = true;
               smtp.Send(message);

            }
            catch (Exception ex)
            {
                throw ex;

            }

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Entities
{
    public class ApplicationsFields
    {
        public int idItem { get; set; }
        public string Title { get; set; }
        public int UrlRunArchitectureSchemeFileDisplayName { get; set; }
        public int UrlRunSchemeOfExploitationFileDisplayName { get; set; }
        public int UrlRunSchemeOfInstallationFileDisplayName { get; set; }
        public int UrlRunSanityCheckApplicationFileDisplayName { get; set; }
        public int UrlRunSupportDocumentationFileDisplayName { get; set; }
        public int UrlRunUserGuideFileDisplayName { get; set; }
        public int UrlRunSecurityDocumentFileDisplayName { get; set; }
        public int UrlRunNonRegressionTestsBookFileDisplayName { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Entities
{
    public class EmailTemplateDocsDsi
    {
        public string MailSubject;
        public string MailBody;
        public DateTime FirstReminderDate;
        public DateTime SecondReminderDate;

    }
}

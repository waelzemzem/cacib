﻿using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.DataManagers;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using BNPPI.RE.DocsDsi.Portal.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Activation;
using System.Web.Script.Serialization;

namespace BNPPI.RE.DocsDsi.Portal
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class HomeService : IHomeService
    {
        // http://pars402i2701.bnppi.priv/_vti_bin/DocsDsi/HomeService.svc/getTime
        /// <summary>
        /// Get time (test)
        /// </summary>
        /// <returns></returns>
        public string getTime()
        {
            return DateTime.Now.ToLongDateString();
        }


        #region Tests
        /* http://pars402i2701.bnppi.priv/sites/DsiDocs/_vti_bin/DocsDsi/HomeService.svc/GetTheLatestUploadedDocumentsByLibraryInternalName/Procdures
          http://pars402i2701.bnppi.priv/sites/docsdsi/_vti_bin/DocsDsi/HomeService.svc/GetTheLatestUploadedDocumentsByLibraryInternalName/AppProceduresDocsLibrary */
        #endregion


        ///http://pars402i2701.bnppi.priv/sites/docsdsi/_vti_bin/DocsDsi/HomeService.svc/GetLatestUploadedDocsByLibraryInternalNameAndNumberOfDays/AppProceduresDocsLibrary/10
        /// <summary>
        /// Obtenir la liste des fichiers récemment enregistrés, modifiés par nom de la bibliothèque et le nombre de jours à récupérer.
        /// </summary>
        /// <param name="libraryInternalName"></param>
        /// <param name="NumberOfDays"></param>
        /// <returns></returns>
        public string GetLatestUploadedDocsByLibraryInternalNameAndNumberOfDays(string libraryInternalName, string NumberOfDays)
        {
            try
            {
                List<Document> docs = LibraryDataManager.getLatestDocs(libraryInternalName, NumberOfDays);
                string json = new JavaScriptSerializer().Serialize(docs);
                return json;
            }
            catch (Exception ex)
            {
                LogManager.LogError("[DOCS DSI- ISAPI ] Error occurred," + ". Exception- " + ex.ToString());
                return ("[Error occurred]" + ex.Message);
            }
        }

        /// http://pars402i2701.bnppi.priv/sites/docsdsi/_vti_bin/DocsDsi/HomeService.svc/GetTheLatestUploadedDocumentsHomePage/10
        /// <summary>
        /// utilisé dans la page d'acceuil du site
        /// Obtenir la liste des documents (Templates documents, procedure, Cartographie applicative et informations générales )récemment enregistrés,(ordonnés par la date de modification) 
        /// </summary>
        /// <returns></returns>

        public string GetTheLatestUploadedDocumentsHomePage(string NumberOfDays)
        {
            // Templates documents
            List<Document> docsTemplate = LibraryDataManager.getLatestDocs(Lists.APP_LIB_TEMPLATES_DOCS_NAME, NumberOfDays);
            // procedure documents
            List<Document> docsProcedure = LibraryDataManager.getLatestDocs(Lists.APP_LIB_PROCEDURE_DOCS_NAME, NumberOfDays);
            // Application Mapping Library documents
            List<Document> docsApplicationMapping = LibraryDataManager.getLatestDocs(Lists.APP_LIB_APPLICATION_MAPPING_NAME, NumberOfDays);
            // General Information documents
            List<Document> docsAppGeneralInfDocs = LibraryDataManager.getLatestDocs(Lists.APP_LIB_GENERAL_INFORMATION_DOCS_NAME, NumberOfDays);


            var docs = docsTemplate.Concat(docsProcedure).Concat(docsApplicationMapping).Concat(docsAppGeneralInfDocs);
            List<Document> docslist = docs.ToList().OrderByDescending(o => o.Modified).ToList();
            string json = new JavaScriptSerializer().Serialize(docslist);
            return json;
        }

        /// <summary>
        /// Get Projects documents
        /// </summary>
        /// <returns></returns>
        public string GetTheLatestUploadedDocumentsProjects(string NumberOfDays)
        {
            try
            {
                List<Document> docsBalanceSheeProjects = LibraryDataManager.getLatestDocs("ProjectsBalanceSheetDocsLibrary", NumberOfDays);
                List<Document> docsC2IProjects = LibraryDataManager.getLatestDocs("ProjectsC2IDocsLibrary", NumberOfDays);
                List<Document> docsCMATProjects = LibraryDataManager.getLatestDocs("ProjectsCMATDocsLibrary", NumberOfDays);
                List<Document> docsCOMITProjects = LibraryDataManager.getLatestDocs("ProjectsCOMITDocsLibrary", NumberOfDays);
                List<Document> docsCVITProjects = LibraryDataManager.getLatestDocs("ProjectsCvitDocsLibrary", NumberOfDays);
                List<Document> docsDeliveryCardsProjects = LibraryDataManager.getLatestDocs("ProjectsDeliveryCardsDocsLibrary", NumberOfDays);
                List<Document> docsDemandsDocsProjects = LibraryDataManager.getLatestDocs("ProjectsDemandsDocsLibrary", NumberOfDays);
                List<Document> docsIRPPProjects = LibraryDataManager.getLatestDocs("ProjectsIRPPDocsLibrary", NumberOfDays);
                List<Document> docsMinutesOfMeetingProjects = LibraryDataManager.getLatestDocs("ProjectsMinutesOfMeetingDocsLibrary", NumberOfDays);
                List<Document> docsOtherProjects = LibraryDataManager.getLatestDocs("ProjectsOtherDocsLibrary", NumberOfDays);
                List<Document> docsReleaseNotesProjects = LibraryDataManager.getLatestDocs("ProjectsReleaseNotesDocsLibrary", NumberOfDays);
                List<Document> docsSpecificationsProjects = LibraryDataManager.getLatestDocs("ProjectsSpecificationsDocsLibrary", NumberOfDays);
                List<Document> docsTestsBookProjects = LibraryDataManager.getLatestDocs("ProjectsTestsBookDocsLibrary", NumberOfDays);


                // Concat
                var docs = docsBalanceSheeProjects.Concat(docsC2IProjects).Concat(docsCMATProjects).Concat(docsCOMITProjects).Concat(docsCVITProjects)
                    .Concat(docsDeliveryCardsProjects).Concat(docsDemandsDocsProjects).Concat(docsIRPPProjects).Concat(docsMinutesOfMeetingProjects)
                    .Concat(docsOtherProjects).Concat(docsReleaseNotesProjects).Concat(docsSpecificationsProjects).Concat(docsTestsBookProjects);

                List<Document> docslist = docs.ToList().OrderByDescending(o => o.Modified).ToList();


                string json = new JavaScriptSerializer().Serialize(docslist);
                return json;
            }
            catch (Exception ex)
            {
                LogManager.LogError("[DOCS DSI] Error occurred," + ". Exception- " + ex.ToString());
                return ("[DOCS DSI] Error occurred " + ex.Message);
            }
        }


    }
}

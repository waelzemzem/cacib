﻿using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing;
using System;
using System.Collections.ObjectModel;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace BNPPI.RE.DocsDsi.Portal.CONTROLTEMPLATES.DocsDsi
{
    public partial class SwitchLanguage : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (PublishingWeb.IsPublishingWeb(SPContext.Current.Web))
                {
                    ReadOnlyCollection<VariationLabel> labels = Variations.GetLabels(SPContext.Current.Site);
                    rptLanguages.DataSource = labels;
                    rptLanguages.DataBind();
                }
            }
            catch (Exception ex)
            {
                LogManager.LogError(ex);
            }
        }

        protected void rptLanguages_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.DataItem != null)
            {
                if (PublishingWeb.IsPublishingWeb(SPContext.Current.Web))
                {
                    VariationLabel label = e.Item.DataItem as VariationLabel;

                    string urlLink;
                    PublishingWeb pweb = PublishingWeb.GetPublishingWeb(SPContext.Current.Web);
                    try
                    {

                        if (pweb.Label == label)
                        {
                            urlLink = Request.Url.AbsoluteUri;
                            ((HtmlGenericControl)e.Item.FindControl("liLanguage")).Attributes.Add("class", "active");
                        }
                        else
                        {
                            urlLink = Request.Url.AbsoluteUri.Replace(pweb.Label.TopWebUrl, label.TopWebUrl);
                        }

                        ((HtmlAnchor)e.Item.FindControl("lnkUrl")).HRef = urlLink;
                        pweb.Close();
                    }
                    catch (ArgumentOutOfRangeException argEx)
                    {
                        LogManager.LogError(argEx);
                    }
                    finally
                    {
                        pweb.Close();
                    }
                }
            }
        }
    }
}

﻿using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.Model;
using BNPPI.RE.DocsDsi.Portal.Utilities;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;

namespace BNPPI.RE.DocsDsi.Portal.DataManagers
{
    public static class LibraryDataManager
    {
        public static List<Document> getLatestDocs(string libraryInternalName, string NumberOfDays)
        {
            List<Document> DocumentsData = new List<Document>();
            Document element = null;
            SPList spLibrary = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, libraryInternalName));
            if (spLibrary != null)
            {
                try
                {
                    SPQuery spQueryLatestDocuments = new SPQuery();
                    spQueryLatestDocuments.Query = String.Format(CamlQuery.QUERY_LAST_DOCUMENTS_By_Library, NumberOfDays);
                    SPListItemCollection spResults = spLibrary.GetItems(spQueryLatestDocuments);
                    foreach (SPListItem i in spResults)
                    {
                        element = ConvertItem.ItemConfigToEntity(i, spLibrary.Title.ToString());
                        DocumentsData.Add(element);
                    }

                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return DocumentsData;
        }

        internal static List<Document> getListDocumentsByIDandLibrary(string libraryInternalName, string itemTitle)
        {
            List<Document> DocumentsData = new List<Document>();
            Document element = null;
            SPList spLibrary = SPContext.Current.Web.GetList(SPUrlUtility.CombineUrl(SPContext.Current.Web.ServerRelativeUrl, libraryInternalName));
      

            string url = SPContext.Current.Web.ServerRelativeUrl + "/"+ libraryInternalName  + "/" + itemTitle;
            SPFolder folder = SPContext.Current.Web.GetFolder(url);
            


            if (spLibrary != null)
            {
                try
                {
                    SPQuery camlQuery = new SPQuery();
                    camlQuery.Folder = folder;
                    camlQuery.ViewAttributes = "Scope='RecursiveAll'";
                    SPListItemCollection spResults = spLibrary.GetItems(camlQuery);
                    foreach (SPListItem i in spResults)
                    {
                        element = ConvertItem.ItemConfigToEntity(i, spLibrary.Title.ToString());
                        DocumentsData.Add(element);
                    }

                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return DocumentsData;
        }
    }
}

﻿using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Diagnotics
{
    /// <summary>
    /// Logger holds the System.Diagnostics.TraceSource Implementation for "HPSWebTraceSource" source.
    /// </summary>
    public static class LogManager
    {
        /// <summary>
        /// Method to log the error
        /// </summary>
        /// <param name="message"> Parameter for the error message </param>
        public static void LogError(string message)
        {
            UlsLogger.LogError(message);
        }

        /// <summary>
        /// Returns HTML for exception description
        /// </summary>
        /// <param name="ex">exception to parse</param>
        /// <returns>HTML description of the error</returns>
        public static string GetHTMLForExceptionDescription(Exception ex)
        {
            if (ex == null)
                return null;

            var sb = new StringBuilder();

            sb.Append("<table><tr><td>");
            sb.Append("Error message : ");
            sb.Append("</td><td>");
            sb.Append(ex.Message);
            sb.Append("</td></tr>");
            sb.Append("<tr><td>");
            sb.Append("StackTrace : ");
            sb.Append("</td><td>");
            sb.Append(ex.TargetSite);
            sb.Append("</td></tr>");
            sb.Append("</table>");

            return sb.ToString();
        }

        /// <summary>
        /// Method to log the error
        /// </summary>
        /// <param name="ex">The exception to log</param>
        public static void LogError(Exception ex)
        {
            string innerMessage = string.Empty;
            string innerStack = string.Empty;
            if (ex.InnerException != null)
            {
                innerMessage = ex.InnerException.Message;
                innerStack = ex.InnerException.StackTrace;
            }
            UlsLogger.LogError(string.Format("Message : {0}; Stack trace : {1}; Inner Exception Message : {2}; Inner Exception stack trace : {3}", ex.Message, ex.StackTrace, innerMessage, innerStack));
        }

        /// <summary>
        /// Method to log the information
        /// </summary>
        /// <param name="message"> Parameter for message </param>
        public static void LogInfo(string message)
        {
            UlsLogger.LogMessage(message);
        }

        /// <summary>
        /// Storing the warning messages
        /// </summary>
        /// <param name="message">Log message text</param>
        public static void LogWarning(string message)
        {
            UlsLogger.LogWarning(message);
        }
    }

}

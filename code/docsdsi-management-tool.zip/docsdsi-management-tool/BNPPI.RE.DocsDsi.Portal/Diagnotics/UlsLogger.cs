﻿using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Diagnotics
{
    /// <summary>
    /// Implementaiton of ULS Logger inherited from SPDiagnosticsService
    /// </summary>
    public sealed class UlsLogger : SPDiagnosticsService
    {
        /// <summary>
        /// Constant for Information type Log Message 
        /// </summary>
        private const string LoggerWebInfo = "Information";

        /// <summary>
        /// Constant for Error type Log Message
        /// </summary>
        private const string LoggerWebError = "Error";

        /// <summary>
        /// Constant for Warning type Log Message
        /// </summary>
        private const string LoggerWebWarning = "Warning";

        /// <summary>
        /// Constant for Log Source
        /// </summary>
        private const string LoggerAppName = "BNPPI.RE.DocsDsi";

        /// <summary>
        /// Instance of ULS Logger service
        /// </summary>
        private static UlsLogger _current;

        /// <summary>
        /// Prevents a default instance of the <see cref="UlsLogger" /> class from being created.
        /// </summary>
        private UlsLogger()
            : base("BNPPI.RE.DocsDsi.Portal Logging Service", SPFarm.Local)
        {
        }

        /// <summary>
        /// Gets the current ULS Logger Instance
        /// </summary>
        public static UlsLogger Current
        {
            get
            {
                if (_current == null)
                {
                    _current = new UlsLogger();
                }

                return _current;
            }
        }

        /// <summary>
        /// Message to log the message to the ULS Log
        /// </summary>
        /// <param name="message">Message to be logged</param>
        public static void LogMessage(string message)
        {
            SPDiagnosticsCategory category = Current.Areas[LoggerAppName].Categories[LoggerWebInfo];
            Current.WriteTrace(0, category, TraceSeverity.Verbose, message);
        }

        /// <summary>
        /// Message to log the error to the ULS Log
        /// </summary>
        /// <param name="message">Message to be logged</param>
        public static void LogError(string message)
        {
            SPDiagnosticsCategory category = Current.Areas[LoggerAppName].Categories[LoggerWebError];
            Current.WriteTrace(0, category, TraceSeverity.Unexpected, message);
        }

        /// <summary>
        /// Message to log the warning to the ULS Log
        /// </summary>
        /// <param name="message">Message to be logged</param>
        public static void LogWarning(string message)
        {
            SPDiagnosticsCategory category = Current.Areas[LoggerAppName].Categories[LoggerWebWarning];
            Current.WriteTrace(0, category, TraceSeverity.Unexpected, message);
        }

        /// <summary>
        /// Create the Logging Header for HPSWeb
        /// </summary>
        /// <returns>returns collection of HPS logging areas</returns>
        protected override IEnumerable<SPDiagnosticsArea> ProvideAreas()
        {
            List<SPDiagnosticsCategory> diagnosticsCategories = new List<SPDiagnosticsCategory>();
            diagnosticsCategories.Add(new SPDiagnosticsCategory(LoggerWebInfo, TraceSeverity.Verbose, EventSeverity.Information));
            diagnosticsCategories.Add(new SPDiagnosticsCategory(LoggerWebError, TraceSeverity.Unexpected, EventSeverity.Error));
            diagnosticsCategories.Add(new SPDiagnosticsCategory(LoggerWebWarning, TraceSeverity.Unexpected, EventSeverity.Warning));
            SPDiagnosticsArea diagnosticsArea = new SPDiagnosticsArea(LoggerAppName, diagnosticsCategories);
            List<SPDiagnosticsArea> areas = new List<SPDiagnosticsArea> { diagnosticsArea };
            return areas;
        }
    }

}

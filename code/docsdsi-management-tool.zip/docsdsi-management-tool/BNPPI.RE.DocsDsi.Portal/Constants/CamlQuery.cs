﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Constants
{
    public static class CamlQuery
    {
        public const string QUERY_LAST_DOCUMENTS_By_LibraryA = @"<Where>
                                                  <And>
                                                     <Geq>
                                                        <FieldRef Name='Modified' />
                                                        <Value Type='DateTime'>
                                                           <Today OffsetDays='{0}' />
                                                        </Value>
                                                     </Geq>
                                                     <Eq>
                                                        <FieldRef Name='FSObjType' />
                                                        <Value Type='Integer'>0</Value>
                                                     </Eq>
                                                  </And>
                                               </Where>
                                               <OrderBy>
                                                  <FieldRef Name='Modified' />
                                               </OrderBy>";


        public const string QUERY_LAST_DOCUMENTS_By_Library = "<Where><And><Geq><FieldRef Name = 'Modified' /><Value Type='DateTime'> <Today OffsetDays ='" +
                                                "{0}" + "' /></Value ></Geq ><Eq><FieldRef Name='FSObjType' /><Value Type='Integer'>0</Value></Eq></And></Where><QueryOptions><ViewAttributes Scope='RecursiveAll' /></QueryOptions>";





        public const string QUERY_GET_DOCUMENTS_IN_FOLDER = @"   <Where>
                                                     <Eq>
                                                        <FieldRef Name='FSObjType' />
                                                        <Value Type='Integer'>0</Value>
                                                     </Eq>
                                               </Where>
                                               <OrderBy>
                                                  <FieldRef Name='Modified' />
                                               </OrderBy>";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Constants
{
    public static class Lists
    {
        #region  Lists
        public const string APP_LIST_APPLICATIONS_NAME = "Lists/AppsList";
        public const string APP_LIST_PROJECTS_NAME = "Lists/ProjectsList";

        public const string APP_LIST_Param_TEMPLATE_TYPE_NAME = "Lists/ParamTypesTemplateDoctsList";

        public const string APP_LIST_Param_COUNTRY_NAME = "Lists/ParamCountryList";
        public const string APP_LIST_PARAM_ROLE_FUNCTIONS_NAME = "Lists/ParamRolesFunctionsList";
        


        #endregion

        #region  Projects Libraries
        public const string PROJECT_LIB_COMIT_DOCS_NAME = "ProjectsCOMITDocsLibrary";
        public const string PROJECT_LIB_CMAT_DOCS_NAME = "ProjectsCMATDocsLibrary";
        public const string PROJECT_LIB_CVIT_DOCS_NAME = "ProjectsCvitDocsLibrary";
        public const string PROJECT_LIB_C2I_DOCS_NAME = "ProjectsC2IDocsLibrary";
        public const string PROJECT_LIB_IRPP_DOCS_NAME = "ProjectsIRPPDocsLibrary";
        public const string PROJECT_LIB_DEMANDS_DOCS_NAME = "ProjectsDemandsDocsLibrary";
        public const string PROJECT_LIB_SPECIFICATION_DOCS_NAME = "ProjectsSpecificationsDocsLibrary";
        public const string PROJECT_LIB_RELEASE_NOTES_DOCS_NAME = "ProjectsReleaseNotesDocsLibrary";
        public const string PROJECT_LIB_TEST_BOOK_DOCS_NAME = "ProjectsTestsBookDocsLibrary";
        public const string PROJECT_LIB_MINUTES_OF_METTING_DOCS_NAME = "ProjectsMinutesOfMeetingDocsLibrary";
        public const string PROJECT_LIB_DELIVERY_CARDS_DOCS_NAME = "ProjectsDeliveryCardsDocsLibrary";
        public const string PROJECT_LIB_BALANCE_SHEET_DOCS_NAME = "ProjectsBalanceSheetDocsLibrary";
        public const string PROJECT_LIB_OTHER_DOCS_NAME = "ProjectsOtherDocsLibrary";
        public const string PROJECT_LIB_COPIL_DOCS_NAME = "ProjectsCOPILDocsLibrary";
        public const string PROJECT_LIB_SVC_DOCS_NAME = "ProjectsSVCDocsLibrary";
        public const string PROJECT_LIB_IDCARD_DOCS_NAME = "ProjectsIDCard";

        

        #endregion


        #region  RUN Libraries
        public const string RUN_LIB_FILE_ARCHITECTURE_SCHEMA_DOCS_NAME = "RunFileArchitectureSchemeLibrary";
        public const string RUN_LIB_FILE_SCHEMA_OF_EXPLOITATION_DOCS_NAME = "RunFileSchemeOfExploitationLibrary";
        public const string RUN_LIB_FILE_SCHEMA_OF_INSTALATION_DOCS_NAME = "RunFileSchemeOfInstallationLibrary";
        public const string RUN_LIB_SANITY_CHECK_APPLICATION_DOCS_NAME = "RunSanityCheckApplicationLibrary";
        public const string RUN_LIB_SUPPORT_DOCS_NAME = "RunSupportDocumentationLibrary";
        public const string RUN_LIB_USER_GUIDE_DOCS_NAME = "RunUserGuideLibrary";
        public const string RUN_LIB_SECURITY_DOCS_NAME = "RunSecurityDocumentLibrary";
        public const string RUN_LIB_NON_REGRESSION_TESTS_BOOK_DOCS_NAME = "RunNonRegressionTestsBookLibrary";

        public const string RUN_LIB_OTHER_DOCS_NAME = "RunOtherDocsLibrary";
        #endregion


        #region  Others Libraries
        public const string APP_LIB_PROCEDURE_DOCS_NAME = "AppProceduresDocsLibrary";
        public const string APP_LIB_GENERAL_INFORMATION_DOCS_NAME = "AppGeneralInfDocsLibrary";
        public const string APP_LIB_TEMPLATES_DOCS_NAME = "AppTemplateDocsLibrary";
        public const string APP_LIB_APPLICATION_MAPPING_NAME = "ApplicationMappingLibrary";
        public const string MINITORING_MANAGEMENT_LIB_NAME = "MonitoringManagementLib";

        
        #endregion



    }
}

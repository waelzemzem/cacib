﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Constants
{
    public static class ContentTypes
    {
        #region Defaults Content Types
        public const string DEFAULT_CT_DOCUMENT_NAME = "Document";
        #endregion
        #region  Content Types Projects Libraries document set
        public const string PROJECT_CT_COMIT_ID = "0x0120D5200078E642D4A3AD4894A2B938FBD462E95A";
        public const string PROJECT_CT_CMAT_ID = "0x0120D52000AE860C4D965D401785C1D82F9B3A0593";
        public const string PROJECT_CT_CVIT_ID = "0x0120D52000D1D396130B854D6DB8EC179BFB357406";
        public const string PROJECT_CT_C2I_ID = "0x0120D520000A0C037802FA4E4C914526BC1136B54F";
        public const string PROJECT_CT_CIRPP_ID = "0x0120D520008C7A9F8F118F4B0EA5E52955BCFE1388";
        public const string PROJECT_CT_DEMANDS_ID = "0x0120D520000B403C5A1AD744AB82866BAA9564FC68";
        public const string PROJECT_CT_SPECIFICATION_ID = "0x0120D5200021C0D5212A0A40D794E82810BA21BAAB";
        public const string PROJECT_CT_RELEASE_NOTES_ID = "0x0120D520007C32182155514E27B41F8FFCD92CBE49";
        public const string PROJECT_CT_TEST_BOOK_ID = "0x0120D52000B63DC7306D8245168F5BAACF56A49D5D";
        public const string PROJECT_CT_MINUTES_OF_METTING_ID = "0x0120D520006D435F321EB44D709D21080CB2086520";
        public const string PROJECT_CT_DELIVERY_CARDS_ID = "0x0120D52000F3759784C3B246A4B750DB89EE3B7835";
        public const string PROJECT_CT_BALANCE_SHEET_ID = "0x0120D52000E003F8A732CC4E54A58A95D024A8441E";
        public const string PROJECT_CT_OTHER_ID = "0x0120D520004D90214F561B415088662E65161F7DB3";

        public const string PROJECT_CT_COPIL_ID = "0x0120D520006C520FAF975C4EDEBE66D1A01AED4AA8";
        public const string PROJECT_CT_SVC_ID = "0x0120D52000C03630D2177349A7A8A61A41A97B1DE9";

        public const string PROJECT_CT_IDCARD_ID = "0x0120D5200092E94FEDE24C41F680F4AB1F739C2F64";



        #endregion
        #region Content Types Run Libraries
        public const string RUN_CT_COMMON_DOCS_SET_ID = "0x0120D520000D3F1096E8C1409FA00A0DFA2CC27162";
        #endregion

        #region Content type Bibliothèque Informations générales
        public const string APP_CT_GENERAL_INFORMATIONS_DOCS_SET_ID = "0x0120D5200028EC208A4F59479C93870D7AF0B9B2B8";
        public const string APP_CT_GENERAL_INFORMATIONS_DOCS_ID = "0x0101001ABE8ABECF8D4EBC91632F04817541E9";

        
        #endregion

        #region  Content type  Bibliothèque des Procédures
        public const string APP_CT_PROCEDURE_DOC_SET_ID = "0x0120D520000141EF10334447D3B641282D5EB163F6";
        #endregion

        #region 
        public const string APP_CT_PROJECT_ID = "0x010093A0F63E8A284E8E92BC76DB7E378AFF";
        

        #endregion
    }
}

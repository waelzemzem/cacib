﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Constants
{
    public static class FieldsRefApps
    {
        public const string REF_APPS_FIELDS_TITLE_INTERNALNAME = "Title";
        public const string REF_APPS_FIELDS_ID_APPLICATION_INTERNALNAME = "IDApp";
        public const string REF_APPS_FIELDS_DESCRIPTION_INTERNALNAME = "AppDescription";
        public const string REF_APPS_FIELDS_VERSION_INTERNALNAME = "AppVersion";
        public const string REF_APPS_FIELDS_INTERNET_FACING_INTERNALNAME = "AppInternetFacing";
        public const string REF_APPS_FIELDS_PERSONA_DATA_INTERNALNAME = "AppPersonalData";
        public const string REF_APPS_FIELDS_CONFIDENTIALITY_INTERNALNAME = "AppConfidentiality";
        public const string REF_APPS_FIELDS_INTEGRITY_INTERNALNAME = "AppIntegrity";
        public const string REF_APPS_FIELDS_AVAIBILITY_INTERNALNAME = "AppAvaibility";
        public const string REF_APPS_FIELDS_TRACEABILITY_INTERNALNAME = "AppTraceability";
        public const string REF_APPS_FIELDS_RTO_INTERNALNAME = "AppRTO";
        public const string REF_APPS_FIELDS_RPO_INTERNALNAME = "AppRPO";
        public const string REF_APPS_FIELDS_LASTCIAT_INTERNALNAME = "AppLastCIAT";
        public const string REF_APPS_FIELDS_CLASS_INTERNALNAME = "AppClass";
        public const string REF_APPS_FIELDS_AUTHENTIFICATION_INTERNALNAME = "AppAuthentification";
        public const string REF_APPS_FIELDS_HOSTING_TYPE_INTERNALNAME = "AppHostingType";
        public const string REF_APPS_FIELDS_CLOUD_SERVICE_MODEL_INTERNALNAME = "AppCloudServiceModel";
        public const string REF_APPS_FIELDS_HOSTING_PROVIDER_INTERNALNAME = "AppHostingProvider";
        public const string REF_APPS_FIELDS_MANAGED_APPLICATION_INTERNALNAME = "AppManagedApplication";
        public const string REF_APPS_FIELDS_STATUS_INTERNALNAME = "AppStatus";
        public const string REF_APPS_FIELDS_IT_RESPONSIBLE_INTERNALNAME = "AppITResponsible";



    }
}

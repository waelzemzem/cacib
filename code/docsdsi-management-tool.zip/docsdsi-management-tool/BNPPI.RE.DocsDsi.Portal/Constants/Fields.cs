﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.DocsDsi.Portal.Constants
{
    public static class Fields
    {
        #region Native fields
        public const string SP_FIELDS_TITLE_INTERNALNAME = "Title";
        public const string SP_FIELDS_ID_INTERNALNAME = "ID";
        public const string SP_FIELDS_CONTENT_TYPE_ID_INTERNALNAME = "ContentTypeId";
        public const string FIELDS_LANGUAGE_INTERNALNAME = "Language";
        #endregion

        #region PROJECTS fields
        public const string PROJECTS_LIST_FIELDS_PROJECT_NAME_INTERNALNAME = "ProjectName";
        public const string PROJECTS_LIST_FIELDS_TO_NOTIFY_INTERNALNAME = "ToNotify";

        #endregion
        #region fields of Application Lists
        public const string APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME = "RelatedApplications";
        #endregion

        #region Interval name columns Projects List
        public const string PROJET_FIELDS_IDPROJECT_INTERNALNAME = "IDProjet";
        public const string PROJET_FIELDS_BALANCESHEET_INTERNALNAME = "BalanceSheet";
        public const string PROJET_FIELDS_C2I_INTERNALNAME = "C2I";
        public const string PROJET_FIELDS_CMAT_INTERNALNAME = "CMAT";
        public const string PROJET_FIELDS_COMIT_INTERNALNAME = "COMIT";
        public const string PROJET_FIELDS_CVIT_INTERNALNAME = "CVIT";
        public const string PROJET_FIELDS_DELIVERY_CARDS_INTERNALNAME = "DeliveryCards";
        public const string PROJET_FIELDS_DEMANDS_INTERNALNAME = "Demands";
        public const string PROJET_FIELDS_IRPP_INTERNALNAME = "IRPP";
        public const string PROJET_FIELDS_MINUTES_INTERNALNAME = "Minutes";
        public const string PROJET_FIELDS_OtherDOCS_INTERNALNAME = "OtherDocs";
        public const string PROJET_FIELDS_RELEASE_NOTES_INTERNALNAME = "ReleaseNotes";
        public const string PROJET_FIELDS_SPECIFICATION_INTERNALNAME = "Specifications";
        public const string PROJET_FIELDS_TESTS_BOOK_INTERNALNAME = "TestsBook";

        // COPIL
        public const string PROJET_FIELDS_COPIL_INTERNALNAME = "COPIL";
        public const string PROJET_FIELDS_SVC_INTERNALNAME = "SVC";
        public const string PROJET_FIELDS_IDCARD_INTERNALNAME = "IDCard";

        #endregion

        #region Interval name columns Applications List
        public const string RUN_FIELDS_IDAPPLICATION_INTERNALNAME = "IDApp";
        public const string RUN_FIELDS_ARCHI_SCHEMA_INTERNALNAME = "UrlRunArchitectureSchemeFile";
        public const string RUN_FIELDS_SCHEMA_OF_EXPLOITATION_INTERNALNAME = "UrlRunSchemeOfExploitationFile";
        public const string RUN_FIELDS_SCHEMA_OF_INSTALLATION_INTERNALNAME = "UrlRunSchemeOfInstallationFile";
        public const string RUN_FIELDS_NON_REGRESSION_TESTBOOK_INTERNALNAME = "UrlRunNonRegressionTestsBookFile";
        public const string RUN_FIELDS_SANITY_CHECK_APPLICATION__INTERNALNAME = "UrlRunSanityCheckApplicationFile";
        public const string RUN_FIELDS_SECURITY_DOCS_INTERNALNAME = "UrlRunSecurityDocumentFile";
        public const string RUN_FIELDS_SUPPORT_DOCS_INTERNALNAME = "UrlRunSupportDocumentationFile";
        public const string RUN_FIELDS_USER_GUIDE_INTERNALNAME = "UrlRunUserGuideFile";

        public const string RUN_FIELDS_OTHER_DOCS_INTERNALNAME = "UrlRunOtherDocuments";


        #endregion

        #region Others Columns
        public const string FIELDS_DOCUMENT_STATUS_INTERNALNAME = "DocumentStatus";
        public const string FIELDS_COMMON_COL_COMMENT_INTERNALNAME = "CommonColComment";
        public const string FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME = "CountriesConcerned";

        public const string FIELDS_COMMON_COL_BUSNESSKINE_AND_FUNCTION_INTERNALNAME = "BusinessLineAndFunction";
        public const string FIELDS_COMMON_COL_DOC_TYPE_SECU_INTERNALNAME = "DocumentTypeSecu";

        

        #endregion
    }
}

﻿namespace BNPPI.RE.DocsDsi.Portal.Layouts.BNPPI.RE.DocsDsi.Portal
{
    public partial class ApplicationPage1
    {
    }
}

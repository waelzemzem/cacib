﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace BNPPI.RE.DocsDsi.Portal.Layouts.BNPPI.RE.DocsDsi.Portal
{
    public partial class ApplicationPage1 : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}

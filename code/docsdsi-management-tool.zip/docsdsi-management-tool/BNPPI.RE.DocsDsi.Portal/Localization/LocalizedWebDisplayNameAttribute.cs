﻿using Microsoft.SharePoint;
using System;
using System.Web.UI.WebControls.WebParts;

namespace BNPPI.RE.DocsDsi.Portal.Localization
{
    /// <summary>
    /// Localized Web Display Name Attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public sealed class LocalizedWebDisplayNameAttribute : WebDisplayNameAttribute
    {
        /// <summary>
        /// Check if localized
        /// </summary>
        bool _isLocalized;

        /// <summary>
        /// Get resource file name
        /// </summary>
        readonly string _resourceFile;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="displayName">Web display name</param>
        /// <param name="resourceFile">resource file used to localize</param>
        public LocalizedWebDisplayNameAttribute(string displayName, string resourceFile)
            : base(displayName)
        {
            _resourceFile = resourceFile;
        }

        /// <summary>
        /// Display name
        /// </summary>
        public override string DisplayName
        {
            get
            {
                if (!_isLocalized)
                {
                    uint lcid = SPContext.Current.Web.Language;
                    Localization localization = new Localization(_resourceFile, lcid);
                    DisplayNameValue = localization.GetResource(base.DisplayName);
                    _isLocalized = true;
                }
                return base.DisplayName;
            }
        }
    }
}

﻿using Microsoft.SharePoint;
using System;
using System.ComponentModel;

namespace BNPPI.RE.DocsDsi.Portal.Localization
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public sealed class LocalizedCategoryAttribute : CategoryAttribute
    {
        readonly string _resourceFile;

        public LocalizedCategoryAttribute(string category, string resourceFile) : base(category)
        {
            _resourceFile = resourceFile;
        }

        /// <summary>
        /// Return localized string from key
        /// </summary>
        /// <param name="value">resource key</param>
        /// <returns>Localized string</returns>
        protected override string GetLocalizedString(string value)
        {
            uint lcid = SPContext.Current.Web.Language;
            Localization localization = new Localization(_resourceFile, lcid);
            return localization.GetResource(value);
        }
    }
}

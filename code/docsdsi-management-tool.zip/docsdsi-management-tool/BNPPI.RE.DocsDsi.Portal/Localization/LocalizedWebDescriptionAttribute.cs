﻿using Microsoft.SharePoint;
using System;
using System.Web.UI.WebControls.WebParts;

namespace BNPPI.RE.DocsDsi.Portal.Localization
{
    /// <summary>
    /// Localized Web Description Attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public sealed class LocalizedWebDescriptionAttribute : WebDescriptionAttribute
    {
        /// <summary>
        /// Check if localized
        /// </summary>
        bool _isLocalized;

        /// <summary>
        /// Get resource file name
        /// </summary>
        readonly string _resourceFile;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="description">Description of the web attribute</param>
        /// <param name="resourceFile">resource file used to localize</param>
        public LocalizedWebDescriptionAttribute(string description, string resourceFile)
            : base(description)
        {
            _resourceFile = resourceFile;
        }

        /// <summary>
        /// Desription of the web attribute
        /// </summary>
        public override string Description
        {
            get
            {
                if (!_isLocalized)
                {
                    uint lcid = SPContext.Current.Web.Language;
                    Localization localization = new Localization(_resourceFile, lcid);
                    DescriptionValue = localization.GetResource(base.Description);
                    _isLocalized = true;
                }
                return base.Description;
            }
        }
    }
}

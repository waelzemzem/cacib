﻿using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Diagnostics;

namespace BNPPI.RE.DocsDsi.Portal.Localization
{
    /// <summary>
    /// Localization Utils Class
    /// </summary>
    public class Localization
    {
        /// <summary>
        /// Instance of Localization object
        /// </summary>
        [DebuggerBrowsable(DebuggerBrowsableState.Never)]
        private static Localization _instance;

        /// <summary>
        /// Object used to lock resources while accessing the instance
        /// </summary>
        [DebuggerBrowsable(DebuggerBrowsableState.Never)]
        private static readonly object Locker = new object();

        /// <summary>
        /// Gets the Localization object for the current HTTP request
        /// </summary>
        public static Localization Current
        {
            [DebuggerStepThrough]
            get
            {
                lock (Locker)
                {
                    return _instance ?? (_instance = new Localization());
                }
            }
        }

        /// <summary>
        /// Default resource file (core is the default WSS resource file)
        /// </summary>
        private const string DefaultResourceFile = "";

        /// <summary>
        /// Resource internal prefix
        /// </summary>
        private const string ResourcesPrefix = "$Resources:";

        /// <summary>
        /// Resource file
        /// </summary>
        private readonly string _resFile = DefaultResourceFile;

        /// <summary>
        /// LCID
        /// </summary>
        private readonly uint _lcid;

        #region Constructors
        /// <summary>
        /// Use current website's language and "core" as default resource file 
        /// </summary>
        public Localization()
        {
            try
            {
                _lcid = SPContext.Current.Web.Language;
            }
            catch (Exception ex)
            {
                LogManager.LogError(ex.Message);
                _lcid = 1036;
            }
        }

        /// <summary>
        /// Use specific language and resource file 
        /// </summary>
        /// <param name="defaultResourceFile">Default Resource filename</param>
        /// <param name="lcid">Culture ID</param>
        public Localization(string defaultResourceFile, uint lcid)
        {
            _resFile = defaultResourceFile;
            _lcid = lcid;
        }
        #endregion

        /// <summary>
        /// Get string from resource key
        /// </summary>
        /// <param name="resKey">Resource key</param>
        /// <returns>String associated to the resource key</returns>
        public string GetResource(string resKey)
        {
            if (_resFile != null)
                return GetResource(resKey, _resFile, _lcid);
            return resKey;
        }

        /// <summary>
        /// Get string from resource key and resource file
        /// </summary>
        /// <param name="resKey">Resource key</param>
        /// <param name="resFile">Resource file ("core" for core.resx, core.en-US.resx, etc)</param>
        /// <returns>String associated to the resource key</returns>
        public string GetResource(string resKey, string resFile)
        {
            if (resFile != null && resKey != null)
                return GetResource(resKey, resFile, _lcid);
            return resKey;
        }

        /// <summary>
        /// Get string from key, resource file and language
        /// </summary>
        /// <param name="resKey">Resource key</param>
        /// <param name="resFile">Resource file ("core" for core.resx, core.en-US.resx, etc)</param>
        /// <param name="lcid">LCID</param>
        /// <returns>String associated to the resource key</returns>
        public string GetResource(string resKey, string resFile, uint lcid)
        {
            string resValue = SPUtility.GetLocalizedString(ResourcesPrefix + resKey, resFile, lcid);
            if (resValue == ResourcesPrefix + resKey && lcid != 0)
            {
                resValue = SPUtility.GetLocalizedString(ResourcesPrefix + resKey, resFile, 0);
            }
            return resValue;
        }
      }
}

﻿using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing;
using Microsoft.SharePoint.Utilities;
using System;

namespace BNPPI.RE.DocsDsi.Portal.Extensions
{
    public static class SPWebExtensions
    {
        /// <summary>
        /// Apply masterpages
        /// </summary>
        /// <param name="web">The extended Web</param>
        /// <param name="frontMasterUrl">url of the masterpage to apply</param>
        public static void ApplyMasterPage(this SPWeb web, string frontMasterUrl, string systemMasterUrl)
        {
            try
            {
                // save old value
                string oldFrontMasterUrl;
                string oldSystemMasterUrl;

                // Unsafe web
                bool unsafed = web.AllowUnsafeUpdates;
                web.AllowUnsafeUpdates = true;

                // Swap MasterPage
                LogManager.LogInfo("SPWebExtension : ApplyMasterPage Swap masterpage");

                // Check if web is publishing
                if (PublishingWeb.IsPublishingWeb(web))
                {
                    // swap master
                    oldFrontMasterUrl = web.CustomMasterUrl;
                    oldSystemMasterUrl = web.MasterUrl;

                    web.CustomMasterUrl = frontMasterUrl;
                    web.MasterUrl = systemMasterUrl;
                }
                else
                {
                    // swap master
                    oldFrontMasterUrl = web.MasterUrl;
                    oldSystemMasterUrl = web.MasterUrl;

                    web.CustomMasterUrl = frontMasterUrl;
                    web.MasterUrl = systemMasterUrl;
                }

                // Front Master - Save old value for deactivating
                LogManager.LogInfo("SPWebExtension : ApplyMasterPage Save old masterpage Url");

                if (web.Properties.ContainsKey("Web_SwapFrontMasterPageUrl"))
                    web.Properties["Web_SwapFrontMasterPageUrl"] = oldFrontMasterUrl;
                else
                    web.Properties.Add("Web_SwapFrontMasterPageUrl", oldFrontMasterUrl);

                // System Master - Save old value for deactivating
                if (web.Properties.ContainsKey("Web_SwapSystemMasterPageUrl"))
                    web.Properties["Web_SwapSystemMasterPageUrl"] = oldSystemMasterUrl;
                else
                    web.Properties.Add("Web_SwapSystemMasterPageUrl", oldSystemMasterUrl);


                web.Properties.Update();
                web.Update();

                // reset unsafe
                web.AllowUnsafeUpdates = unsafed;
            }
            catch (Exception ex)
            {
                LogManager.LogError(ex);
            }
        }



        /// <summary>
        /// Get list by url
        /// </summary>
        /// <param name="element"></param>
        /// <param name="url">the url of the list</param>
        /// <returns>the list or null</returns>
        public static SPList TryGetListByUrl(this SPWeb element, string url)
        {
            LogManager.LogInfo("SPWebExtensions : Begin TryGetListByUrl : " + url);

            SPList list = null;
            try
            {
                if (element != null && !string.IsNullOrEmpty(url))
                {
                    string fullUrl = !SPUrlUtility.IsUrlFull(url) ? SPUrlUtility.CombineUrl(element.ServerRelativeUrl, url) : url;
                    list = element.GetList(fullUrl);
                }
            }
            catch (Exception ex)
            {
                LogManager.LogError(ex);
            }

            LogManager.LogInfo("SPWebExtensions : End TryGetListByUrl");
            return list;
        }

        /// <summary>
        /// Get list by url
        /// </summary>
        /// <param name="element">the element</param>
        /// <param name="url">the url of the list</param>
        /// <param name="list">The list.</param>
        /// <returns>the list or null</returns>
        public static bool TryGetListByUrl(this SPWeb element, string url, out SPList list)
        {
            LogManager.LogInfo("SPWebExtensions : Begin TryGetListByUrl : " + url);
            bool isFound = false;
            list = null;
            try
            {
                if (element != null && !string.IsNullOrEmpty(url))
                {
                    string fullUrl = SPUrlUtility.CombineUrl(element.ServerRelativeUrl, url);
                    list = element.GetList(fullUrl);
                    isFound = true;
                }
            }
            catch (Exception ex)
            {
                LogManager.LogError(ex);
            }
            LogManager.LogInfo("SPWebExtensions : Begin TryGetListByUrl");
            return isFound;
        }


        internal static void AddFieldByInternalNnmeToListAndView(SPWeb currentWeb, SPList libDocs, SPField sPField, bool required)
        {
            try
            {
                if (!libDocs.Fields.ContainsField(sPField.InternalName))
                {
                    sPField.Required = required;
                    libDocs.Fields.Add(sPField);
                    libDocs.Update();

                    AddToDefaultView(libDocs, sPField);
                }
            }
            catch (Exception ex)
            {
                LogManager.LogError(ex);
            }
        }

        /// <summary>
        /// Ajouter la colonne rôles et fonctions
        /// </summary>
        /// <param name="currentWeb"></param>
        /// <param name="libTemplatesDocs"></param>
        /// <param name="cTypes"></param>
        /// <param name="BusinessLineAndFunction"></param>
        internal static void AddFieldLookUpInContentTypeToCountryLisAt(SPWeb currentWeb, SPList libTemplatesDocs,  SPList BusinessLineAndFunction)
        {
            try

            {
                //var listContentType = (new SPContentTypeId(cTypes.Id.ToString()));
               
                    if (!libTemplatesDocs.Fields.ContainsField(Fields.FIELDS_COMMON_COL_BUSNESSKINE_AND_FUNCTION_INTERNALNAME))
                    {
                        libTemplatesDocs.Fields.AddLookup(Fields.FIELDS_COMMON_COL_BUSNESSKINE_AND_FUNCTION_INTERNALNAME, BusinessLineAndFunction.ID, true);
                        libTemplatesDocs.Update();

                        SPFieldLookup fieldLookup = new SPFieldLookup(libTemplatesDocs.Fields, Fields.FIELDS_COMMON_COL_BUSNESSKINE_AND_FUNCTION_INTERNALNAME);
                        fieldLookup.Title = Localization.Localization.Current.GetResource("Fields_BusinessLineAndFunctionDisplayName", "BNPPI.RE.DocsDSI.portal", 1036);
                        fieldLookup.Title = Localization.Localization.Current.GetResource("Fields_BusinessLineAndFunctionDisplayName", "BNPPI.RE.DocsDSI.portal", 1033);

                        fieldLookup.LookupField = BusinessLineAndFunction.Fields.GetField(Fields.SP_FIELDS_TITLE_INTERNALNAME).InternalName;
                        fieldLookup.Update();
                        libTemplatesDocs.Update();

                    SPView viewDefault = libTemplatesDocs.DefaultView;
                    viewDefault.ViewFields.Add(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME);
                    viewDefault.Update();
                }

            }
            catch (Exception ex)
            {
                LogManager.LogError("[DOCS DSI] Error occurred," + ". Exception- " + ex.ToString());
            }
        }

        internal static void AddContentTypeToLibraryById(SPWeb currentWeb, SPDocumentLibrary listLibrary, SPContentType cTypes_AppProceduresDocsSetName)
        {
            try
            {
                if (listLibrary != null)
                {
                    //SPContentType cTypes_AppProceduresDocsSetName = currentWeb.AvailableContentTypes[new SPContentTypeId(contentTypeId)];
                    if (!listLibrary.ContentTypesEnabled)
                    {
                        listLibrary.ContentTypesEnabled = true;
                        listLibrary.Update();
                    }
                    if (listLibrary.EnableFolderCreation)
                    {
                        listLibrary.EnableFolderCreation = false;
                        listLibrary.Update();
                    }

                    if (listLibrary.ContentTypes[cTypes_AppProceduresDocsSetName.Name] == null)
                    {
                        listLibrary.ContentTypes.Add(cTypes_AppProceduresDocsSetName);
                        listLibrary.Update();
                    }
                }

            }
            catch (Exception ex)
            {
                LogManager.LogError(ex);
            }
        }

        internal static void AddLookupFieldByInternalNnmeToListAndView(SPWeb currentWeb, SPDocumentLibrary libTemplatesDocs, SPField sPField, bool required)
        {
            // List ref Application 
            SPList countryList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.APP_LIST_Param_COUNTRY_NAME));
            try
            {
                //var fieldDocumentStatus = currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_DOCUMENT_STATUS_INTERNALNAME);
                if (!libTemplatesDocs.Fields.ContainsField(sPField.InternalName))
                {
                    libTemplatesDocs.Fields.AddLookup(sPField.InternalName, countryList.ID, true);
                    libTemplatesDocs.Update();

                    AddToDefaultView(libTemplatesDocs, sPField);
                }
            }
            catch (Exception ex)
            {
                LogManager.LogError(ex);
            }
        }
        public static void AddToDefaultView(SPList list, SPField sPField)
        {
            if (list != null && list.Fields.ContainsField(sPField.InternalName) && !list.DefaultView.ViewFields.Exists(sPField.InternalName))
            {
                SPView defaultView = list.DefaultView;
                defaultView.ViewFields.Add(sPField);
                defaultView.Update();
            }
        }




        /// <summary>
        /// Ajouter la colonne country
        /// </summary>
        /// <param name="currentWeb"></param>
        /// <param name="listWithLookup"></param>
        /// <param name="countryList"></param>
        internal static void AddFieldLookUpToCountryList(SPWeb currentWeb, SPDocumentLibrary listWithLookup, SPList countryList)
        {
            if (!listWithLookup.Fields.ContainsField(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME))
            {
                listWithLookup.Fields.AddLookup(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME, countryList.ID, true);
                listWithLookup.Update();

                SPFieldLookup fieldLookup = new SPFieldLookup(listWithLookup.Fields, Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME);
                fieldLookup.Title = Localization.Localization.Current.GetResource("Fields_CountriesConcernedDisplayName", "BNPPI.RE.DocsDSI.portal", 1036);
                fieldLookup.Title = Localization.Localization.Current.GetResource("Fields_CountriesConcernedDisplayName", "BNPPI.RE.DocsDSI.portal", 1033);

                fieldLookup.LookupField = countryList.Fields.GetField(Fields.SP_FIELDS_TITLE_INTERNALNAME).InternalName;
                fieldLookup.Update();
                listWithLookup.Update();

                SPView viewDefault = listWithLookup.DefaultView;
                viewDefault.ViewFields.Add(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME);
                viewDefault.Update();
            }
        }
    }

}

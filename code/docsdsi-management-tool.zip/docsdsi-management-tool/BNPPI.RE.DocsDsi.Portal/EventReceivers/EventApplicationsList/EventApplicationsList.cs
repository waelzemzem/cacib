﻿using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BNPPI.RE.DocsDsi.Portal.EventReceivers.EventApplicationsList
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class EventApplicationsList : SPItemEventReceiver
    {
        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            SPServiceContext currentContext = SPServiceContext.GetContext(properties.Site);
            using (SPSite site = new SPSite(properties.SiteId))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate
                    {
                        base.EventFiringEnabled = false;
                        //  MAJ du code projet 
                        #region RunFileArchitectureSchemeLibrary
                        SPDocumentLibrary RunFileArchitectureSchemeList = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.RUN_LIB_FILE_ARCHITECTURE_SCHEMA_DOCS_NAME)) as SPDocumentLibrary;
                        if (RunFileArchitectureSchemeList != null)
                        {
                            try

                            {
                                var listContentType = from c in RunFileArchitectureSchemeList.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID)) == true select c;
                                if (listContentType != null)
                                {
                                    string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(RunFileArchitectureSchemeList, properties, listContentType);
                                    SPFieldUrlValue hyper = new SPFieldUrlValue();
                                    hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                    hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                    properties.ListItem[Fields.RUN_FIELDS_ARCHI_SCHEMA_INTERNALNAME] = hyper;
                                    properties.ListItem.Update();
                                }
                            }
                            catch (Exception ex)
                            {
                                LogManager.LogError("[DOCS DSI] Error occurred," + Fields.RUN_FIELDS_ARCHI_SCHEMA_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                            }
                        }
                        #endregion

                        #region RunFileSchemeOfExploitationLibrary
                        SPDocumentLibrary RunFileSchemeOfExploitationList = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.RUN_LIB_FILE_SCHEMA_OF_EXPLOITATION_DOCS_NAME)) as SPDocumentLibrary;
                        if (RunFileSchemeOfExploitationList != null)
                        {
                            try
                            {
                                var listContentType = from c in RunFileSchemeOfExploitationList.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID)) == true select c;
                                if (listContentType != null)
                                {
                                    string urlRunSchemeOfExploitationFile = CreateDocumentsSetProjetInLibrary(RunFileSchemeOfExploitationList, properties, listContentType);
                                    SPFieldUrlValue hyper = new SPFieldUrlValue();
                                    hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                    hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunSchemeOfExploitationFile);
                                    properties.ListItem[Fields.RUN_FIELDS_SCHEMA_OF_EXPLOITATION_INTERNALNAME] = hyper;
                                    properties.ListItem.Update();

                                }
                            }
                            catch (Exception ex)
                            {
                                LogManager.LogError("[DOCS DSI] Error occurred," + Fields.RUN_FIELDS_SCHEMA_OF_EXPLOITATION_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                            }
                        }
                        #endregion

                        #region RunFileSchemeOfInstallationLibrary
                        SPDocumentLibrary RunFileSchemeOfInstallationList = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.RUN_LIB_FILE_SCHEMA_OF_INSTALATION_DOCS_NAME)) as SPDocumentLibrary;
                        if (RunFileSchemeOfInstallationList != null)
                        {
                            try
                            {
                                var listContentType = from c in RunFileSchemeOfInstallationList.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID)) == true select c;
                                if (listContentType != null)
                                {
                                    string urlRunSchemeOfInstallationFile = CreateDocumentsSetProjetInLibrary(RunFileSchemeOfInstallationList, properties, listContentType);

                                    SPFieldUrlValue hyper = new SPFieldUrlValue();
                                    hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                    hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunSchemeOfInstallationFile);
                                    properties.ListItem[Fields.RUN_FIELDS_SCHEMA_OF_INSTALLATION_INTERNALNAME] = hyper;
                                    properties.ListItem.Update();
                                }
                            }
                            catch (Exception ex)
                            {
                                LogManager.LogError("[DOCS DSI] Error occurred," + Fields.RUN_FIELDS_SCHEMA_OF_INSTALLATION_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                            }
                        }
                        #endregion

                        #region RunNonRegressionTestsBookLibrary
                        SPList RunNonRegressionTestsBookList = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.RUN_LIB_NON_REGRESSION_TESTS_BOOK_DOCS_NAME)) as SPDocumentLibrary;
                        if (RunNonRegressionTestsBookList != null)
                        {
                            try
                            {
                                var listContentType = from c in RunNonRegressionTestsBookList.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID)) == true select c;
                                if (listContentType != null)
                                {
                                    string urlRunNonRegressionTestsBookFile = CreateDocumentsSetProjetInLibrary(RunNonRegressionTestsBookList, properties, listContentType);
                                    SPFieldUrlValue hyper = new SPFieldUrlValue();
                                    hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                    hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunNonRegressionTestsBookFile);
                                    properties.ListItem[Fields.RUN_FIELDS_NON_REGRESSION_TESTBOOK_INTERNALNAME] = hyper;
                                    properties.ListItem.Update();
                                }
                            }
                            catch (Exception ex)
                            {
                                LogManager.LogError("[DOCS DSI] Error occurred," + Fields.RUN_FIELDS_NON_REGRESSION_TESTBOOK_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                            }
                        }
                        #endregion

                        #region RunSanityCheckApplicationLibrary

                        SPDocumentLibrary RunSanityCheckApplicationList = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.RUN_LIB_SANITY_CHECK_APPLICATION_DOCS_NAME)) as SPDocumentLibrary;
                        if (RunSanityCheckApplicationList != null)
                        {
                            try
                            {
                                var listContentType = from c in RunSanityCheckApplicationList.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID)) == true select c;
                                if (listContentType != null)
                                {
                                    string urlRunSanityCheckApplicationFile = CreateDocumentsSetProjetInLibrary(RunSanityCheckApplicationList, properties, listContentType);
                                    SPFieldUrlValue hyper = new SPFieldUrlValue();
                                    hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                    hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunSanityCheckApplicationFile);
                                    properties.ListItem[Fields.RUN_FIELDS_SANITY_CHECK_APPLICATION__INTERNALNAME] = hyper;
                                    properties.ListItem.Update();
                                }
                            }
                            catch (Exception ex)
                            {
                                LogManager.LogError("[DOCS DSI] Error occurred," + Fields.RUN_FIELDS_SANITY_CHECK_APPLICATION__INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                            }
                        }
                        #endregion

                        #region RunSecurityDocumentLibrary
                        SPDocumentLibrary RunSecurityDocumentList = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.RUN_LIB_SECURITY_DOCS_NAME)) as SPDocumentLibrary;
                        if (RunSecurityDocumentList != null)
                        {
                            try
                            {
                                var listContentType = from c in RunSecurityDocumentList.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID)) == true select c;
                                if (listContentType != null)
                                {
                                    string urlRunSecurityDocumentFile = CreateDocumentsSetProjetInLibrary(RunSecurityDocumentList, properties, listContentType);

                                    SPFieldUrlValue hyper = new SPFieldUrlValue();
                                    hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                    hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunSecurityDocumentFile);
                                    properties.ListItem[Fields.RUN_FIELDS_SECURITY_DOCS_INTERNALNAME] = hyper;
                                    properties.ListItem.Update();
                                }
                            }
                            catch (Exception ex)
                            {
                                LogManager.LogError("[DOCS DSI] Error occurred," + Fields.RUN_FIELDS_SECURITY_DOCS_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                            }
                        }
                        #endregion

                        #region RunSupportDocumentationLibrary
                        SPDocumentLibrary RunSupportDocumentationList = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.RUN_LIB_SUPPORT_DOCS_NAME)) as SPDocumentLibrary;
                        if (RunSupportDocumentationList != null)
                        {
                            try
                            {
                                var listContentType = from c in RunSupportDocumentationList.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID)) == true select c;
                                if (listContentType != null)
                                {
                                    string urlRunSupportDocumentationFile = CreateDocumentsSetProjetInLibrary(RunSupportDocumentationList, properties, listContentType);
                                    SPFieldUrlValue hyper = new SPFieldUrlValue();
                                    hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                    hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunSupportDocumentationFile);
                                    properties.ListItem[Fields.RUN_FIELDS_SUPPORT_DOCS_INTERNALNAME] = hyper;
                                    properties.ListItem.Update();
                                }
                            }
                            catch (Exception ex)
                            {
                                LogManager.LogError("[DOCS DSI] Error occurred," + Fields.RUN_FIELDS_SUPPORT_DOCS_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                            }
                        }
                        #endregion

                        #region RunOtherDocsLibrary
                        SPDocumentLibrary RunOtherDocsLibraryList = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.RUN_LIB_OTHER_DOCS_NAME)) as SPDocumentLibrary;
                        if (RunOtherDocsLibraryList != null)
                        {
                            try
                            {
                                var listContentType = from c in RunOtherDocsLibraryList.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID)) == true select c;
                                if (listContentType != null)
                                {
                                    string urlRunOrherDocumentsFile = CreateDocumentsSetProjetInLibrary(RunOtherDocsLibraryList, properties, listContentType);
                                    SPFieldUrlValue hyper = new SPFieldUrlValue();
                                    hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                    hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunOrherDocumentsFile);
                                    properties.ListItem[Fields.RUN_FIELDS_OTHER_DOCS_INTERNALNAME] = hyper;
                                    properties.ListItem.Update();
                                }
                            }
                            catch (Exception ex)
                            {
                                LogManager.LogError("[DOCS DSI] Error occurred," + Fields.RUN_FIELDS_OTHER_DOCS_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                            }
                        }
                        #endregion

                        #region RunUserGuideLibrary
                        SPDocumentLibrary RunUserGuideList = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.RUN_LIB_USER_GUIDE_DOCS_NAME)) as SPDocumentLibrary;
                        if (RunUserGuideList != null)
                        {
                            try
                            {
                                var listContentType = from c in RunUserGuideList.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID)) == true select c;
                                if (listContentType != null)
                                {
                                    string urlRunUserGuideFile = CreateDocumentsSetProjetInLibrary(RunUserGuideList, properties, listContentType);
                                    SPFieldUrlValue hyper = new SPFieldUrlValue();
                                    hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                    hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunUserGuideFile);
                                    properties.ListItem[Fields.RUN_FIELDS_USER_GUIDE_INTERNALNAME] = hyper;
                                    properties.ListItem.Update();
                                }
                            }
                            catch (Exception ex)
                            {
                                LogManager.LogError("[DOCS DSI] Error occurred," + Fields.RUN_FIELDS_USER_GUIDE_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                            }
                        }
                        #endregion

                        base.EventFiringEnabled = true;
                    });
                }
            }
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPWeb currentWeb = properties.OpenWeb())
                {
                    try
                    {
                        //currentWeb.AllowUnsafeUpdates = true;
                        //base.EventFiringEnabled = false;

                        LogManager.LogError("[DOCS DSI] Start ItemUpdating");


                        #region RunOtherDocsLibraryFolder
                        SPDocumentLibrary RunOtherDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, "RunOtherDocsLibrary")) as SPDocumentLibrary;
                        string RunOtherDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + "RunOtherDocsLibrary" + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder RunOtherDocsLibraryFolder = currentWeb.GetFolder(RunOtherDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, RunOtherDocsLibraryFolder, RunOtherDocsLibrary, properties, Fields.RUN_FIELDS_OTHER_DOCS_INTERNALNAME);
                        #endregion

                        #region RunFileArchitectureSchemeList
                        SPDocumentLibrary RunFileArchitectureSchemeList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, "RunFileArchitectureSchemeLibrary")) as SPDocumentLibrary;
                        string RunFileArchitectureSchemeListURL = currentWeb.ServerRelativeUrl + "/" + "RunFileArchitectureSchemeLibrary" + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder RunFileArchitectureSchemeLibraryFolder = currentWeb.GetFolder(RunFileArchitectureSchemeListURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, RunFileArchitectureSchemeLibraryFolder, RunFileArchitectureSchemeList, properties, Fields.RUN_FIELDS_ARCHI_SCHEMA_INTERNALNAME);
                        #endregion

                        #region RunFileSchemeOfExploitationList
                        SPDocumentLibrary RunFileSchemeOfExploitationList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, "RunFileSchemeOfExploitationLibrary")) as SPDocumentLibrary;
                        string RunFileSchemeOfExploitationListURL = currentWeb.ServerRelativeUrl + "/" + "RunFileSchemeOfExploitationLibrary" + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder RunFileSchemeOfExploitationLibraryFolder = currentWeb.GetFolder(RunFileSchemeOfExploitationListURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, RunFileSchemeOfExploitationLibraryFolder, RunFileSchemeOfExploitationList, properties, Fields.RUN_FIELDS_SCHEMA_OF_EXPLOITATION_INTERNALNAME);
                        #endregion

                        #region RunFileSchemeOfInstallationList
                        SPDocumentLibrary RunFileSchemeOfInstallationList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, "RunFileSchemeOfInstallationLibrary")) as SPDocumentLibrary;
                        string RunFileSchemeOfInstallationListURL = currentWeb.ServerRelativeUrl + "/" + "RunFileSchemeOfInstallationLibrary" + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder RunFileSchemeOfInstallationLibraryFolder = currentWeb.GetFolder(RunFileSchemeOfInstallationListURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, RunFileSchemeOfInstallationLibraryFolder, RunFileSchemeOfInstallationList, properties, Fields.RUN_FIELDS_SCHEMA_OF_INSTALLATION_INTERNALNAME);
                        #endregion

                        #region RunNonRegressionTestsBookList
                        SPDocumentLibrary RunNonRegressionTestsBookList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, "RunNonRegressionTestsBookLibrary")) as SPDocumentLibrary;
                        string RunNonRegressionTestsBookListURL = currentWeb.ServerRelativeUrl + "/" + "RunNonRegressionTestsBookLibrary" + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder RunNonRegressionTestsBookLibraryFolder = currentWeb.GetFolder(RunNonRegressionTestsBookListURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, RunNonRegressionTestsBookLibraryFolder, RunNonRegressionTestsBookList, properties, Fields.RUN_FIELDS_NON_REGRESSION_TESTBOOK_INTERNALNAME);
                        #endregion

                        #region RunSanityCheckApplicationList
                        SPDocumentLibrary RunSanityCheckApplicationList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, "RunSanityCheckApplicationLibrary")) as SPDocumentLibrary;
                        string RunSanityCheckApplicationListURL = currentWeb.ServerRelativeUrl + "/" + "RunSanityCheckApplicationLibrary" + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder RunSanityCheckApplicationLibraryFolder = currentWeb.GetFolder(RunSanityCheckApplicationListURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, RunSanityCheckApplicationLibraryFolder, RunSanityCheckApplicationList, properties, Fields.RUN_FIELDS_SANITY_CHECK_APPLICATION__INTERNALNAME);
                        #endregion

                        #region RunSecurityDocumentList
                        SPDocumentLibrary RunSecurityDocumentList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, "RunSecurityDocumentLibrary")) as SPDocumentLibrary;
                        string RunSecurityDocumentListURL = currentWeb.ServerRelativeUrl + "/" + "RunSecurityDocumentLibrary" + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder RunSecurityDocumentLibraryFolder = currentWeb.GetFolder(RunSecurityDocumentListURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, RunSecurityDocumentLibraryFolder, RunSecurityDocumentList, properties, Fields.RUN_FIELDS_SECURITY_DOCS_INTERNALNAME);
                        #endregion

                        #region RunSupportDocumentationList
                        SPDocumentLibrary RunSupportDocumentationList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, "RunSupportDocumentationLibrary")) as SPDocumentLibrary;
                        string RunSupportDocumentationListURL = currentWeb.ServerRelativeUrl + "/" + "RunSupportDocumentationLibrary" + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder RunSupportDocumentationLibraryFolder = currentWeb.GetFolder(RunSupportDocumentationListURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, RunSupportDocumentationLibraryFolder, RunSupportDocumentationList, properties, Fields.RUN_FIELDS_SUPPORT_DOCS_INTERNALNAME);
                        #endregion

                        #region RunUserGuideList
                        SPDocumentLibrary RunUserGuideList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, "RunUserGuideLibrary")) as SPDocumentLibrary;
                        string RunUserGuideListURL = currentWeb.ServerRelativeUrl + "/" + "RunUserGuideLibrary" + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder RunUserGuideLibraryFolder = currentWeb.GetFolder(RunUserGuideListURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, RunUserGuideLibraryFolder, RunUserGuideList, properties, Fields.RUN_FIELDS_USER_GUIDE_INTERNALNAME);
                        #endregion

                        #region Update Folder automatically in the differents libraries 
                        if (properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString() != properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString())
                        {
                            RenameDocumentsSetProjetInLibrary(RunFileArchitectureSchemeLibraryFolder, properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                            RenameDocumentsSetProjetInLibrary(RunFileSchemeOfExploitationLibraryFolder, properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                            RenameDocumentsSetProjetInLibrary(RunFileSchemeOfInstallationLibraryFolder, properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                            RenameDocumentsSetProjetInLibrary(RunNonRegressionTestsBookLibraryFolder, properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                            RenameDocumentsSetProjetInLibrary(RunSanityCheckApplicationLibraryFolder, properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                            RenameDocumentsSetProjetInLibrary(RunSecurityDocumentLibraryFolder, properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                            RenameDocumentsSetProjetInLibrary(RunSupportDocumentationLibraryFolder, properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                            RenameDocumentsSetProjetInLibrary(RunUserGuideLibraryFolder, properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                            RenameDocumentsSetProjetInLibrary(RunOtherDocsLibraryFolder, properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        LogManager.LogError("[DOCS DSI] Error occurred," + Fields.SP_FIELDS_TITLE_INTERNALNAME + " has not been ItemUpdated in " + properties.List.Title + ". Exception- " + ex.Message.ToString());
                    }
                }
            });
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPWeb currentWeb = properties.OpenWeb())
                {
                    try
                    {
                        LogManager.LogError("[DOCS DSI] Start ItemUpdated");

                        #region Update the Url link to libraries
                        SPFieldUrlValue hyperLinkSchemaArchi = new SPFieldUrlValue((properties.ListItem[Fields.RUN_FIELDS_ARCHI_SCHEMA_INTERNALNAME]).ToString());
                        hyperLinkSchemaArchi.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkSchemaArchi.Url = currentWeb.ServerRelativeUrl + "/" + "RunFileArchitectureSchemeLibrary" + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        properties.ListItem[Fields.RUN_FIELDS_ARCHI_SCHEMA_INTERNALNAME] = hyperLinkSchemaArchi;

                        SPFieldUrlValue hyperLinkSchemaExploitation = new SPFieldUrlValue((properties.ListItem[Fields.RUN_FIELDS_SCHEMA_OF_EXPLOITATION_INTERNALNAME]).ToString());
                        hyperLinkSchemaExploitation.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkSchemaExploitation.Url = currentWeb.ServerRelativeUrl + "/" + "RunFileSchemeOfExploitationLibrary" + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        properties.ListItem[Fields.RUN_FIELDS_SCHEMA_OF_EXPLOITATION_INTERNALNAME] = hyperLinkSchemaExploitation;

                        SPFieldUrlValue hyperLinkSchemaInstallation = new SPFieldUrlValue((properties.ListItem[Fields.RUN_FIELDS_SCHEMA_OF_INSTALLATION_INTERNALNAME]).ToString());
                        hyperLinkSchemaInstallation.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkSchemaInstallation.Url = currentWeb.ServerRelativeUrl + "/" + "RunFileSchemeOfInstallationLibrary" + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        properties.ListItem[Fields.RUN_FIELDS_SCHEMA_OF_INSTALLATION_INTERNALNAME] = hyperLinkSchemaInstallation;

                        SPFieldUrlValue hyperLinkNoRegressionTest = new SPFieldUrlValue((properties.ListItem[Fields.RUN_FIELDS_NON_REGRESSION_TESTBOOK_INTERNALNAME]).ToString());
                        hyperLinkNoRegressionTest.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkNoRegressionTest.Url = currentWeb.ServerRelativeUrl + "/" + "RunNonRegressionTestsBookLibrary" + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        properties.ListItem[Fields.RUN_FIELDS_NON_REGRESSION_TESTBOOK_INTERNALNAME] = hyperLinkNoRegressionTest;
                        /* *********** */
                        SPFieldUrlValue hyperLinkSanityCheckApplication = new SPFieldUrlValue((properties.ListItem[Fields.RUN_FIELDS_SANITY_CHECK_APPLICATION__INTERNALNAME]).ToString());
                        hyperLinkSanityCheckApplication.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkSanityCheckApplication.Url = currentWeb.ServerRelativeUrl + "/" + "RunSanityCheckApplicationLibrary" + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        properties.ListItem[Fields.RUN_FIELDS_SANITY_CHECK_APPLICATION__INTERNALNAME] = hyperLinkSanityCheckApplication;

                        SPFieldUrlValue hyperLinkSecurityDocs = new SPFieldUrlValue((properties.ListItem[Fields.RUN_FIELDS_SECURITY_DOCS_INTERNALNAME]).ToString());
                        hyperLinkSecurityDocs.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkSecurityDocs.Url = currentWeb.ServerRelativeUrl + "/" + "RunSecurityDocumentLibrary" + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        properties.ListItem[Fields.RUN_FIELDS_SECURITY_DOCS_INTERNALNAME] = hyperLinkSecurityDocs;

                        SPFieldUrlValue hyperLinkUserFieldsSupport = new SPFieldUrlValue((properties.ListItem[Fields.RUN_FIELDS_SUPPORT_DOCS_INTERNALNAME]).ToString());
                        hyperLinkUserFieldsSupport.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkUserFieldsSupport.Url = currentWeb.ServerRelativeUrl + "/" + "RunSupportDocumentationLibrary" + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        properties.ListItem[Fields.RUN_FIELDS_SUPPORT_DOCS_INTERNALNAME] = hyperLinkUserFieldsSupport;

                        SPFieldUrlValue hyperLinkUserGuide = new SPFieldUrlValue((properties.ListItem[Fields.RUN_FIELDS_USER_GUIDE_INTERNALNAME]).ToString());
                        hyperLinkUserGuide.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkUserGuide.Url = currentWeb.ServerRelativeUrl + "/" + "RunUserGuideLibrary" + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        properties.ListItem[Fields.RUN_FIELDS_USER_GUIDE_INTERNALNAME] = hyperLinkUserGuide;

                        SPFieldUrlValue hyperLinkRunOtherDocs = new SPFieldUrlValue();
                        hyperLinkRunOtherDocs.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkRunOtherDocs.Url = currentWeb.ServerRelativeUrl + "/" + "RunOtherDocsLibrary" + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        properties.ListItem[Fields.RUN_FIELDS_OTHER_DOCS_INTERNALNAME] = hyperLinkRunOtherDocs;

                        EventFiringEnabled = false;
                        properties.ListItem.SystemUpdate(false);
                        EventFiringEnabled = true;

                        LogManager.LogError("[DOCS DSI] END ItemUpdated");
                        #endregion

                    }
                    catch (SPException spEx)
                    {
                        LogManager.LogError("[DOCS DSI] Error occurred," + Fields.SP_FIELDS_TITLE_INTERNALNAME + " has not been ItemUpdated in " + properties.List.Title + ". Exception- " + spEx.Message.ToString());

                        if (!spEx.Message.ToLower().Contains("save conflict"))
                        {
                            throw spEx;
                        }
                    }
                    finally
                    {
                        //
                    }
                }
            });

        }

        ///// <summary>
        /// An item was deleted.
        /// </summary>
        public override void ItemDeleted(SPItemEventProperties properties)
        {
            base.ItemDeleted(properties);
        }

        private void CheckIfTheAppsFolderExistOrCreate(SPWeb currentWeb, SPFolder runFolder, SPDocumentLibrary runDocsLibrary, SPItemEventProperties properties, string runFieldsUrlToFolder)
        {
            string runUrl = String.Empty;
            if (!runFolder.Exists)
            {
                try
                {
                    var listContentType = from c in runDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID)) == true select c;
                    if (listContentType != null)
                    {
                        runUrl = CreateDocumentsSetProjetInLibrary(runDocsLibrary, properties, listContentType);
                        #region Old
                        //SPFieldUrlValue hyper = new SPFieldUrlValue();
                        //hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        //hyper.Url = SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, runUrl);
                        //properties.ListItem[runFieldsUrlToFolder] = hyper;
                        //properties.ListItem.Update(); 
                        #endregion
                    }
                }
                catch (Exception ex)
                {
                    LogManager.LogError("[DOCS DSI] Error occurred," + runFieldsUrlToFolder + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                }
            }
            // Update relatedApplication 
            //SPListItem itemJustAdded = runDocsLibrary.GetItemById(runFolder.Item.ID);
            //itemJustAdded[Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME] = properties.ListItem.ID; //properties.ListItemId;
            //itemJustAdded.Update();
        }

        /// <summary>
        /// Create document set in differents libraries 
        /// </summary>
        /// <param name="spList"></param>
        /// <param name="properties"></param>
        /// <param name="listContentType"></param>
        /// <returns></returns>
        private string CreateDocumentsSetProjetInLibrary(SPList spList, SPItemEventProperties properties, IEnumerable<SPContentType> listContentType)
        {
            try
            {
                string folderURL = SPUrlUtility.CombineUrl(spList.ParentWebUrl + "/" + spList.RootFolder.Url, properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                SPFolder folder = spList.ParentWeb.GetFolder(folderURL);
                if (folder.Exists)
                {
                    // Update the relatedApplication Col
                    SPListItem itemJustAdded = spList.GetItemById(folder.Item.ID);
                    itemJustAdded[Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME] = properties.ListItem.ID; //properties.ListItemId;
                    itemJustAdded.Update();
                    return itemJustAdded.Url;
                }
                else
                {
                    string urlfolder = spList.RootFolder.ServerRelativeUrl.ToString();
                    SPListItem item = spList.AddItem(urlfolder, SPFileSystemObjectType.Folder, properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                    item[Fields.SP_FIELDS_TITLE_INTERNALNAME] = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME];
                    item[Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME] = properties.ListItem.ID;
                    item[Fields.SP_FIELDS_CONTENT_TYPE_ID_INTERNALNAME] = listContentType.First().Id.ToString();
                    item.Update();
                    return item.Url;
                }

            }
            catch (SPException spEx)
            {
                LogManager.LogError("[DOCS DSI] Error occurred, file could not be created in " + spList.Title + ". Exception- " + spEx.Message.ToString());
            }
            return string.Empty;
        }

        /// <summary>
        /// Rebame documents set ile
        /// </summary>
        /// <param name="spFolder"></param>
        /// <param name="afterPropertiesName"></param>
        private void RenameDocumentsSetProjetInLibrary(SPFolder spFolder, string afterPropertiesName)
        {
            try
            {
                spFolder.Item["Name"] = afterPropertiesName;
                spFolder.Item.SystemUpdate(false);
            }
            catch (SPException spEx)
            {
                LogManager.LogError("[DOCS DSI] Error occurred, in RenameDocumentsSetProjetInLibrary function . Exception- " + spEx.Message.ToString());
            }
        }


    }
}
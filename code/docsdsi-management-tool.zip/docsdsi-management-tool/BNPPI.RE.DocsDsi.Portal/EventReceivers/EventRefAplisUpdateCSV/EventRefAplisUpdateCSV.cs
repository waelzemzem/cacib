﻿using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using System;
using System.IO;
using System.Security.Permissions;
using System.Text;

namespace BNPPI.RE.DocsDsi.Portal.EventReceivers.EventRefAplisUpdateCSV
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class EventRefAplisUpdateCSV : SPItemEventReceiver
    {
        /// <summary>
        /// An item is being added.
        /// </summary>
        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);
        }

        /// <summary>
        /// An item is being updated.
        /// </summary>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);
        }

        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            SPServiceContext currentContext = SPServiceContext.GetContext(properties.Site);
            using (SPSite site = new SPSite(properties.SiteId))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    // Update CSV 
                    //base.EventFiringEnabled = false;
                    UpdateRefAppsList(currentWeb, properties);
                    //base.EventFiringEnabled = true;
                }
            }
        }


        /// <summary>
        /// An item was updated.
        /// </summary>

        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            //SPSecurity.RunWithElevatedPrivileges(delegate ()
            //{
            using (SPSite site = new SPSite(properties.SiteId))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    //base.EventFiringEnabled = false;
                    UpdateRefAppsList(currentWeb, properties);
                    //base.EventFiringEnabled = true;
                }
            }
            //});
        }

        private void UpdateRefAppsList(SPWeb currentWeb, SPItemEventProperties properties)
        {
            // Update CSV 
            if (((properties.ListItem["Name"]).ToString().Contains(".csv")) && (properties.ListItem.File.ParentFolder.Name.Equals("RefApplis")) )
            {
                SPFile spfile = currentWeb.GetFile(currentWeb.Url + "/" + properties.ListItem.Url);
                char[] splitter = { ';' };

                SPFile logFile = null;

                ASCIIEncoding enc = new ASCIIEncoding();
                UnicodeEncoding uniEncoding = new UnicodeEncoding();
                StringBuilder errors = new StringBuilder();

                #region Init Log file Create log file in document Library
                //SPList lib = currentWeb.Lists.TryGetList("Documents");
                SPDocumentLibrary monitoringManagementLib = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.MINITORING_MANAGEMENT_LIB_NAME)) as SPDocumentLibrary;

                SPFolder folder = currentWeb.GetFolder(monitoringManagementLib.RootFolder.ServerRelativeUrl + "/Logs");

                string fileNameWithoutExtension = (properties.ListItem["Name"]).ToString().Substring(0, (properties.ListItem["Name"]).ToString().LastIndexOf('.'));
                string logFileName = folder.ServerRelativeUrl + ("/" + fileNameWithoutExtension + "_log_" + DateTime.Now.ToString("ddMMyyyy--HH-mm") + ".txt");

                using (var stream = new MemoryStream())
                {
                    using (var writer = new StreamWriter(stream))
                    {
                        writer.WriteLine("Ref Applis Update " + " FileName " + fileNameWithoutExtension + " " + DateTime.Now.ToString("ddMMyyyy--HH-mm"));
                        writer.Flush();
                        stream.Position = 0;
                        logFile = folder.Files.Add(logFileName, stream, true);
                    }
                }
                #endregion

                if (spfile.Exists)
                {
                    using (StreamReader reader = new StreamReader(spfile.OpenBinaryStream(), System.Text.Encoding.UTF7))
                    {
                        // Message Append
                        LogAppMessageRefApps(logFile, enc, "====================  [START] ===================");

                        reader.ReadLine();
                        string currentLine;

                        while ((currentLine = reader.ReadLine()) != null)
                        {
                            String[] Array = currentLine.ToString().Split(splitter);
                            if (Array.Length == 21)
                            {
                                try
                                {
                                    SPList myList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.APP_LIST_APPLICATIONS_NAME));

                                    #region GetOrUpdate File
                                    SPItem itemToUpdate = GetItemIfExistInSharePointList(currentWeb, "AppsList", FieldsRefApps.REF_APPS_FIELDS_ID_APPLICATION_INTERNALNAME, Array[0]);
                                    if (itemToUpdate != null)
                                    {
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_TITLE_INTERNALNAME] = Array[1];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_DESCRIPTION_INTERNALNAME] = Array[2];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_VERSION_INTERNALNAME] = Array[3];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_INTERNET_FACING_INTERNALNAME] = Array[4];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_PERSONA_DATA_INTERNALNAME] = Array[5];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_CONFIDENTIALITY_INTERNALNAME] = Array[6];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_INTEGRITY_INTERNALNAME] = Array[7];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_AVAIBILITY_INTERNALNAME] = Array[8];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_TRACEABILITY_INTERNALNAME] = Array[9];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_RTO_INTERNALNAME] = Array[10];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_RPO_INTERNALNAME] = Array[11];

                                        DateTime newdate;
                                        if (DateTime.TryParse(Array[12].ToString().Trim(), System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out newdate))
                                        {
                                            itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_LASTCIAT_INTERNALNAME] = newdate;
                                        }
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_CLASS_INTERNALNAME] = Array[13];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_AUTHENTIFICATION_INTERNALNAME] = Array[14];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_HOSTING_TYPE_INTERNALNAME] = Array[15];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_CLOUD_SERVICE_MODEL_INTERNALNAME] = Array[16];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_HOSTING_PROVIDER_INTERNALNAME] = Array[17];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_MANAGED_APPLICATION_INTERNALNAME] = Array[18];
                                        itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_STATUS_INTERNALNAME] = Array[19];

                                        int LookupIDitemToUpdate = GetLookupIDFromList(currentWeb, "ParamITResponsibleList", "Title", Array[20]);
                                        if (LookupIDitemToUpdate > 0)
                                        {
                                            SPFieldLookupValue spflv = new SPFieldLookupValue(LookupIDitemToUpdate, Array[20]);
                                            itemToUpdate[FieldsRefApps.REF_APPS_FIELDS_IT_RESPONSIBLE_INTERNALNAME] = spflv;
                                        }
                                        itemToUpdate.Update();
                                        // Message append file , item updated
                                        LogAppMessageRefApps(logFile, enc, "[" + Array[0] + "][UPDATED] => " + currentLine);
                                    }
                                    else
                                    {
                                        // Create the new application // Add new Item
                                        SPItem itemToAdd = myList.Items.Add();
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_ID_APPLICATION_INTERNALNAME] = Array[0];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_TITLE_INTERNALNAME] = Array[1];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_DESCRIPTION_INTERNALNAME] = Array[2];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_VERSION_INTERNALNAME] = Array[3];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_INTERNET_FACING_INTERNALNAME] = Array[4];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_PERSONA_DATA_INTERNALNAME] = Array[5];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_CONFIDENTIALITY_INTERNALNAME] = Array[6];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_INTEGRITY_INTERNALNAME] = Array[7];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_AVAIBILITY_INTERNALNAME] = Array[8];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_TRACEABILITY_INTERNALNAME] = Array[9];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_RTO_INTERNALNAME] = Array[10];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_RPO_INTERNALNAME] = Array[11];

                                        DateTime date;
                                        if (DateTime.TryParse(Array[12].ToString().Trim(), System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date))
                                        {
                                            itemToAdd[FieldsRefApps.REF_APPS_FIELDS_LASTCIAT_INTERNALNAME] = date;
                                        }
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_CLASS_INTERNALNAME] = Array[13];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_AUTHENTIFICATION_INTERNALNAME] = Array[14];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_HOSTING_TYPE_INTERNALNAME] = Array[15];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_CLOUD_SERVICE_MODEL_INTERNALNAME] = Array[16];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_HOSTING_PROVIDER_INTERNALNAME] = Array[17];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_MANAGED_APPLICATION_INTERNALNAME] = Array[18];
                                        itemToAdd[FieldsRefApps.REF_APPS_FIELDS_STATUS_INTERNALNAME] = Array[19];

                                        int LookupID = GetLookupIDFromList(currentWeb, "ParamITResponsibleList", "Title", Array[20]);
                                        if (LookupID > 0)
                                        {
                                            SPFieldLookupValue spflv = new SPFieldLookupValue(LookupID, Array[20]);
                                            itemToAdd[FieldsRefApps.REF_APPS_FIELDS_IT_RESPONSIBLE_INTERNALNAME] = spflv;
                                        }
                                        itemToAdd.Update();

                                        // Message Append
                                        LogAppMessageRefApps(logFile, enc, "[" + Array[0] + "][CREATED] => " + currentLine);
                                    }
                                    #endregion
                                }
                                catch (Exception ex)
                                {
                                    // Log the Error un the output in ULS SHarePoint
                                    LogManager.LogError("Feature Web_SwapMasterpage : Upload csv- " + ex.Message.ToString());

                                    // Message Append
                                    LogAppMessageRefApps(logFile, enc, "[" + Array[0] + "][IException] => " + currentLine + " \n " + ex.Message.ToString());
                                }
                            }
                            else
                            {
                                // Message Append
                                LogAppMessageRefApps(logFile, enc, "[" + Array[0] + "][INVALID format] => " + currentLine);
                            }
                        }
                        // Message Append
                        LogAppMessageRefApps(logFile, enc, "====================  [END] ===================");

                        #region Change Status Apps if the app is in sharepoint list and not find in csv 
                        SPList list = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, "Lists/" + "AppsList"));
                        SPListItemCollection items = list.Items;

                        foreach (SPListItem item in items)
                        {
                            bool itemInCsvFile = CheckIfItemExistInCsv(reader, item);
                            if (!itemInCsvFile)
                            {
                                // Change the status of the item
                                item[FieldsRefApps.REF_APPS_FIELDS_STATUS_INTERNALNAME] = "Decommissioned";
                                base.EventFiringEnabled = false;
                                item.Update();
                                base.EventFiringEnabled = true;

                                // Message Append
                                LogAppMessageRefApps(logFile, enc, "[" + item[FieldsRefApps.REF_APPS_FIELDS_ID_APPLICATION_INTERNALNAME].ToString() + "]" + "[Decommissioned]");
                            }
                        }
                        #endregion
                    }
                }
            }
        }

        /// <summary>
        /// Loger le traitement dans un fichier txt
        /// </summary>
        /// <param name="logFile"></param>
        /// <param name="enc"></param>
        /// <param name="logMessage"></param>
        private void LogAppMessageRefApps(SPFile logFile, ASCIIEncoding enc, string logMessage)
        {
            try
            {
                byte[] fileContentsStart = logFile.OpenBinary();
                string newContentsStartFormat = enc.GetString(fileContentsStart) + Environment.NewLine + logMessage;
                logFile.SaveBinary(enc.GetBytes(newContentsStartFormat));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        ///  Check if an app is in sharepoint list and not find in csv (to change the app Status) 
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        private bool CheckIfItemExistInCsv(StreamReader reader, SPListItem item)
        {
            reader.ReadLine();
            string currentLineToCheck;
            char[] splitter = { ';' };
            reader.BaseStream.Seek(0, System.IO.SeekOrigin.Begin);
            while ((currentLineToCheck = reader.ReadLine()) != null)
            {
                String[] Array = currentLineToCheck.ToString().Split(splitter);
                if (item[FieldsRefApps.REF_APPS_FIELDS_ID_APPLICATION_INTERNALNAME].ToString() == Array[0].ToString())
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        ///  Check if the item existe in SharePoint list
        /// </summary>
        /// <param name="currentweb"></param>
        /// <param name="strListName"></param>
        /// <param name="idAppColumnName"></param>
        /// <param name="csvValue"></param>
        /// <returns></returns>
        private SPItem GetItemIfExistInSharePointList(SPWeb currentweb, string strListName, string idAppColumnName, string csvValue)
        {
            try
            {
                SPList list = currentweb.GetList(SPUrlUtility.CombineUrl(currentweb.ServerRelativeUrl, "Lists/" + strListName));

                string strCAMLQuery = "<Where><Eq><FieldRef Name='" + idAppColumnName + "' /><Value Type='Text'>" + csvValue + "</Value></Eq></Where>";

                SPQuery query = new SPQuery();
                query.Query = strCAMLQuery;
                query.ViewFields = string.Concat(
                                        "<FieldRef Name='ID' />",
                                        "<FieldRef Name='" + idAppColumnName + "' />");
                SPListItemCollection items = list.GetItems(query);

                if (items.Count > 0)
                {
                    return items[0];
                }
                else
                {
                    return null;
                }
            }
            catch (SPException sPex)
            {

                return null;
            }
        }
        public static int GetLookupIDFromList(SPWeb currentweb, string strListName, string strLookupColumnName, string strLookupValue)
        {
            try
            {
                SPList list = currentweb.GetList(SPUrlUtility.CombineUrl(currentweb.ServerRelativeUrl, "Lists/" + strListName));

                string strCAMLQuery = "<Where><Eq><FieldRef Name='" + strLookupColumnName + "' /><Value Type='Text'>" + strLookupValue + "</Value></Eq></Where>";

                SPQuery query = new SPQuery();
                query.Query = strCAMLQuery;
                query.ViewFields = string.Concat(
                                        "<FieldRef Name='ID' />",
                                        "<FieldRef Name='" + strLookupColumnName + "' />");


                SPListItemCollection items = list.GetItems(query);

                if (items.Count > 0)
                {
                    int iRet = items[0].ID;
                    return iRet;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
    }
}
﻿using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using BNPPI.RE.DocsDsi.Portal.Utilities;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BNPPI.RE.DocsDsi.Portal.EventReceivers.EventProjectsList
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class EventProjectsList : SPItemEventReceiver
    {
        /// <summary>
        /// An item is being updated.
        /// </summary>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);

            //SPSecurity.RunWithElevatedPrivileges(delegate ()
            //{
            using (SPSite site = new SPSite(properties.SiteId))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    this.EventFiringEnabled = false;
                    //currentWeb.AllowUnsafeUpdates = true;
                    try
                    {


                        #region projectsCOMITDocsLibrary
                        SPDocumentLibrary projectsCOMITDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_COMIT_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsCOMITDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_COMIT_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsCOMITDocsLibraryFolder = currentWeb.GetFolder(projectsCOMITDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsCOMITDocsLibraryFolder, projectsCOMITDocsLibrary, properties, Fields.PROJET_FIELDS_COMIT_INTERNALNAME, ContentTypes.PROJECT_CT_COMIT_ID);
                        #endregion

                        #region projectsCMATDocsLibrary
                        SPDocumentLibrary projectsCMATDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_CMAT_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsCMATDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_CMAT_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsCMATDocsLibraryFilder = currentWeb.GetFolder(projectsCMATDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsCMATDocsLibraryFilder, projectsCMATDocsLibrary, properties, Fields.PROJET_FIELDS_CMAT_INTERNALNAME, ContentTypes.PROJECT_CT_CMAT_ID);
                        #endregion


                        #region projectsCvitDocsLibrary
                        SPDocumentLibrary projectsCvitDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_CVIT_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsCvitDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_CVIT_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsCvitDocsLibraryFolder = currentWeb.GetFolder(projectsCvitDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsCvitDocsLibraryFolder, projectsCvitDocsLibrary, properties, Fields.PROJET_FIELDS_CVIT_INTERNALNAME, ContentTypes.PROJECT_CT_CVIT_ID);
                        #endregion

                        #region projectsC2IDocsLibrary
                        SPDocumentLibrary projectsC2IDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_C2I_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsC2IDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_C2I_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsC2IDocsLibraryFolder = currentWeb.GetFolder(projectsC2IDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsC2IDocsLibraryFolder, projectsC2IDocsLibrary, properties, Fields.PROJET_FIELDS_C2I_INTERNALNAME, ContentTypes.PROJECT_CT_C2I_ID);
                        #endregion

                        #region Rename the folders


                        #region projectsIRPPDocsLibrary
                        SPDocumentLibrary projectsIRPPDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_IRPP_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsIRPPDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_IRPP_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsIRPPDocsLibraryFolder = currentWeb.GetFolder(projectsIRPPDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsIRPPDocsLibraryFolder, projectsIRPPDocsLibrary, properties, Fields.PROJET_FIELDS_IRPP_INTERNALNAME, ContentTypes.PROJECT_CT_CIRPP_ID);
                        #endregion

                        #region projectsDemandsDocsLibrary
                        SPDocumentLibrary projectsDemandsDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_DEMANDS_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsDemandsDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_DEMANDS_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsDemandsDocsLibraryFolder = currentWeb.GetFolder(projectsDemandsDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsDemandsDocsLibraryFolder, projectsDemandsDocsLibrary, properties, Fields.PROJET_FIELDS_DEMANDS_INTERNALNAME, ContentTypes.PROJECT_CT_DEMANDS_ID);
                        #endregion

                        #region projectsSpecificationsDocsLibrary
                        SPDocumentLibrary projectsSpecificationsDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_SPECIFICATION_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsSpecificationsDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_SPECIFICATION_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsSpecificationsDocsLibraryFolder = currentWeb.GetFolder(projectsSpecificationsDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsSpecificationsDocsLibraryFolder, projectsSpecificationsDocsLibrary, properties, Fields.PROJET_FIELDS_SPECIFICATION_INTERNALNAME, ContentTypes.PROJECT_CT_SPECIFICATION_ID);
                        #endregion

                        #region projectsReleaseNotesDocsLibrary
                        SPDocumentLibrary projectsReleaseNotesDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_RELEASE_NOTES_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsReleaseNotesDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_RELEASE_NOTES_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsReleaseNotesDocsLibraryFolder = currentWeb.GetFolder(projectsReleaseNotesDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsReleaseNotesDocsLibraryFolder, projectsReleaseNotesDocsLibrary, properties, Fields.PROJET_FIELDS_RELEASE_NOTES_INTERNALNAME, ContentTypes.PROJECT_CT_RELEASE_NOTES_ID);
                        #endregion

                        #region projectsTestsBookDocsLibrary
                        SPDocumentLibrary projectsTestsBookDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_TEST_BOOK_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsTestsBookDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_TEST_BOOK_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsTestsBookDocsLibraryFolder = currentWeb.GetFolder(projectsTestsBookDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsTestsBookDocsLibraryFolder, projectsTestsBookDocsLibrary, properties, Fields.PROJET_FIELDS_TESTS_BOOK_INTERNALNAME, ContentTypes.PROJECT_CT_TEST_BOOK_ID);
                        #endregion

                        #region projectsMinutesOfMeetingDocsLibrary
                        SPDocumentLibrary projectsMinutesOfMeetingDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_MINUTES_OF_METTING_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsMinutesOfMeetingDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_MINUTES_OF_METTING_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsMinutesOfMeetingDocsLibraryFolder = currentWeb.GetFolder(projectsMinutesOfMeetingDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsMinutesOfMeetingDocsLibraryFolder, projectsMinutesOfMeetingDocsLibrary, properties, Fields.PROJET_FIELDS_MINUTES_INTERNALNAME, ContentTypes.PROJECT_CT_MINUTES_OF_METTING_ID);
                        #endregion

                        #region projectsDeliveryCardsDocsList
                        SPDocumentLibrary projectsDeliveryCardsDocsList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_DELIVERY_CARDS_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsDeliveryCardsDocsListURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_DELIVERY_CARDS_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsDeliveryCardsDocsListFolder = currentWeb.GetFolder(projectsDeliveryCardsDocsListURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsDeliveryCardsDocsListFolder, projectsDeliveryCardsDocsList, properties, Fields.PROJET_FIELDS_DELIVERY_CARDS_INTERNALNAME, ContentTypes.PROJECT_CT_DELIVERY_CARDS_ID);
                        #endregion

                        #region projectsBalanceSheetDocsLibrary
                        SPDocumentLibrary projectsBalanceSheetDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_BALANCE_SHEET_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsBalanceSheetDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_BALANCE_SHEET_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsBalanceSheetDocsLibraryFolder = currentWeb.GetFolder(projectsBalanceSheetDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsBalanceSheetDocsLibraryFolder, projectsBalanceSheetDocsLibrary, properties, Fields.PROJET_FIELDS_BALANCESHEET_INTERNALNAME, ContentTypes.PROJECT_CT_BALANCE_SHEET_ID);
                        #endregion

                        #region projectsOtherDocsLibrary
                        SPDocumentLibrary projectsOtherDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_OTHER_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsOtherDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_OTHER_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsOtherDocsLibraryFolder = currentWeb.GetFolder(projectsOtherDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsOtherDocsLibraryFolder, projectsOtherDocsLibrary, properties, Fields.PROJET_FIELDS_OtherDOCS_INTERNALNAME, ContentTypes.PROJECT_CT_OTHER_ID);
                        #endregion

                        #region projectsCopilDocsLibrary
                        SPDocumentLibrary projectsCopilDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_COPIL_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsCopilDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_COPIL_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsCopilDocsLibraryFolder = currentWeb.GetFolder(projectsCopilDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsCopilDocsLibraryFolder, projectsCopilDocsLibrary, properties, Fields.PROJET_FIELDS_COPIL_INTERNALNAME, ContentTypes.PROJECT_CT_COPIL_ID);
                        #endregion


                        #region projectsSVCDocsLibrary
                        SPDocumentLibrary projectsSVCDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_SVC_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsSVCDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_SVC_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsSVCDocsLibraryFolder = currentWeb.GetFolder(projectsSVCDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsSVCDocsLibraryFolder, projectsSVCDocsLibrary, properties, Fields.PROJET_FIELDS_SVC_INTERNALNAME, ContentTypes.PROJECT_CT_SVC_ID);
                        #endregion


                        #region projectsIdCardDocsLibrary
                        SPDocumentLibrary projectsIdCardDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_IDCARD_DOCS_NAME)) as SPDocumentLibrary;
                        string projectsIdCardDocsLibraryURL = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_IDCARD_DOCS_NAME + "/" + properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        SPFolder projectsIdCardDocsLibraryFolder = currentWeb.GetFolder(projectsIdCardDocsLibraryURL);
                        CheckIfTheAppsFolderExistOrCreate(currentWeb, projectsIdCardDocsLibraryFolder, projectsIdCardDocsLibrary, properties, Fields.PROJET_FIELDS_IDCARD_INTERNALNAME, ContentTypes.PROJECT_CT_IDCARD_ID);
                        #endregion

                        // COPIL
                        string itemTitleAfterApdating = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();

                        if (properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString() != properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString())
                        {
                            RenameDocumentsSetProjetInLibrary(projectsCOMITDocsLibraryFolder, itemTitleAfterApdating);
                            RenameDocumentsSetProjetInLibrary(projectsCMATDocsLibraryFilder, itemTitleAfterApdating);
                            RenameDocumentsSetProjetInLibrary(projectsCvitDocsLibraryFolder, itemTitleAfterApdating);
                            RenameDocumentsSetProjetInLibrary(projectsC2IDocsLibraryFolder, itemTitleAfterApdating);

                            RenameDocumentsSetProjetInLibrary(projectsIRPPDocsLibraryFolder, itemTitleAfterApdating);
                            RenameDocumentsSetProjetInLibrary(projectsDemandsDocsLibraryFolder, itemTitleAfterApdating);
                            RenameDocumentsSetProjetInLibrary(projectsSpecificationsDocsLibraryFolder, itemTitleAfterApdating);
                            RenameDocumentsSetProjetInLibrary(projectsReleaseNotesDocsLibraryFolder, itemTitleAfterApdating);


                            RenameDocumentsSetProjetInLibrary(projectsTestsBookDocsLibraryFolder, itemTitleAfterApdating);
                            RenameDocumentsSetProjetInLibrary(projectsMinutesOfMeetingDocsLibraryFolder, itemTitleAfterApdating);
                            RenameDocumentsSetProjetInLibrary(projectsDeliveryCardsDocsListFolder, itemTitleAfterApdating);
                            RenameDocumentsSetProjetInLibrary(projectsBalanceSheetDocsLibraryFolder, itemTitleAfterApdating);
                            RenameDocumentsSetProjetInLibrary(projectsOtherDocsLibraryFolder, itemTitleAfterApdating);

                            // COPIL
                            RenameDocumentsSetProjetInLibrary(projectsCopilDocsLibraryFolder, itemTitleAfterApdating);

                            // SVC
                            RenameDocumentsSetProjetInLibrary(projectsSVCDocsLibraryFolder, itemTitleAfterApdating);
                             
                            // ID CARD
                            RenameDocumentsSetProjetInLibrary(projectsIdCardDocsLibraryFolder, itemTitleAfterApdating);
                        }
                        #endregion


                    }
                    catch (Exception ex)
                    {
                        LogManager.LogError("Feature : Error in Event Projects List - " + ex.Message.ToString());
                    }
                    finally
                    {
                        EventFiringEnabled = true;
                        // currentWeb.AllowUnsafeUpdates = false;
                    }
                }
            }
            //});
        }

        private void CheckIfTheAppsFolderExistOrCreate(SPWeb currentWeb, SPFolder runFolder, SPDocumentLibrary runDocsLibrary, SPItemEventProperties properties, string runFieldsUrlToFolder, string cTypeID)
        {
            string runUrl = String.Empty;
            if (!runFolder.Exists)
            {
                try
                {
                    var listContentType = from c in runDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(cTypeID)) == true select c;
                    if (listContentType != null)
                    {
                        runUrl = CreateDocumentsSetProjetInLibrary(runDocsLibrary, properties, listContentType);
                    }
                }
                catch (Exception ex)
                {
                    LogManager.LogError("[DOCS DSI] Error occurred," + runFieldsUrlToFolder + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                }
            }
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            using (SPSite site = new SPSite(properties.SiteId))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    try
                    {

                        #region Update the Url link to libraries

                        //SPListItem currentItem = properties.ListItem;
                        SPListItem currentItem = properties.List.Items.GetItemById(properties.ListItem.ID);

                        SPFieldUrlValue hyperLinkprojectsCOMITDocsLibrary = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_COMIT_INTERNALNAME]).ToString());
                        hyperLinkprojectsCOMITDocsLibrary.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsCOMITDocsLibrary.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_COMIT_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_COMIT_INTERNALNAME] = hyperLinkprojectsCOMITDocsLibrary;

                        SPFieldUrlValue hyperLinkprojectsCMATDocsLibrary = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_CMAT_INTERNALNAME]).ToString());
                        hyperLinkprojectsCMATDocsLibrary.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsCMATDocsLibrary.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_CMAT_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_CMAT_INTERNALNAME] = hyperLinkprojectsCMATDocsLibrary;


                        SPFieldUrlValue hyperLinkprojectsCvitDocsLibrary = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_CVIT_INTERNALNAME]).ToString());
                        hyperLinkprojectsCvitDocsLibrary.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsCvitDocsLibrary.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_CVIT_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_CVIT_INTERNALNAME] = hyperLinkprojectsCvitDocsLibrary;

                        SPFieldUrlValue hyperLinkprojectsC2IDocsLibrary = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_C2I_INTERNALNAME]).ToString());
                        hyperLinkprojectsC2IDocsLibrary.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsC2IDocsLibrary.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_C2I_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_C2I_INTERNALNAME] = hyperLinkprojectsC2IDocsLibrary;

                        /* *********** */
                        SPFieldUrlValue hyperLinkprojectsIRPPDocsLibrary = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_IRPP_INTERNALNAME]).ToString());
                        hyperLinkprojectsIRPPDocsLibrary.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsIRPPDocsLibrary.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_IRPP_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_IRPP_INTERNALNAME] = hyperLinkprojectsIRPPDocsLibrary;

                        SPFieldUrlValue hyperLinkprojectsDemandsDocsLibrary = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_DEMANDS_INTERNALNAME]).ToString());
                        hyperLinkprojectsDemandsDocsLibrary.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsDemandsDocsLibrary.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_DEMANDS_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_DEMANDS_INTERNALNAME] = hyperLinkprojectsDemandsDocsLibrary;

                        SPFieldUrlValue hyperLinkprojectsSpecificationsDocsLibrary = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_SPECIFICATION_INTERNALNAME]).ToString());
                        hyperLinkprojectsSpecificationsDocsLibrary.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsSpecificationsDocsLibrary.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_SPECIFICATION_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_SPECIFICATION_INTERNALNAME] = hyperLinkprojectsSpecificationsDocsLibrary;

                        SPFieldUrlValue hyperLinkprojectsReleaseNotesDocsLibrary = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_RELEASE_NOTES_INTERNALNAME]).ToString());
                        hyperLinkprojectsReleaseNotesDocsLibrary.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsReleaseNotesDocsLibrary.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_RELEASE_NOTES_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_RELEASE_NOTES_INTERNALNAME] = hyperLinkprojectsReleaseNotesDocsLibrary;


                        /* *********** */
                        SPFieldUrlValue hyperLinkprojectsTestsBookDocsLibraryURL = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_TESTS_BOOK_INTERNALNAME]).ToString());
                        hyperLinkprojectsTestsBookDocsLibraryURL.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsTestsBookDocsLibraryURL.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_TEST_BOOK_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_TESTS_BOOK_INTERNALNAME] = hyperLinkprojectsTestsBookDocsLibraryURL;


                        SPFieldUrlValue hyperLinkprojectsMinutesOfMeetingDocsLibraryURL = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_MINUTES_INTERNALNAME]).ToString());
                        hyperLinkprojectsMinutesOfMeetingDocsLibraryURL.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsMinutesOfMeetingDocsLibraryURL.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_MINUTES_OF_METTING_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_MINUTES_INTERNALNAME] = hyperLinkprojectsMinutesOfMeetingDocsLibraryURL;

                        SPFieldUrlValue hyperLinkprojectsDeliveryCardsDocsListURL = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_DELIVERY_CARDS_INTERNALNAME]).ToString());
                        hyperLinkprojectsDeliveryCardsDocsListURL.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsDeliveryCardsDocsListURL.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_DELIVERY_CARDS_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_DELIVERY_CARDS_INTERNALNAME] = hyperLinkprojectsDeliveryCardsDocsListURL;

                        SPFieldUrlValue hyperLinkprojectsBalanceSheetDocsLibraryURL = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_BALANCESHEET_INTERNALNAME]).ToString());
                        hyperLinkprojectsBalanceSheetDocsLibraryURL.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsBalanceSheetDocsLibraryURL.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_BALANCE_SHEET_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_BALANCESHEET_INTERNALNAME] = hyperLinkprojectsBalanceSheetDocsLibraryURL;

                        SPFieldUrlValue hyperLinkprojectsOtherDocsLibraryURL = new SPFieldUrlValue((properties.ListItem[Fields.PROJET_FIELDS_OtherDOCS_INTERNALNAME]).ToString());
                        hyperLinkprojectsOtherDocsLibraryURL.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        hyperLinkprojectsOtherDocsLibraryURL.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_OTHER_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                        currentItem[Fields.PROJET_FIELDS_OtherDOCS_INTERNALNAME] = hyperLinkprojectsOtherDocsLibraryURL;

                        // Update solution , add new space ,
                        // COPIL
                        if ((currentItem[Fields.PROJET_FIELDS_COPIL_INTERNALNAME] != null))
                        {
                            SPFieldUrlValue hyperLinkprojectsCopilDocsLibraryURL = new SPFieldUrlValue((currentItem[Fields.PROJET_FIELDS_COPIL_INTERNALNAME]).ToString());
                            hyperLinkprojectsCopilDocsLibraryURL.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            hyperLinkprojectsCopilDocsLibraryURL.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_COPIL_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            currentItem[Fields.PROJET_FIELDS_COPIL_INTERNALNAME] = hyperLinkprojectsCopilDocsLibraryURL;
                        }
                        else
                        {
                            SPFieldUrlValue hyperLinkprojectsCopilDocsLibraryURL = new SPFieldUrlValue();
                            hyperLinkprojectsCopilDocsLibraryURL.Description = currentItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            hyperLinkprojectsCopilDocsLibraryURL.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_COPIL_DOCS_NAME + "/" + currentItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            currentItem[Fields.PROJET_FIELDS_COPIL_INTERNALNAME] = hyperLinkprojectsCopilDocsLibraryURL;

                        }

                        // SVC
                        if ((currentItem[Fields.PROJET_FIELDS_SVC_INTERNALNAME] != null))
                        {
                            SPFieldUrlValue hyperLinkprojectsSVCDocsLibraryURL = new SPFieldUrlValue((currentItem[Fields.PROJET_FIELDS_SVC_INTERNALNAME]).ToString());
                            hyperLinkprojectsSVCDocsLibraryURL.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            hyperLinkprojectsSVCDocsLibraryURL.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_SVC_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            currentItem[Fields.PROJET_FIELDS_SVC_INTERNALNAME] = hyperLinkprojectsSVCDocsLibraryURL;
                        }
                        else
                        {
                            SPFieldUrlValue hyperLinkprojectsSVCDocsLibraryURL = new SPFieldUrlValue();
                            hyperLinkprojectsSVCDocsLibraryURL.Description = currentItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            hyperLinkprojectsSVCDocsLibraryURL.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_SVC_DOCS_NAME + "/" + currentItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            currentItem[Fields.PROJET_FIELDS_SVC_INTERNALNAME] = hyperLinkprojectsSVCDocsLibraryURL;
                        }



                        // ID CARD
                        if ((currentItem[Fields.PROJET_FIELDS_IDCARD_INTERNALNAME] != null))
                        {
                            SPFieldUrlValue hyperLinkprojectsIDCardDocsLibraryURL = new SPFieldUrlValue((currentItem[Fields.PROJET_FIELDS_IDCARD_INTERNALNAME]).ToString());
                            hyperLinkprojectsIDCardDocsLibraryURL.Description = properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            hyperLinkprojectsIDCardDocsLibraryURL.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_IDCARD_DOCS_NAME + "/" + properties.AfterProperties[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            currentItem[Fields.PROJET_FIELDS_IDCARD_INTERNALNAME] = hyperLinkprojectsIDCardDocsLibraryURL;
                        }
                        else
                        {
                            SPFieldUrlValue hyperLinkprojectsIDCardDocsLibraryURL = new SPFieldUrlValue();
                            hyperLinkprojectsIDCardDocsLibraryURL.Description = currentItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            hyperLinkprojectsIDCardDocsLibraryURL.Url = currentWeb.ServerRelativeUrl + "/" + Lists.PROJECT_LIB_IDCARD_DOCS_NAME + "/" + currentItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                            currentItem[Fields.PROJET_FIELDS_IDCARD_INTERNALNAME] = hyperLinkprojectsIDCardDocsLibraryURL;
                        }

                        currentItem.SystemUpdate(false);
                        #endregion


                    }
                    catch (Exception ex)
                    {
                        LogManager.LogError("Feature : Error in Event Projects List - " + ex.Message.ToString());
                    }
                }
            }
        }

        /// <summary>
        /// Rebame documents set ile
        /// </summary>
        /// <param name="spFolder"></param>
        /// <param name="afterPropertiesName"></param>
        private void RenameDocumentsSetProjetInLibrary(SPFolder spFolder, string afterPropertiesName)
        {
            try
            {
                spFolder.Item["Name"] = afterPropertiesName;
                spFolder.Item.SystemUpdate(false);

            }
            catch (Exception ex)
            {
                LogManager.LogError("[DOCS DSI] Error occurred, in RenameDocumentsSetProjetInLibrary function . Exception- " + ex.Message.ToString());
            }
        }

        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            SPServiceContext currentContext = SPServiceContext.GetContext(properties.Site);
            using (SPSite site = new SPSite(properties.SiteId))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    #region  Ajouter le code projet
                    EventFiringEnabled = false;
                    properties.ListItem[Fields.PROJET_FIELDS_IDPROJECT_INTERNALNAME] = "ID@" + properties.ListItemId;
                    properties.ListItem.SystemUpdate(false);
                    EventFiringEnabled = true;
                    #endregion

                    #region ProjectsCOMITDocsLibrary
                    SPDocumentLibrary projectsCOMITDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_COMIT_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsCOMITDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsCOMITDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_COMIT_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsCOMITDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_COMIT_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + Fields.PROJET_FIELDS_COMIT_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsCMATDocsLibrary
                    SPList projectsCMATDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_CMAT_DOCS_NAME));
                    if (projectsCMATDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsCMATDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_CMAT_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsCMATDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_CMAT_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + Fields.PROJET_FIELDS_CMAT_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsCvitDocsLibrary
                    SPList projectsCvitDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_CVIT_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsCvitDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsCvitDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_CVIT_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsCvitDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_CVIT_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + Fields.PROJET_FIELDS_CVIT_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsC2IDocsLibrary
                    SPDocumentLibrary projectsC2IDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_C2I_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsC2IDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsC2IDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_C2I_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsC2IDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_C2I_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + Fields.PROJET_FIELDS_C2I_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsIRPPDocsLibrary
                    SPDocumentLibrary projectsIRPPDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_IRPP_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsIRPPDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsIRPPDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_CIRPP_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsIRPPDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_IRPP_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + properties.ListItem[Fields.PROJET_FIELDS_IRPP_INTERNALNAME] + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsDemandsDocsLibrary

                    SPList projectsDemandsDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_DEMANDS_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsDemandsDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsDemandsDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_DEMANDS_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsDemandsDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_DEMANDS_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + properties.ListItem[Fields.PROJET_FIELDS_DEMANDS_INTERNALNAME] + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsSpecificationsDocsLibrary
                    SPList projectsSpecificationsDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_SPECIFICATION_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsSpecificationsDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsSpecificationsDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_SPECIFICATION_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsSpecificationsDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_SPECIFICATION_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + properties.ListItem[Fields.PROJET_FIELDS_SPECIFICATION_INTERNALNAME] + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsReleaseNotesDocsLibrary
                    SPList projectsReleaseNotesDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_RELEASE_NOTES_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsReleaseNotesDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsReleaseNotesDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_RELEASE_NOTES_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsReleaseNotesDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_RELEASE_NOTES_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + properties.ListItem[Fields.PROJET_FIELDS_RELEASE_NOTES_INTERNALNAME] + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsTestsBookDocsLibrary
                    SPList projectsTestsBookDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_TEST_BOOK_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsTestsBookDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsTestsBookDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_TEST_BOOK_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsTestsBookDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_TESTS_BOOK_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + properties.ListItem[Fields.PROJET_FIELDS_TESTS_BOOK_INTERNALNAME] + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsMinutesOfMeetingDocsLibrary
                    SPList projectsMinutesOfMeetingDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_MINUTES_OF_METTING_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsMinutesOfMeetingDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsMinutesOfMeetingDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_MINUTES_OF_METTING_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsMinutesOfMeetingDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_MINUTES_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + properties.ListItem[Fields.PROJET_FIELDS_MINUTES_INTERNALNAME] + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsDeliveryCardsDocsLibrary
                    SPList projectsDeliveryCardsDocsList = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_DELIVERY_CARDS_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsDeliveryCardsDocsList != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsDeliveryCardsDocsList.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_DELIVERY_CARDS_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsDeliveryCardsDocsList, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_DELIVERY_CARDS_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + properties.ListItem[Fields.PROJET_FIELDS_DELIVERY_CARDS_INTERNALNAME] + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsBalanceSheetDocsLibrary
                    SPList projectsBalanceSheetDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_BALANCE_SHEET_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsBalanceSheetDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsBalanceSheetDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_BALANCE_SHEET_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsBalanceSheetDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_BALANCESHEET_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;

                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + Fields.PROJET_FIELDS_BALANCESHEET_INTERNALNAME + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsOtherDocsLibrary
                    SPList projectsOtherDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_OTHER_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsOtherDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsOtherDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_OTHER_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlRunArchitectureSchemeFile = CreateDocumentsSetProjetInLibrary(projectsOtherDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlRunArchitectureSchemeFile);
                                properties.ListItem[Fields.PROJET_FIELDS_OtherDOCS_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + properties.ListItem[Fields.PROJET_FIELDS_OtherDOCS_INTERNALNAME] + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsCOPITDocsLibrary
                    SPDocumentLibrary projectsCopilDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_COPIL_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsCopilDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsCopilDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_COPIL_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlCopil = CreateDocumentsSetProjetInLibrary(projectsCopilDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlCopil);
                                properties.ListItem[Fields.PROJET_FIELDS_COPIL_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + properties.ListItem[Fields.PROJET_FIELDS_COPIL_INTERNALNAME] + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsSVCDocsLibrary
                    SPDocumentLibrary projectsSVCDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_SVC_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsCopilDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsSVCDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_SVC_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlCopil = CreateDocumentsSetProjetInLibrary(projectsSVCDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlCopil);
                                properties.ListItem[Fields.PROJET_FIELDS_SVC_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + properties.ListItem[Fields.PROJET_FIELDS_SVC_INTERNALNAME] + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region ProjectsSVCDocsLibrary
                    SPDocumentLibrary projectsIDCardDocsLibrary = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, Lists.PROJECT_LIB_IDCARD_DOCS_NAME)) as SPDocumentLibrary;
                    if (projectsCopilDocsLibrary != null)
                    {
                        try
                        {
                            var listContentType = from c in projectsIDCardDocsLibrary.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_IDCARD_ID)) == true select c;
                            if (listContentType != null)
                            {
                                string urlCopil = CreateDocumentsSetProjetInLibrary(projectsIDCardDocsLibrary, properties, listContentType);
                                EventFiringEnabled = false;
                                SPFieldUrlValue hyper = new SPFieldUrlValue();
                                hyper.Description = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString();
                                hyper.Url = SPUrlUtility.CombineUrl(web.ServerRelativeUrl, urlCopil);
                                properties.ListItem[Fields.PROJET_FIELDS_IDCARD_INTERNALNAME] = hyper;
                                properties.ListItem.SystemUpdate(false);
                                EventFiringEnabled = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            LogManager.LogError("[DOCS DSI] Error occurred," + properties.ListItem[Fields.PROJET_FIELDS_IDCARD_INTERNALNAME] + " has not been updated in " + properties.List.Title + ". Exception- " + ex.ToString());
                        }
                    }
                    #endregion

                    #region Send Notification 
                    SPList paramEmailTemplates = web.GetList(SPUrlUtility.CombineUrl(web.ServerRelativeUrl, "Lists/ParamEmailTemplates")) as SPDocumentLibrary;
                    //SPItem templateItem = GetGetEmailTemplate(web, paramEmailTemplates, properties.ListItem);

                    // EmailTemplateDocsDsi mailTemplate = GetGetEmailTemplate(web, "Project");
                    string DispFormURL = properties.ListItem.Web.Url + "/" + Lists.APP_LIST_PROJECTS_NAME + "/DispForm.aspx?ID=" + properties.ListItemId;

                    SPFieldUser userFieldToContact = (SPFieldUser)properties.ListItem.Fields.GetField("ToContact");
                    SPFieldUserValueCollection toContactuserFieldValueCollection = (SPFieldUserValueCollection)userFieldToContact.GetFieldValue(properties.ListItem["ToContact"].ToString());
                    string usersStr = String.Empty;
                    foreach (SPFieldUserValue userValue in toContactuserFieldValueCollection)
                    {
                        usersStr += (userValue.LookupValue + ", ");
                    }

                    //Set mail body  
                    string bodyText = string.Empty;
                    string header = "Bonjour," + "<br />" + "<br />";
                    string body = "Nous vous informons que l'espace projet a été créé, cliquez ici <a href =\""
                                    + DispFormURL + " \"" + "target=\"_blank\" >" + properties.ListItem["Title"].ToString() + "</a>"
                                    + "<br />"
                                    + ""
                                    + "<br /> ";
                    string footer = "Pour tout complément d'information, veuillez contacter " + usersStr + "." + "<br />"
                                  + "Meilleures salutations," + "<br />" + "\n";


                    bodyText = header + body + footer;
                    string subject = "Nouveau espace projet";

                    if (properties.ListItem[Fields.PROJECTS_LIST_FIELDS_TO_NOTIFY_INTERNALNAME] != null)
                    {
                        string fieldValue = properties.ListItem[Fields.PROJECTS_LIST_FIELDS_TO_NOTIFY_INTERNALNAME].ToString();
                        SPFieldUserValueCollection users = new SPFieldUserValueCollection(web, fieldValue);
                        SPFieldUser userField = (SPFieldUser)properties.ListItem.Fields.GetField(Fields.PROJECTS_LIST_FIELDS_TO_NOTIFY_INTERNALNAME);
                        SPFieldUserValueCollection userFieldValueCollection = (SPFieldUserValueCollection)userField.GetFieldValue(properties.ListItem[Fields.PROJECTS_LIST_FIELDS_TO_NOTIFY_INTERNALNAME].ToString());

                        foreach (SPFieldUserValue userValue in users)
                        {
                            Email.SendEmail(userValue.User.Email, "", subject, bodyText, web);
                        }
                    }
                    #endregion
                }
            }
        }
       
        #region Private functions
        private string CreateDocumentsSetProjetInLibrary(SPList spList, SPItemEventProperties properties, IEnumerable<SPContentType> listContentType)
        {
            try
            {
                string folderURL = SPUrlUtility.CombineUrl(spList.ParentWebUrl + "/" + spList.RootFolder.Url, properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                SPFolder folder = spList.ParentWeb.GetFolder(folderURL);
                if (folder.Exists)
                {
                    // Update the relatedApplication Col
                    SPListItem itemJustAdded = spList.GetItemById(folder.Item.ID);
                    itemJustAdded[Fields.PROJECTS_LIST_FIELDS_PROJECT_NAME_INTERNALNAME] = properties.ListItem.ID; //properties.ListItemId;
                    itemJustAdded.Update();
                    return itemJustAdded.Url;
                }
                else
                {
                    string urlfolder = spList.RootFolder.ServerRelativeUrl.ToString();
                    SPListItem item = spList.AddItem(urlfolder, SPFileSystemObjectType.Folder, properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME].ToString());
                    item[Fields.SP_FIELDS_TITLE_INTERNALNAME] = properties.ListItem[Fields.SP_FIELDS_TITLE_INTERNALNAME];
                    item[Fields.PROJECTS_LIST_FIELDS_PROJECT_NAME_INTERNALNAME] = properties.ListItemId;
                    item[Fields.SP_FIELDS_CONTENT_TYPE_ID_INTERNALNAME] = listContentType.First().Id.ToString();
                    item.Update();
                    return item.Url;
                }

            }
            catch (SPException spEx)
            {
                LogManager.LogError("[DOCS DSI] Error occurred, file could not be created in " + spList.Title + ". Exception- " + spEx.ToString());
            }
            return string.Empty;
        }

        private SPItem GetGetEmailTemplate(SPWeb web, SPList paramEmailTemplates, SPListItem listItem)
        {
            foreach (SPItem item in paramEmailTemplates.Items)
            {
                if (item[""].ToString() == "Projet")
                {
                    return item;

                }
            }
            return null;
        }
        #endregion

        /// <summary>
        /// An item was deleted.
        /// </summary>
        public override void ItemDeleted(SPItemEventProperties properties)
        {
            base.ItemDeleted(properties);
        }
    }
}
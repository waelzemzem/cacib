using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using BNPPI.RE.DocsDsi.Portal.Extensions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace BNPPI.RE.DocsDsi.Portal.Features.DocsDsi___Web_Lists_instances___Run
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("3b600657-5e37-4898-9eea-462ebe92a7c3")]
    public class DocsDsi___Web_Lists_instances___RunEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            if (properties == null)
                return;


            if (properties.Feature == null)
                return;

            if (properties.Feature.Parent == null)
                return;

            if (!(properties.Feature.Parent is SPWeb))
                return;

            using (SPWeb currentWeb = (SPWeb)properties.Feature.Parent)
            {
                try
                {
                    currentWeb.AllowUnsafeUpdates = true;

                    #region Pour forcer le fichier de ressource pour la description, probl�me il prend la variable au d�ploiement
                    var cTypeslibProcedures = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.APP_CT_PROCEDURE_DOC_SET_ID)) == true select c;

                    cTypeslibProcedures.First().Description = Localization.Localization.Current.GetResource("ContentTypes_AppProceduresDocsSetsDescription", "BNPPI.RE.DocsDSI.portal", 1036);
                    cTypeslibProcedures.First().Update();

                    var cTypeslibGeneralInfo = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.APP_CT_GENERAL_INFORMATIONS_DOCS_SET_ID)) == true select c;

                    cTypeslibGeneralInfo.First().Description = Localization.Localization.Current.GetResource("ContentTypes_GeneralInformationsDocSetDescription", "BNPPI.RE.DocsDSI.portal", 1036);
                    cTypeslibGeneralInfo.First().Update(); 
                    #endregion



                    SPList listParamRolesFunctionsList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.APP_LIST_PARAM_ROLE_FUNCTIONS_NAME));
                    // Ajouter la colonne pays
                    SPList listCountry = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.APP_LIST_Param_COUNTRY_NAME));
                  
                    #region  Biblioth�que de documents Proc�dures, ajouter le type de contenu, les colonnes statut du document, commentaire, pays concern�s 
                    SPDocumentLibrary libProcedures = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.APP_LIB_PROCEDURE_DOCS_NAME)) as SPDocumentLibrary;
                    SPContentType cTypes_libProcedures = currentWeb.AvailableContentTypes[new SPContentTypeId(ContentTypes.APP_CT_PROCEDURE_DOC_SET_ID)];

                    SPWebExtensions.AddContentTypeToLibraryById(currentWeb, libProcedures, cTypes_libProcedures);

                    // Ajouter la colonne document status
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libProcedures, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_DOCUMENT_STATUS_INTERNALNAME), true);

                    // Ajouter la colonne comment
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libProcedures, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COMMENT_INTERNALNAME), false);

                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libProcedures, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME), true);

                    //SPWebExtensions.AddFieldLookUpToCountryList(currentWeb, libProcedures, listCountry);
                    #endregion

                    #region Biblioth�que de document informations g�n�rales, ajouter le type de contenu, les colonnes statut du document, commentaire, pays concern�s 
                    SPDocumentLibrary libInformationGeneral = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.APP_LIB_GENERAL_INFORMATION_DOCS_NAME)) as SPDocumentLibrary;
                    SPContentType cTypes_libInformationGeneral = currentWeb.AvailableContentTypes[new SPContentTypeId(ContentTypes.APP_CT_GENERAL_INFORMATIONS_DOCS_SET_ID)];
                    SPWebExtensions.AddContentTypeToLibraryById(currentWeb, libInformationGeneral, cTypes_libInformationGeneral);
                    // Ajouter la colonne document status
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libInformationGeneral, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_DOCUMENT_STATUS_INTERNALNAME), true);

                    // Ajouter la colonne pays
                    //SPWebExtensions.AddFieldLookUpToCountryList(currentWeb, libInformationGeneral, listCountry);
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libInformationGeneral, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME), true);

                    // Ajouter la colonne comment
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libInformationGeneral, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COMMENT_INTERNALNAME), false);
                    #endregion

                    #region Biblioth�que de documents template, ajouter le type de contenu, les colonnes statut du document, commentaire, pays concern�s 
                    SPDocumentLibrary libTemplate = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.APP_LIB_TEMPLATES_DOCS_NAME)) as SPDocumentLibrary;
                    // Ajouter la colonne document status
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libTemplate, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_DOCUMENT_STATUS_INTERNALNAME), true);

                    // Ajouter la colonne pays
                    // SPWebExtensions.AddFieldLookUpToCountryList(currentWeb, libTemplate, listCountry);
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libTemplate, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME), true);

                    // Ajouter la colonne Language 
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libTemplate, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_LANGUAGE_INTERNALNAME), true);

                    // Ajouter la colonne comment
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libTemplate, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COMMENT_INTERNALNAME), false);
                    #endregion

                    #region Biblioth�que de document Application mapping, les colonnes statut du document, commentaire, pays concern�s 
                    SPDocumentLibrary libApplicationMapping = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.APP_LIB_APPLICATION_MAPPING_NAME)) as SPDocumentLibrary;

                    // Ajouter la colonne document status
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libApplicationMapping, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_DOCUMENT_STATUS_INTERNALNAME), true);

                    // Ajouter la colonne pays
                    // SPWebExtensions.AddFieldLookUpToCountryList(currentWeb, libApplicationMapping, listCountry);
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libApplicationMapping, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME), true);

                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libApplicationMapping, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_BUSNESSKINE_AND_FUNCTION_INTERNALNAME), true);

                    // Ajouter la colonne comment
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, libApplicationMapping, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COMMENT_INTERNALNAME), false);

                    #endregion

                    // ajouter le type de contenu document set aux biblioth�ques Runs
                    // List ref Application 
                    SPList applicationsList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.APP_LIST_APPLICATIONS_NAME));

                    // Content Type Run Document Set  
                    SPContentTypeId CtypeID_runDocumentsSet = new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID);
                    SPContentType CType_runDocumentsSet= currentWeb.AvailableContentTypes[CtypeID_runDocumentsSet];
                   
                    #region Ajouter la colonne application li�e au type de contenu documents set 


                    var siteColApplication = currentWeb.Fields.GetFieldByInternalName(Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME);
                    SPFieldLink fieldLinkApplication = new SPFieldLink(siteColApplication);
                    if (CType_runDocumentsSet.FieldLinks[Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME] == null)
                    {
                        currentWeb.ContentTypes[CType_runDocumentsSet.Id].FieldLinks.Add(fieldLinkApplication);
                        currentWeb.ContentTypes[CType_runDocumentsSet.Id].Update();
                    }
                    #endregion

                    #region Ajouter les colonnes M�tier / Fonction et Pays au type de contenu document pour les biblioth�ques Runs

                    SPContentTypeId cTypesID_runDocsTemplateCT = new SPContentTypeId("0x010100359290F302344266A4C01A3D53438C6D");
                    SPContentType cTypes_runDocsTemplateCT = currentWeb.AvailableContentTypes[cTypesID_runDocsTemplateCT];

                    //Ajouter la colonne Busness line
                    var siteColBusnessLine = currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_BUSNESSKINE_AND_FUNCTION_INTERNALNAME);
                    SPFieldLink fieldLinkBusnessLine = new SPFieldLink(siteColBusnessLine);
                    if (cTypes_runDocsTemplateCT.FieldLinks[Fields.FIELDS_COMMON_COL_BUSNESSKINE_AND_FUNCTION_INTERNALNAME] == null)
                    {
                        currentWeb.ContentTypes[cTypes_runDocsTemplateCT.Id].FieldLinks.Add(fieldLinkBusnessLine);
                        currentWeb.ContentTypes[cTypes_runDocsTemplateCT.Id].Update();
                    }

                    var siteColCountry = currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME);
                    SPFieldLink fieldLinkCountry = new SPFieldLink(siteColCountry);
                    if (cTypes_runDocsTemplateCT.FieldLinks[Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME] == null)
                    {
                        currentWeb.ContentTypes[cTypes_runDocsTemplateCT.Id].FieldLinks.Add(fieldLinkCountry);
                        currentWeb.ContentTypes[cTypes_runDocsTemplateCT.Id].Update();
                    }

                    #endregion


                    var CType_WithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.RUN_CT_COMMON_DOCS_SET_ID)) == true select c;

                    #region Biblioth�que de documents, Dossier / Sch�ma d�architecture 
                    SPDocumentLibrary RunFileArchitectureSchemeLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.RUN_LIB_FILE_ARCHITECTURE_SCHEMA_DOCS_NAME)) as SPDocumentLibrary;
                    if (RunFileArchitectureSchemeLibrary != null)
                    {

                        if (CType_WithColumns != null)
                        {
                            SetAdvsetingLibraries(currentWeb, RunFileArchitectureSchemeLibrary, CType_WithColumns.First());
                        }
                    }
                    #endregion

                    #region Biblioth�que de documents, Dossier / Sch�ma d�exploitation 
                    SPDocumentLibrary RunFileSchemeOfExploitationLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.RUN_LIB_FILE_SCHEMA_OF_EXPLOITATION_DOCS_NAME)) as SPDocumentLibrary;
                    if (RunFileSchemeOfExploitationLibrary != null)
                    {
                        SetAdvsetingLibraries(currentWeb, RunFileSchemeOfExploitationLibrary, CType_WithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents, Dossier / Sch�ma d�installation 
                    SPDocumentLibrary RunFileSchemeOfInstallationLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.RUN_LIB_FILE_SCHEMA_OF_INSTALATION_DOCS_NAME)) as SPDocumentLibrary;
                    if (RunFileSchemeOfInstallationLibrary != null)
                    {
                        SetAdvsetingLibraries(currentWeb, RunFileSchemeOfInstallationLibrary, CType_WithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents, Cahier de Tests de Non R�gression 
                    SPDocumentLibrary RunNonRegressionTestsBookLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.RUN_LIB_NON_REGRESSION_TESTS_BOOK_DOCS_NAME)) as SPDocumentLibrary;
                    if (RunNonRegressionTestsBookLibrary != null)
                    {
                        SetAdvsetingLibraries(currentWeb, RunNonRegressionTestsBookLibrary, CType_WithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents, Sanity Check 
                    SPDocumentLibrary RunSanityCheckApplicationLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.RUN_LIB_SANITY_CHECK_APPLICATION_DOCS_NAME)) as SPDocumentLibrary;
                    if (RunSanityCheckApplicationLibrary != null)
                    {
                        SetAdvsetingLibraries(currentWeb, RunSanityCheckApplicationLibrary, CType_WithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents, Document s�curit� 
                    SPDocumentLibrary RunSecurityDocumentLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.RUN_LIB_SECURITY_DOCS_NAME)) as SPDocumentLibrary;
                    if (RunSecurityDocumentLibrary != null)
                    {
                        SetAdvsetingLibraries(currentWeb, RunSecurityDocumentLibrary, CType_WithColumns.First());
                        // Ajouter la colonne Type document s�curit�  
                        SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, RunSecurityDocumentLibrary, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_DOC_TYPE_SECU_INTERNALNAME), false);
                    }
                    #endregion

                    #region Biblioth�que de documents, Fiches support 
                    SPDocumentLibrary RunSupportDocumentationLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.RUN_LIB_SUPPORT_DOCS_NAME)) as SPDocumentLibrary;

                    if (RunSupportDocumentationLibrary != null)
                    {
                        SetAdvsetingLibraries(currentWeb, RunSupportDocumentationLibrary, CType_WithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents, Manuel utilisateur / 
                    SPDocumentLibrary RunUserGuideLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.RUN_LIB_USER_GUIDE_DOCS_NAME)) as SPDocumentLibrary;

                    if (RunUserGuideLibrary != null)
                    {
                        SetAdvsetingLibraries(currentWeb, RunUserGuideLibrary, CType_WithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents, Autres documents/ 
                    SPDocumentLibrary RunOtherDocumentLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.RUN_LIB_OTHER_DOCS_NAME)) as SPDocumentLibrary;

                    if (RunOtherDocumentLibrary != null)
                    {
                        SetAdvsetingLibraries(currentWeb, RunOtherDocumentLibrary, CType_WithColumns.First());
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                    LogManager.LogError("[DOCS DSI] Error occurred,in the feature 02-DocsDsi - WebCommonDataRunLibraries" + ".Exception- " + ex.Message.ToString());
                }
                finally
                {
                    currentWeb.AllowUnsafeUpdates = true;
                    currentWeb.Dispose();
                }
            }
        }
        
        private void SetAdvsetingLibraries(SPWeb currentWeb, SPDocumentLibrary runLibraryName, SPContentType parentContentType)
        {
            try
            {
                runLibraryName.ContentTypesEnabled = true;
                runLibraryName.EnableFolderCreation = false;
                runLibraryName.Update();
                if (runLibraryName.ContentTypes[ContentTypes.DEFAULT_CT_DOCUMENT_NAME] != null)
                {
                    runLibraryName.ContentTypes.Delete(runLibraryName.ContentTypes[ContentTypes.DEFAULT_CT_DOCUMENT_NAME].Id);
                    runLibraryName.Update();
                }

                if (runLibraryName.ContentTypes[parentContentType.Name] != null)
                    return;

                runLibraryName.ContentTypes.Add(parentContentType);
                runLibraryName.Update();
            }
            catch (Exception ex)
            {
                LogManager.LogError("[DOCS DSI] Error occurred,in the feature 02-DocsDsi - WebCommonDataRunLibraries" + ".Exception- " + ex.Message.ToString());
            }
        }

        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System.Linq;

namespace BNPPI.RE.DocsDsi.Portal.Features._03_DocsDsi___Web_Lists_instances___Projects
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("ccc7699e-7749-4753-a5f4-59e7dacefc57")]
    public class _03_DocsDsi___Web_Lists_instances___ProjectsEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            if (properties == null)
                return;


            if (properties.Feature == null)
                return;

            if (properties.Feature.Parent == null)
                return;

            if (!(properties.Feature.Parent is SPWeb))
                return;

            using (SPWeb currentWeb = (SPWeb)properties.Feature.Parent)
            {
                try
                {
                    currentWeb.AllowUnsafeUpdates = true;
                    // List ref Application 
                    #region Old Localization

                    //runFileArchitectureSchemeLibraryContentType.Name = Localization.Current.GetResource("ContentTypes_RunApplicationDocsSetName", "BNPPI.RE.DocsDSI.portal", currentWeb.Language);
                    //runFileArchitectureSchemeLibraryContentType.Description = Localization.Current.GetResource("ContentTypes_RunApplicationDocsSetDescription", "BNPPI.RE.DocsDSI.portal", currentWeb.Language); 
                    #endregion

                    // Colonne de site Project Name
                    var siteColProjetName = currentWeb.Fields.GetFieldByInternalName(Fields.PROJECTS_LIST_FIELDS_PROJECT_NAME_INTERNALNAME);

                    #region Biblioth�que Bilan  Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsBalanceSheetDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_BALANCE_SHEET_DOCS_NAME)) as SPDocumentLibrary;
                    if (ProjectsBalanceSheetDocsLibrary != null)
                    {
                        SPContentTypeId cTypesID_BalanceSheetDocSetsName = new SPContentTypeId("0x0120D52000E003F8A732CC4E54A58A95D024A8441E");
                        SPContentType cTypes_BalanceSheetDocSetsName = currentWeb.AvailableContentTypes[cTypesID_BalanceSheetDocSetsName];

                        //Ajouter la colonne Lookup Projet
                        SPFieldLink fieldLink = new SPFieldLink(siteColProjetName);
                        if (cTypes_BalanceSheetDocSetsName.FieldLinks[Fields.PROJECTS_LIST_FIELDS_PROJECT_NAME_INTERNALNAME] == null)
                        {
                            currentWeb.ContentTypes[cTypes_BalanceSheetDocSetsName.Id].FieldLinks.Add(fieldLink);
                            currentWeb.ContentTypes[cTypes_BalanceSheetDocSetsName.Id].Update();
                        }

                        // Ajouter le type de contenu � la liste
                        var cTypes_BalanceSheetDocSetsNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_BALANCE_SHEET_ID)) == true select c;

                        SetAdvsetingLibraries(currentWeb, ProjectsBalanceSheetDocsLibrary, cTypes_BalanceSheetDocSetsNameWithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents C2I Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsC2IDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_C2I_DOCS_NAME)) as SPDocumentLibrary;
                    if (ProjectsC2IDocsLibrary != null)
                    {
                        SPContentTypeId cTypesID_C2iDocSetsName = new SPContentTypeId("0x0120D520000A0C037802FA4E4C914526BC1136B54F");
                        SPContentType cTypes_C2iDocSetsName = currentWeb.AvailableContentTypes[cTypesID_C2iDocSetsName];

                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_C2iDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_C2iDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_C2iDocSetsNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_C2I_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsC2IDocsLibrary, cTypes_C2iDocSetsNameWithColumns.First());
                       // AddFieldLookUpToProjectsList(currentWeb, ProjectsC2IDocsLibrary, projectsList);
                    }
                    #endregion

                    #region Biblioth�que de documents CMAT, Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsCMATDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_CMAT_DOCS_NAME)) as SPDocumentLibrary;
                    if (ProjectsCMATDocsLibrary != null)
                    {
                        SPContentTypeId cTypesID_CMATDocSetsName = new SPContentTypeId(ContentTypes.PROJECT_CT_CMAT_ID);
                        SPContentType cTypes_CMATDocSetsName = currentWeb.AvailableContentTypes[cTypesID_CMATDocSetsName];

                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_CMATDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_CMATDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_CMATDocSetsNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_CMAT_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsCMATDocsLibrary, cTypes_CMATDocSetsNameWithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents COMIT, Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsCOMITDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_COMIT_DOCS_NAME)) as SPDocumentLibrary;
                    if (ProjectsCOMITDocsLibrary != null)
                    {
                        SPContentTypeId cTypesID_ComitDocSetsName = new SPContentTypeId("0x0120D5200078E642D4A3AD4894A2B938FBD462E95A");
                        SPContentType cTypes_ComitDocSetsName = currentWeb.AvailableContentTypes[cTypesID_ComitDocSetsName];
                        
                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_ComitDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_ComitDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_ComitDocSetsNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_COMIT_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsCOMITDocsLibrary, cTypes_ComitDocSetsNameWithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents CVIT, Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsCvitDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_CVIT_DOCS_NAME)) as SPDocumentLibrary;
                    if (ProjectsCvitDocsLibrary != null)
                    {
                        SPContentTypeId cTypesID_CvitDocSetsName = new SPContentTypeId("0x0120D52000D1D396130B854D6DB8EC179BFB357406");
                        SPContentType cTypes_CvitDocSetsName = currentWeb.AvailableContentTypes[cTypesID_CvitDocSetsName];

                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_CvitDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_CvitDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_CvitDocSetsNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_CVIT_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsCvitDocsLibrary, cTypes_CvitDocSetsNameWithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents Fiches de livraisons, Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsDeliveryCardsDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_DELIVERY_CARDS_DOCS_NAME)) as SPDocumentLibrary;
                    if (ProjectsDeliveryCardsDocsLibrary != null)
                    {
                        SPContentTypeId cTypesID_DeliveryCardsDocSetsName = new SPContentTypeId("0x0120D52000F3759784C3B246A4B750DB89EE3B7835");

                        SPContentType cTypes_DeliveryCardsDocSetsName = currentWeb.AvailableContentTypes[cTypesID_DeliveryCardsDocSetsName];
                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_DeliveryCardsDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_DeliveryCardsDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_DeliveryCardsDocSetsNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_DELIVERY_CARDS_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsDeliveryCardsDocsLibrary, cTypes_DeliveryCardsDocSetsNameWithColumns.First());

                    }
                    #endregion

                    #region Biblioth�que de documents Exigences, Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsDemandsDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_DEMANDS_DOCS_NAME)) as SPDocumentLibrary;

                    if (ProjectsDemandsDocsLibrary != null)
                    {
                        SPContentTypeId cTypesID_DemandsDocSetsName = new SPContentTypeId("0x0120D520000B403C5A1AD744AB82866BAA9564FC68");
                        SPContentType cTypes_DemandsDocSetsName = currentWeb.AvailableContentTypes[cTypesID_DemandsDocSetsName];
                       
                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_DemandsDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_DemandsDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_DemandsDocSetsNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_DEMANDS_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsDemandsDocsLibrary, cTypes_DemandsDocSetsNameWithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents IRPP, Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsIRPPDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_IRPP_DOCS_NAME)) as SPDocumentLibrary;
                    if (ProjectsIRPPDocsLibrary != null)
                    {
                        SPContentTypeId cTypesId_IRPPDocSetsName = new SPContentTypeId("0x0120D520008C7A9F8F118F4B0EA5E52955BCFE1388");
                        SPContentType cTypes_IRPPDocSetsName = currentWeb.AvailableContentTypes[cTypesId_IRPPDocSetsName];
                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_IRPPDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_IRPPDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_IRPPDocSetsNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_CIRPP_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsIRPPDocsLibrary, cTypes_IRPPDocSetsNameWithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents PV, GO/NOGO, Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsMinutesOfMeetingDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_MINUTES_OF_METTING_DOCS_NAME)) as SPDocumentLibrary;

                    if (ProjectsMinutesOfMeetingDocsLibrary != null)
                    {
                        SPContentTypeId cTypesId_MinutesOfMeetingDocSetsName = new SPContentTypeId("0x0120D520006D435F321EB44D709D21080CB2086520");
                        SPContentType cTypes_MinutesOfMeetingDocSetsName = currentWeb.AvailableContentTypes[cTypesId_MinutesOfMeetingDocSetsName];
                       
                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_MinutesOfMeetingDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_MinutesOfMeetingDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_MinutesOfMeetingDocSetsNameNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_MINUTES_OF_METTING_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsMinutesOfMeetingDocsLibrary, cTypes_MinutesOfMeetingDocSetsNameNameWithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents Other Documents, Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsOtherDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_OTHER_DOCS_NAME)) as SPDocumentLibrary;
                    if (ProjectsOtherDocsLibrary != null)
                    {
                        SPContentTypeId cTypesId_OtherDocumentsDocSetsName = new SPContentTypeId("0x0120D520004D90214F561B415088662E65161F7DB3");
                        SPContentType cTypes_OtherDocumentsDocSetsName = currentWeb.AvailableContentTypes[cTypesId_OtherDocumentsDocSetsName];
                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_OtherDocumentsDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_OtherDocumentsDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_OtherDocumentsDocSetsNameNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_OTHER_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsOtherDocsLibrary, cTypes_OtherDocumentsDocSetsNameNameWithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents Release notes, Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsReleaseNotesDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_RELEASE_NOTES_DOCS_NAME)) as SPDocumentLibrary;
                    if (ProjectsReleaseNotesDocsLibrary != null)
                    {
                        SPContentTypeId cTypesId_ReleaseNotesDocSetsName = new SPContentTypeId("0x0120D520007C32182155514E27B41F8FFCD92CBE49");
                        SPContentType cTypes_ReleaseNotesDocSetsName = currentWeb.AvailableContentTypes[cTypesId_ReleaseNotesDocSetsName];

                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_ReleaseNotesDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_ReleaseNotesDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_ReleaseNotesDocSetsNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_RELEASE_NOTES_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsReleaseNotesDocsLibrary, cTypes_ReleaseNotesDocSetsNameWithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents Sp�cifications, Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsSpecificationsDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_SPECIFICATION_DOCS_NAME)) as SPDocumentLibrary;
                    if (ProjectsSpecificationsDocsLibrary != null)
                    {
                        SPContentTypeId cTypesId_SpecificationsDocSetsName = new SPContentTypeId("0x0120D5200021C0D5212A0A40D794E82810BA21BAAB");
                        SPContentType cTypes_SpecificationsDocSetsName = currentWeb.AvailableContentTypes[cTypesId_SpecificationsDocSetsName];

                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_SpecificationsDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_SpecificationsDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_SpecificationsDocSetsNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_SPECIFICATION_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsSpecificationsDocsLibrary, cTypes_SpecificationsDocSetsNameWithColumns.First());
                    }
                    #endregion

                    #region Biblioth�que de documents cahier de recette, Ajouter le type de contenu Documents Set
                    SPDocumentLibrary ProjectsTestsBookDocsLibrary = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.PROJECT_LIB_TEST_BOOK_DOCS_NAME)) as SPDocumentLibrary;
                    if (ProjectsTestsBookDocsLibrary != null)
                    {
                        SPContentTypeId cTypesId_TestsBookDocSetsName = new SPContentTypeId("0x0120D52000B63DC7306D8245168F5BAACF56A49D5D");
                        SPContentType cTypes_TestsBookDocSetsName = currentWeb.AvailableContentTypes[cTypesId_TestsBookDocSetsName];

                        //Ajouter la colonne Lookup Projet
                        currentWeb.ContentTypes[cTypes_TestsBookDocSetsName.Id].FieldLinks.Add(new SPFieldLink(siteColProjetName));
                        currentWeb.ContentTypes[cTypes_TestsBookDocSetsName.Id].Update();

                        // Ajouter le type de contenu � la liste
                        var cTypes_TestsBookDocSetsNameWithColumns = from c in currentWeb.ContentTypes.Cast<SPContentType>() where c.Id.IsChildOf(new SPContentTypeId(ContentTypes.PROJECT_CT_TEST_BOOK_ID)) == true select c;
                        SetAdvsetingLibraries(currentWeb, ProjectsTestsBookDocsLibrary, cTypes_TestsBookDocSetsNameWithColumns.First());
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                    LogManager.LogError("[DOCS DSI] Error occurred,in the feature 05-DocsDsi - WebCommonDataProject" + ". Exception- " + ex.ToString());
                }
                finally
                {
                    currentWeb.AllowUnsafeUpdates = true;
                    currentWeb.Dispose();
                }
            }
        }

        /// <summary>
        ///  Ajouter le type de contenu � la liste
        /// </summary>
        /// <param name="currentWeb"></param>
        /// <param name="listName"></param>
        /// <param name="cType"></param>
        private void SetAdvsetingLibraries(SPWeb currentWeb, SPDocumentLibrary listName, SPContentType cType)
        {
            try
            {
                // Activer le type de contenu et d�sactiver la cr�ation des dossiers
                listName.ContentTypesEnabled = true;
                listName.EnableFolderCreation = false;
                listName.Update();

                // Supprimer le type de contenu par defaut (Document)
                if (listName.ContentTypes[ContentTypes.DEFAULT_CT_DOCUMENT_NAME] != null)
                {
                    listName.ContentTypes.Delete(listName.ContentTypes[ContentTypes.DEFAULT_CT_DOCUMENT_NAME].Id);
                    listName.Update();
                }

                // si le type de contenu existe
                if (listName.ContentTypes[cType.Name] != null)
                    return;
               
                // Sinon Ajouter le type de contenu � la liste
                listName.ContentTypes.Add(cType);
                listName.Update();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using BNPPI.RE.DocsDsi.Portal.Extensions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Runtime.InteropServices;

namespace BNPPI.RE.DocsDsi.Portal.Features._03_DocsDsi___WebCommonDataProjectsList
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("5a1eb110-5295-4016-b4bd-ae9d5e6bef4b")]
    public class _03_DocsDsi___WebCommonDataProjectsListEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            if (properties == null)
                return;


            if (properties.Feature == null)
                return;

            if (properties.Feature.Parent == null)
                return;

            if (!(properties.Feature.Parent is SPWeb))
                return;

            using (SPWeb currentWeb = (SPWeb)properties.Feature.Parent)
            {
                try
                {
                    #region List ref Projet 
                    SPList projectsList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.APP_LIST_PROJECTS_NAME));
                    if (!currentWeb.Fields.ContainsField(Fields.PROJECTS_LIST_FIELDS_PROJECT_NAME_INTERNALNAME))
                    {
                        currentWeb.Fields.AddLookup(Fields.PROJECTS_LIST_FIELDS_PROJECT_NAME_INTERNALNAME, projectsList.ID, true);
                        currentWeb.Update();

                        SPFieldLookup fieldLookup = new SPFieldLookup(currentWeb.Fields, Fields.PROJECTS_LIST_FIELDS_PROJECT_NAME_INTERNALNAME);

                        fieldLookup.Title = Localization.Localization.Current.GetResource("Fields_ProjectNameDisplayName", "BNPPI.RE.DocsDSI.portal", 1036);
                        fieldLookup.Group = Localization.Localization.Current.GetResource("Fields_GroupName", "BNPPI.RE.DocsDSI.portal", 1036);

                        fieldLookup.LookupField = projectsList.Fields.GetField(Fields.SP_FIELDS_TITLE_INTERNALNAME).InternalName;
                        fieldLookup.Update();
                        currentWeb.Update();
                    } 
                    #endregion

                    #region Ajouter les colonnes M�tier / Fonction et Pays au type de contenu document pour les biblioth�ques Runs
                    SPContentTypeId cTypesID_Project= new SPContentTypeId(ContentTypes.APP_CT_PROJECT_ID);
                    SPContentType cTypes_Project = currentWeb.AvailableContentTypes[cTypesID_Project];
             
                    // Ajouter la colonne application li�e
                    var siteColApplication = currentWeb.Fields.GetFieldByInternalName(Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME);
                    SPFieldLink fieldLinkApplication = new SPFieldLink(siteColApplication);
                    if (cTypes_Project.FieldLinks[Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME] == null)
                    {
                        currentWeb.ContentTypes[cTypes_Project.Id].FieldLinks.Add(fieldLinkApplication);
                        currentWeb.ContentTypes[cTypes_Project.Id].Update();
                    }

                    //Ajouter la colonne Busness line
                    var siteColBusnessLine = currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_BUSNESSKINE_AND_FUNCTION_INTERNALNAME);
                    SPFieldLink fieldLinkBusnessLine = new SPFieldLink(siteColBusnessLine);
                    if (cTypes_Project.FieldLinks[Fields.FIELDS_COMMON_COL_BUSNESSKINE_AND_FUNCTION_INTERNALNAME] == null)
                    {
                        currentWeb.ContentTypes[cTypes_Project.Id].FieldLinks.Add(fieldLinkBusnessLine);
                        currentWeb.ContentTypes[cTypes_Project.Id].Update();
                    }

                    var siteColCountry = currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME);
                    SPFieldLink fieldLinkCountry = new SPFieldLink(siteColCountry);
                    if (cTypes_Project.FieldLinks[Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME] == null)
                    {
                        currentWeb.ContentTypes[cTypes_Project.Id].FieldLinks.Add(fieldLinkCountry);
                        currentWeb.ContentTypes[cTypes_Project.Id].Update();
                    }
                    #endregion

                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, projectsList, currentWeb.Fields.GetFieldByInternalName(Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME), true);

                    #region Ajouter la colonne Application li�e
                    SPFieldLookup fieldLookupApplication = (SPFieldLookup)(projectsList.Fields.GetFieldByInternalName(Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME));
                    fieldLookupApplication.AllowMultipleValues = true;
                    fieldLookupApplication.Required = false;
                    fieldLookupApplication.Title = Localization.Localization.Current.GetResource("Fields_RelatedApplicationsDisplayName", "BNPPI.RE.DocsDSI.portal", 1036);
                    fieldLookupApplication.Update(); 
                    #endregion

                    #region Ajouter la colonne M�tier / Fonction
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, projectsList, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_BUSNESSKINE_AND_FUNCTION_INTERNALNAME), true);

                    SPFieldLookup fieldLookupBusnessLine = (SPFieldLookup)(projectsList.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_BUSNESSKINE_AND_FUNCTION_INTERNALNAME));
                    fieldLookupBusnessLine.Title = Localization.Localization.Current.GetResource("Fields_BusinessLineAndFunctionDisplayName", "BNPPI.RE.DocsDSI.portal", 1036);
                    fieldLookupBusnessLine.Update(); 
                    #endregion

                    #region Ajouter la colonne pays concern�s
                    SPWebExtensions.AddFieldByInternalNnmeToListAndView(currentWeb, projectsList, currentWeb.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME), true);

                    SPFieldLookup fieldLookupCountry = (SPFieldLookup)(projectsList.Fields.GetFieldByInternalName(Fields.FIELDS_COMMON_COL_COUNTRIES_CONCERNED_INTERNALNAME));
                    fieldLookupCountry.Title = Localization.Localization.Current.GetResource("Fields_CountriesConcernedDisplayName", "BNPPI.RE.DocsDSI.portal", 1036);
                    fieldLookupCountry.Update(); 
                    #endregion
                }
                catch (Exception ex)
                {
                    LogManager.LogError("[DOCS DSI] Error occurred,in the feature 03-DocsDsi - WebCommonDataRun" + ". Exception- " + ex.ToString());
                }
            }
        }

        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

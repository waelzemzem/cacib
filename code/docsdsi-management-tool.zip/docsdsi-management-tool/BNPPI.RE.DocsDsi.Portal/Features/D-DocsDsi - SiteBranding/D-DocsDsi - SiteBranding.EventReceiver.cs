using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using BNPPI.RE.DocsDsi.Portal.Extensions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace BNPPI.RE.DocsDsi.Portal.Features.Site_Feature_Branding
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("4f372eab-853f-48dc-a30c-e179f35af238")]
    public class Site_Feature_BrandingEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            if (properties == null)
                return;
            try
            {
                // Get SPSite
                SPSite site = properties.Feature.Parent as SPSite;
                if (site == null)
                    throw new Exception("Unable to get reference of current Site");

                if (properties.Feature.Properties["FrontMasterPageUrlSiteRelative"] != null && properties.Feature.Properties["SystemMasterPageUrlSiteRelative"] != null)
                {
                    // Get site relative url
                    string FrontMasterPageSiteRelative = properties.Feature.Properties["FrontMasterPageUrlSiteRelative"].Value;
                    string SystemMasterPageSiteRelative = properties.Feature.Properties["SystemMasterPageUrlSiteRelative"].Value;

                    if (!string.IsNullOrEmpty(FrontMasterPageSiteRelative) && !string.IsNullOrEmpty(SystemMasterPageSiteRelative))
                    {
                        string frontMasterPageUrl = SPUrlUtility.CombineUrl(site.ServerRelativeUrl, FrontMasterPageSiteRelative);
                        string systemMasterPageUrl = SPUrlUtility.CombineUrl(site.ServerRelativeUrl, SystemMasterPageSiteRelative);

                        // Swap masterpage
                        site.RootWeb.ApplyMasterPage(frontMasterPageUrl, systemMasterPageUrl);
                    }
                }
            }
            catch (Exception ex)
            {
                // Log error
                LogManager.LogError("Feature Web_SwapMasterpage : Error FeatureActivated - " + ex.ToString());
            }
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            if (properties == null)
                return;

            try
            {
                // Get SPSite
                SPSite site = properties.Feature.Parent as SPSite;
                if (null == site)
                    throw new Exception("Unable to get reference of current Site");

                // Get old master url
                string oldFrontMasterUrl = string.Empty;
                string oldSystemMasterUrl = string.Empty;

                if (site.RootWeb.Properties.ContainsKey("Web_SwapFrontMasterPageUrl"))
                    oldFrontMasterUrl = site.RootWeb.Properties["Web_SwapFrontMasterPageUrl"];

                if (site.RootWeb.Properties.ContainsKey("Web_SwapSystemMasterPageUrl"))
                    oldSystemMasterUrl = site.RootWeb.Properties["Web_SwapSystemMasterPageUrl"];

                if (!string.IsNullOrEmpty(oldFrontMasterUrl) && !string.IsNullOrEmpty(oldSystemMasterUrl))
                {
                    // Swap masterpage
                    site.RootWeb.ApplyMasterPage(oldFrontMasterUrl, oldSystemMasterUrl);
                }
            }
            catch (Exception ex)
            {
                // Log error
                LogManager.LogError("Feature Site_BrandingEventReceiver : Error FeatureDeactivating - " + ex.Message);
                throw;
            }
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

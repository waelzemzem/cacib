using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using BNPPI.RE.DocsDsi.Portal.Constants;
using BNPPI.RE.DocsDsi.Portal.Diagnotics;
using BNPPI.RE.DocsDsi.Portal.Extensions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace BNPPI.RE.DocsDsi.Portal.Features._01_DocsDsi___WebCommonDataApplicationsList
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("159927af-6f5d-44c9-910c-8c2d38e7151f")]
    public class _01_DocsDsi___WebCommonDataApplicationsListEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            if (properties == null)
                return;


            if (properties.Feature == null)
                return;

            if (properties.Feature.Parent == null)
                return;

            if (!(properties.Feature.Parent is SPWeb))
                return;

            using (SPWeb currentWeb = (SPWeb)properties.Feature.Parent)
            {
                try
                {
                    currentWeb.AllowUnsafeUpdates = true;
                    // List ref Application 
                    SPList applicationsList = currentWeb.GetList(SPUrlUtility.CombineUrl(currentWeb.ServerRelativeUrl, Lists.APP_LIST_APPLICATIONS_NAME));
                    if (!currentWeb.Fields.ContainsField(Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME))
                    {
                        currentWeb.Fields.AddLookup(Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME, applicationsList.ID, true);
                        currentWeb.Update();

                        SPFieldLookup fieldLookup = new SPFieldLookup(currentWeb.Fields, Fields.APPLICATION_LIST_FIELDS_APPLICATION_INTERNALNAME);
                        fieldLookup.Title = Localization.Localization.Current.GetResource("Fields_RelatedApplicationsDisplayName", "BNPPI.RE.DocsDSI.portal", 1036);
                        fieldLookup.Group = Localization.Localization.Current.GetResource("Fields_GroupName", "BNPPI.RE.DocsDSI.portal", 1036);
                        fieldLookup.LookupField = currentWeb.Fields.GetField(Fields.SP_FIELDS_TITLE_INTERNALNAME).InternalName;
                        fieldLookup.Update();
                        currentWeb.Update();
                    }
                }
                catch (Exception ex)
                {
                    LogManager.LogError("[DOCS DSI] Error occurred,in the feature 03-DocsDsi - WebCommonDataRun" + ". Exception- " + ex.ToString());
                }
                finally
                {
                    currentWeb.AllowUnsafeUpdates = true;
                    currentWeb.Dispose();
                }
            }
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

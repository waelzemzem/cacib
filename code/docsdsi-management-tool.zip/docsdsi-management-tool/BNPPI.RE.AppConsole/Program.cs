﻿using BNPPI.RE.AppConsole;
using BNPPI.RE.AppConsole.Constants;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security;
using System.Text;
using static BNPPI.RE.AppConsole.LogFile;

namespace BNPPI.RE.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {


            #region Copy Documents
            ClientContext clientContextSourceSiteURL = new ClientContext(EnvironmentUat.SourceSiteURL);
            //Web site = clientContextSourceSiteURL.Web;
            clientContextSourceSiteURL.ExecuteQuery();


            ClientContext clientContextDestinationSiteURL = new ClientContext(EnvironmentUat.DestinationSiteURL);
            //Web site = clientContextDestinationSiteURL.Web;
            clientContextDestinationSiteURL.ExecuteQuery();

            SecureString theSecureString = new NetworkCredential("", "+").SecurePassword;
            string theString = new NetworkCredential("", theSecureString).Password;

            CopyDocumentLibraryToAnotherSite.CloneLibraryItems(EnvironmentUat.SourceLibraryName, EnvironmentUat.SourceSiteURL, EnvironmentUat.DestinationSiteURL, @"Bnppi\svc.shp.adm.uat", theSecureString);

           // CopyDocumentLibraryToAnotherSite.CopyDocuments(clientContextSourceSiteURL, clientContextDestinationSiteURL, "General Documents", "General Documents Copy");
            #endregion





            #region Old
            // DEV
            string siteUrl = "http://pars402i2701.bnppi.priv/sites/DocsDSI";

            // UAT 
            // string siteUrl = "https://sharepoint-uat-realestate.staging.echonet/sites/DocsDSI";

            // Staiging
            //  string siteUrl = "https://sharepoint-realestate.staging.echonet/sites/DocsDSI";

            // production 
            // string siteUrl = "https://sharepoint-realestate.is.echonet/sites/docsdsi";






            ClientContext clientContext = new ClientContext(siteUrl);
            Web site = clientContext.Web;
            bool ifExist = true;

            //Getting List 
            // Dev
            List olist = site.Lists.GetByTitle("Applications patrimony");
            // Production 
            //List olist = site.Lists.GetByTitle("Applications patrimoine");
            clientContext.ExecuteQuery();


            #region Region TO upload file in the library document 
            List olistDocuments = site.Lists.GetByTitle("template library");
            clientContext.ExecuteQuery();

            TestsUploadDocuments.UploadDocumentsRandom(olistDocuments, clientContext, 4);

            Console.ReadLine();
            #endregion




            #region Get listItems by view
            View view = olist.Views.GetByTitle("All Items");

            clientContext.Load(view);
            clientContext.ExecuteQuery();
            CamlQuery query = new CamlQuery();
            query.ViewXml = view.ViewQuery;


            ListItemCollection items = olist.GetItems(query);
            clientContext.Load(items);
            clientContext.ExecuteQuery();

            foreach (ListItem itm in items)
            {
                //Console.WriteLine("Title: " + itm["Title"]);
                //Console.WriteLine("IDApp: " + itm["IDApp"]);
                //Console.WriteLine();
            }



            using (var reader = new StreamReader(@"E:\BNPRE Projects Repos\Sharepoint_20220505.csv", System.Text.Encoding.UTF7))
            {
                List<string> listA = new List<string>();
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(';');
                    Console.WriteLine(line);
                    if (values.Count() == 21)
                    {


                        foreach (ListItem item in items)
                        {
                            //  Console.WriteLine(item["IDApp"].ToString().Trim() + " " + item["Title"].ToString().Trim());
                            //if (string.Equals(values[1].ToString().Trim(), item["Title"].ToString().Trim(), StringComparison.OrdinalIgnoreCase))
                            //if (values[0] == "10006")

                            if (item["IDApp"] != null && (string.Equals(values[0].ToString().Trim(), item["IDApp"].ToString().Trim(), StringComparison.OrdinalIgnoreCase)))
                            {
                                // if (values[1] == "​Site Internet Espace Associés REIM​")
                                //if (values[0] == "10006")
                                //{
                                Console.WriteLine(values[0] + " => " + item["IDApp"].ToString());


                                item["IDApp"] = values[0];
                                item["Title"] = values[1];
                                item["AppDescription"] = values[2];
                                item["AppVersion"] = values[3];
                                item["AppInternetFacing"] = values[4];
                                item["AppPersonalData"] = values[5];
                                item["AppConfidentiality"] = values[6];
                                item["AppIntegrity"] = values[7];
                                item["AppAvaibility"] = values[8];
                                item["AppTraceability"] = values[9];
                                item["AppRTO"] = values[10];
                                item["AppRPO"] = values[11];

                                DateTime newdate;
                                if (DateTime.TryParse(values[12].ToString().Trim(), System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out newdate))
                                {
                                    item["AppLastCIAT"] = newdate;
                                }
                                item["AppClass"] = values[13];
                                item["AppAuthentification"] = values[14];
                                item["AppHostingType"] = values[15];
                                item["AppCloudServiceModel"] = values[16];
                                item["AppHostingProvider"] = values[17];
                                item["AppManagedApplication"] = values[18];
                                item["AppStatus"] = values[19];

                                User userFArid = clientContext.Web.EnsureUser(@"euro\e06744");
                                item["Author"] = userFArid;
                                item["Editor"] = userFArid;

                                item.Update();
                                clientContext.ExecuteQuery();

                                // to get the id of lookup field
                                // PROD
                                List list = site.Lists.GetByTitle("IT responsible");
                                // Dev
                                // List list = site.Lists.GetByTitle("ParamITResponsibleList");
                                //item.Update();
                                //clientContext.ExecuteQuery();

                                CamlQuery camlQuery = new CamlQuery();
                                string strCAMLQuery = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" +
                                                values[20].ToString() +
                                                "</Value></Eq>" +
                                              "</Where></Query></View>";

                                camlQuery.ViewXml = strCAMLQuery;
                                ListItemCollection listItemCollection = list.GetItems(camlQuery);
                                clientContext.Load(listItemCollection);
                                clientContext.ExecuteQuery();
                                if (listItemCollection.Count > 0)
                                {
                                    ListItem listItem = listItemCollection.FirstOrDefault();
                                    clientContext.Load(listItem);
                                    clientContext.ExecuteQuery();
                                    //   FieldLookupValue spflv = new FieldLookupValue(int.Parse(listItem["ID"].ToString()), values[20]);
                                    item["AppITResponsible"] = int.Parse(listItem["ID"].ToString());
                                    //Console.WriteLine(" values[0] =>" + values[0] + "values[20]=>  " + values[20].ToString());
                                    //Console.WriteLine(" ID iT-Responsible => " + int.Parse(listItem["ID"].ToString()) + " Title iT-Responsible => " + listItem["Title"].ToString());

                                    //item["AppITResponsible"] = int.Parse(listItem["ID"].ToString());


                                    item["Author"] = userFArid;
                                    item["Editor"] = userFArid;
                                    item.Update();
                                    clientContext.ExecuteQuery();

                                }
                                // Create list elements
                                listA.Add(item["Title"].ToString().Trim());
                                //Console.WriteLine();

                                ifExist = true;
                                break;
                            }
                            else if (values[0] == "ID")
                            {
                                ifExist = true;
                                break;
                            }
                            else
                            {
                                ifExist = false;
                            }

                        }
                        //}

                        // create the new ligne 
                        Console.WriteLine(ifExist);
                        if (ifExist == false)
                        {


                            // to get the id of lookup field
                            // PROD
                            List list = site.Lists.GetByTitle("IT responsible");

                            // DEV
                            //  List list = site.Lists.GetByTitle("ParamITResponsibleList");
                            int lookupIdItems = 0;

                            //oListItem.Update();
                            //clientContext.ExecuteQuery();

                            CamlQuery camlQuery = new CamlQuery();
                            string strCAMLQuery = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" +
                                            values[20].ToString() +
                                            "</Value></Eq>" +
                                          "</Where></Query></View>";

                            camlQuery.ViewXml = strCAMLQuery;
                            ListItemCollection listItemCollection = list.GetItems(camlQuery);
                            clientContext.Load(listItemCollection);
                            clientContext.ExecuteQuery();
                            if (listItemCollection.Count > 0)
                            {
                                ListItem listItem = listItemCollection.FirstOrDefault();
                                clientContext.Load(listItem);
                                //clientContext.ExecuteQuery();
                                //   FieldLookupValue spflv = new FieldLookupValue(int.Parse(listItem["ID"].ToString()), values[20]);
                                lookupIdItems = int.Parse(listItem["ID"].ToString());
                                //Console.WriteLine(" values[0] =>" + values[0] + "values[20]=>  " + values[20].ToString());
                                //Console.WriteLine(" ID iT-Responsible => " + int.Parse(listItem["ID"].ToString()) + " Title iT-Responsible => " + listItem["Title"].ToString());

                                //oListItem["AppITResponsible"] = int.Parse(listItem["ID"].ToString());


                            }

                            ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                            ListItem oListItem = olist.AddItem(itemCreateInfo);

                            oListItem["IDApp"] = values[0];
                            oListItem["Title"] = values[1];
                            oListItem["AppDescription"] = values[2];
                            oListItem["AppVersion"] = values[3];
                            oListItem["AppInternetFacing"] = values[4];
                            oListItem["AppPersonalData"] = values[5];
                            oListItem["AppConfidentiality"] = values[6];
                            oListItem["AppIntegrity"] = values[7];
                            oListItem["AppAvaibility"] = values[8];
                            oListItem["AppTraceability"] = values[9];
                            oListItem["AppRTO"] = values[10];
                            oListItem["AppRPO"] = values[11];

                            DateTime newdate;
                            if (DateTime.TryParse(values[12].ToString().Trim(), System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out newdate))
                            {
                                oListItem["AppLastCIAT"] = newdate;
                            }
                            oListItem["AppClass"] = values[13];
                            oListItem["AppAuthentification"] = values[14];
                            oListItem["AppHostingType"] = values[15];
                            oListItem["AppCloudServiceModel"] = values[16];
                            oListItem["AppHostingProvider"] = values[17];
                            oListItem["AppManagedApplication"] = values[18];
                            oListItem["AppStatus"] = values[19];
                            oListItem["AppITResponsible"] = lookupIdItems;

                            User userFArid = clientContext.Web.EnsureUser(@"euro\e06744");
                            oListItem["Author"] = userFArid;
                            oListItem["Editor"] = userFArid;


                            oListItem.Update();
                            clientContext.ExecuteQuery();
                        }
                    }
                    else
                    {
                        using (StreamWriter w = System.IO.File.AppendText("log" + DateTime.Now.ToString("ddMMyyyy--HH-mm") + ".txt"))
                        {
                            Log(line, w);
                        }


                        Console.WriteLine("line Error =>" + line);
                        Console.WriteLine("line Field count =>" + values.Count());
                    }
                }
                Console.WriteLine(listA.Count);
            }

            #endregion
            Console.ReadKey();


            #region Get Fields and update type fields
            //Getting Column Names
            FieldCollection fieldCollection = olist.Fields;
            clientContext.Load(fieldCollection);
            clientContext.ExecuteQuery();

            ////Printing Column Names
            //foreach (Field field in fieldCollection)
            //{
            //    Console.WriteLine(field.InternalName.ToString());

            //    if (field.InternalName.ToString() == "IDApp")
            //    {
            //        //field.SetShowInNewForm(true);
            //        field.SetShowInEditForm(true);
            //        field.Update();
            //        clientContext.ExecuteQuery();
            //    }

            //}


            #endregion
            Console.ReadLine();

            #region Upload dynamic files
            for (int i = 0; i < 4; i++)
            {
                #region Generate Datetime
                Random rnd = new Random();
                DateTime datetoday = DateTime.Now;

                int rndYear = rnd.Next(2000, datetoday.Year);
                int rndMonth = rnd.Next(1, 12);
                int rndDay = rnd.Next(1, 31);

                DateTime generateDate = new DateTime(rndYear, rndMonth, rndDay);
                Console.WriteLine(generateDate);
                #endregion

                FileCreationInformation newFile = new FileCreationInformation();
                newFile.Content = System.IO.File.ReadAllBytes(@"C:\\TestFile.docx"); //TestFile.xlsx TestFile.pdf TestFile.docx  TestFile.pub TestFile.pptx
                var chars = "0123456789"; //"ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                var stringChars = new char[8];

                var random = new Random();

                for (int j = 0; j < stringChars.Length; j++)
                {
                    stringChars[j] = chars[random.Next(chars.Length)];
                }
                var finalString = new String(stringChars);
                var docName = "Procédure " + finalString + " V_" + generateDate.ToString("yyyy-mm-dd") + ".docx";
                newFile.Url = " / " + docName;

                Microsoft.SharePoint.Client.File uploadFile = olist.RootFolder.Files.Add(newFile);
                clientContext.Load(uploadFile);
                clientContext.ExecuteQuery();

                ListItem item = uploadFile.ListItemAllFields;
                //
                string docTitle = string.Empty;
                item["Title"] = docName;
                item["Created"] = generateDate;
                item["Modified"] = generateDate; // generateDate; datetoday;

                User userFArid = clientContext.Web.EnsureUser(@"euro\e06744");
                User user1FRederic = clientContext.Web.EnsureUser(@"euro\182859");
                User userDidier = clientContext.Web.EnsureUser(@"euro\440214");
                User userLaurent = clientContext.Web.EnsureUser(@"euro\209797");

                item["Author"] = userLaurent;
                item["Editor"] = userDidier;

                item.Update();
                clientContext.ExecuteQuery();
            }

            #endregion

            //Printing Column Names
            foreach (Field field in fieldCollection)
            {
                Console.WriteLine(field.InternalName.ToString());

                if (field.InternalName.ToString() == "Title")
                {
                    //field.Required = false;
                    //field.Update();
                    //clientContext.ExecuteQuery();
                }

            }
            #endregion
            Console.ReadLine();
        }


    }
}

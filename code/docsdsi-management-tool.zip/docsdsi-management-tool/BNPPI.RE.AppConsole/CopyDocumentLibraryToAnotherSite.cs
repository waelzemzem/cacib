﻿using Microsoft.SharePoint.Client;
using System;
using System.Linq;
using System.Security;
using System.Threading;
using SP = Microsoft.SharePoint.Client;
using System.IO;

namespace BNPPI.RE.AppConsole
{
    public static class CopyDocumentLibraryToAnotherSite
    {
        public static void CloneLibraryItems(string srcLibrary, string srcUrl, string destUrl, string userName, SecureString pwd)
        {
            string srclibraryname = string.Empty;
            string fileName = string.Empty;
            string folderPath = string.Empty;
            try
            {
                ClientContext srcContext = new ClientContext(srcUrl);
                ClientContext destContext = new ClientContext(destUrl);

                //srcContext.Credentials = new SharePointOnlineCredentials(userName, pwd);
                srcContext.RequestTimeout = Timeout.Infinite;
                Web srcWeb = srcContext.Web;
                List srcList = srcWeb.Lists.GetByTitle(srcLibrary);
                CamlQuery camlQuery = new CamlQuery();
                camlQuery.ViewXml = "<View Scope='RecursiveAll'><Query></Query></View>";
                ListItemCollection itemColl = srcList.GetItems(camlQuery);
                srcContext.Load(itemColl);
                srcContext.ExecuteQuery();

                //destContext.Credentials = new SharePointOnlineCredentials(userName, pwd);
                destContext.RequestTimeout = Timeout.Infinite;
                Web destWeb = destContext.Web;
                destContext.Load(destWeb);
                destContext.ExecuteQuery();

                List desList = destWeb.Lists.GetByTitle(srcLibrary);
                destContext.Load(desList);
                destContext.ExecuteQuery();


                // Log to file
                WriteToFile("Copy documents is started " + DateTime.Now);
                string _path = destWeb.ServerRelativeUrl;
                if (itemColl.Count > 0)
                {
                    srclibraryname = itemColl[0].FieldValues["FileDirRef"].ToString();
                    string[] srcurlSplit = srclibraryname.Split('/');
                    srclibraryname = srcurlSplit[srcurlSplit.Count() - 1];

                    foreach (ListItem doc in itemColl)
                    {
                        if (doc.FileSystemObjectType == FileSystemObjectType.File)
                        {

                            fileName = doc["FileRef"].ToString();
                            string[] fileNames = fileName.Split(new string[] { srclibraryname }, StringSplitOptions.None);
                            fileName = fileNames[fileNames.Count() - 1];

                            SP.File file = doc.File;
                            srcContext.Load(file);
                            srcContext.ExecuteQuery();

                            srcContext.Load(doc.File.CheckedOutByUser);
                            srcContext.Load(doc.File.Author);
                            srcContext.Load(doc.File.ModifiedBy);
                            srcContext.ExecuteQuery();

                            //Console.WriteLine(doc["FileRef"].ToString().Split('/').LastOrDefault());
                            //Console.WriteLine(doc["Author"].ToString() + doc.File.Author.LoginName);
                            //Console.WriteLine(doc["Modified"].ToString());
                            //Console.WriteLine(doc["Editor"].ToString() + doc.File.ModifiedBy.LoginName);
                            //Console.WriteLine(doc["Created"].ToString());

                            FileInformation fileInfo = SP.File.OpenBinaryDirect(srcContext, file.ServerRelativeUrl);
                            SP.File.SaveBinaryDirect(destContext, _path + "/" + srclibraryname + fileName, fileInfo.Stream, true);

                            // Force metadatas
                            Microsoft.SharePoint.Client.File Newfile = destWeb.GetFileByServerRelativeUrl(_path + "/" + srclibraryname + fileName);
                          
                            ListItem lstItem = Newfile.ListItemAllFields;
                            destContext.Load(lstItem);
                            destContext.ExecuteQuery();

                            lstItem["Editor"] = destWeb.EnsureUser(doc.File.ModifiedBy.LoginName);
                            lstItem["Modified"] = DateTime.Parse(doc["Modified"].ToString().Trim());
                            lstItem["Author"] = destWeb.EnsureUser(doc.File.Author.LoginName);
                            lstItem["Created"] = DateTime.Parse(doc["Created"].ToString().Trim());
                            lstItem.Update();
                            destContext.ExecuteQuery();

                            WriteToFile("File " +  doc["FileRef"].ToString());
                        }
                        else if (doc.FileSystemObjectType == FileSystemObjectType.Folder)
                        {

                            folderPath = doc["FileRef"].ToString();
                            string[] fileNames = folderPath.Split(new string[] { srclibraryname }, StringSplitOptions.None);
                            folderPath = fileNames[fileNames.Count() - 1];
                            folderPath = folderPath.TrimStart(new Char[] { '/' });
                            //Console.WriteLine("Folder Path :" + folderPath);
                            SP.Folder folder = CreateFolder(destContext.Web, srcLibrary, folderPath);

                            // force Metadata
                            srcContext.Load(doc.Folder);
                            srcContext.ExecuteQuery();

                            //Console.WriteLine("Folder ID :" + folder.ListItemAllFields.Id);
                            ListItem itemJustAdded = desList.GetItemById(folder.ListItemAllFields.Id);

                            destContext.Load(itemJustAdded);
                            var editor = destContext.Web.EnsureUser(((FieldUserValue)doc["Editor"]).LookupValue);
                            destContext.Load(editor);
                            itemJustAdded["Editor"] = editor;
                            itemJustAdded["Modified"] = DateTime.Parse(doc["Modified"].ToString()); // doc.Folder.TimeLastModified;

                            var author = destContext.Web.EnsureUser(((FieldUserValue)doc["Author"]).LookupValue);
                            destContext.Load(author);
                            itemJustAdded["Author"] = author;
                            itemJustAdded["Created"] = DateTime.Parse(doc["Created"].ToString()); //doc.Folder.TimeCreated;
                           
                            itemJustAdded.Update();
                            destContext.ExecuteQuery();


                            WriteToFile("Folder " + folder.ServerRelativeUrl);


                            //Console.WriteLine("Folder Path :" + folderPath + "  Editor: " + ((FieldUserValue)doc["Editor"]).LookupId);
                            //Console.WriteLine("Folder Path :" + folderPath + "  Modified: " + doc["Modified"].ToString());
                            //Console.WriteLine("Folder Path :" + folderPath + "  Author: " + ((FieldUserValue)doc["Author"]).LookupId);
                            //Console.WriteLine("Folder Path :" + folderPath + "  Created: " + doc["Created"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                WriteToFile("Error " + ex.Message);
            }
        }
        public static SP.Folder CreateFolder(Web web, string listTitle, string fullFolderPath)
        {
            if (string.IsNullOrEmpty(fullFolderPath))
                throw new ArgumentNullException("fullFolderPath");
            var list = web.Lists.GetByTitle(listTitle);
            return CreateFolderInternal(web, list.RootFolder, fullFolderPath, list);
        }
        private static SP.Folder CreateFolderInternal(Web web, SP.Folder parentFolder, string fullFolderPath, List spList)
        {

            var folderUrls = fullFolderPath.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            string folderUrl = folderUrls[0];
            var curFolder = parentFolder.Folders.Add(folderUrl);
            web.Context.Load(curFolder);
            web.Context.ExecuteQuery();

            web.Context.Load(curFolder.ListItemAllFields);
            web.Context.ExecuteQuery();

            if (folderUrls.Length > 1)
            {
                var folderPath = string.Join("/", folderUrls, 1, folderUrls.Length - 1);
                return CreateFolderInternal(web, curFolder, folderPath, spList);
            }

            return curFolder;
        }
        
        public static void WriteToFile(string message)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + ("\\logs");
            string extension = ".txt";

            if (Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            string filePath = path + "ExportLibLog_" + DateTime.Now.ToShortDateString().Replace("/", "_") + extension;

            if (!System.IO.File.Exists(filePath))
            {
                using (StreamWriter sw = System.IO.File.CreateText(filePath))
                {
                    sw.WriteLine(message);
                }
            }
            else
            {
                using (StreamWriter sw = System.IO.File.AppendText(filePath))
                {
                    sw.WriteLine(message);
                }

            }
        }
    
    }
}

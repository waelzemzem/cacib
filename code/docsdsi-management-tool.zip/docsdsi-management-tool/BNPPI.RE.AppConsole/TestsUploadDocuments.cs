﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace BNPPI.RE.AppConsole
{
   public class TestsUploadDocuments
    {

        internal static void UploadDocumentsRandom(List olist, ClientContext clientContext, int nbrDocument)
        {

            #region Upload dynamic files
            for (int i = 0; i < nbrDocument; i++)
            {
                #region Generate Datetime
                Random rnd = new Random();
                DateTime datetoday = DateTime.Now;

                int rndYear = rnd.Next(2000, datetoday.Year);
                int rndMonth = rnd.Next(1, 12);
                int rndDay = rnd.Next(1, 31);

                DateTime generateDate = new DateTime(rndYear, rndMonth, rndDay);
                Console.WriteLine(generateDate);
                #endregion

                FileCreationInformation newFile = new FileCreationInformation();
                newFile.Content = System.IO.File.ReadAllBytes(@"C:\\TestFile.docx"); //TestFile.xlsx TestFile.pdf TestFile.docx  TestFile.pub TestFile.pptx
                var chars = "0123456789"; //"ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                var stringChars = new char[8];

                var random = new Random();

                for (int j = 0; j < stringChars.Length; j++)
                {
                    stringChars[j] = chars[random.Next(chars.Length)];
                }
                var finalString = new String(stringChars);
                var docName = "Procédure " + finalString + " V_" + generateDate.ToString("yyyy-mm-dd") + ".docx";
                newFile.Url = " / " + docName;

                Microsoft.SharePoint.Client.File uploadFile = olist.RootFolder.Files.Add(newFile);
                clientContext.Load(uploadFile);
                clientContext.ExecuteQuery();

                ListItem item = uploadFile.ListItemAllFields;
                //
                string docTitle = string.Empty;
                item["Title"] = docName;
                item["Created"] = generateDate;
                item["Modified"] = generateDate; // generateDate; datetoday;

                User userFArid = clientContext.Web.EnsureUser(@"euro\e06744");
                User user1FRederic = clientContext.Web.EnsureUser(@"euro\182859");
                User userDidier = clientContext.Web.EnsureUser(@"euro\440214");
                User userLaurent = clientContext.Web.EnsureUser(@"euro\209797");

                item["Author"] = userLaurent;
                item["Editor"] = userDidier;

                item.Update();
                clientContext.ExecuteQuery();
            }

            #endregion
        }

      

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.AppConsole.Constants
{
    public static class EnvironmentUat
    {
        public const string SourceSiteURL = "https://sharepoint-uat-realestate.staging.echonet/sites/uk/cmb";
        public const string SourceLibraryName = "General Documents";

        public const string DestinationSiteURL = "https://sharepoint-uat-realestate.staging.echonet/sites/uk/cm/Test";
        public const string DestinationLibraryName = "General Documents";
    }
}

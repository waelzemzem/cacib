﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPI.RE.AppConsole.Constants
{
    public static class EnvironmentDev
    {
        public const string SourceSiteURL = "";
        public const string SourceLibraryName = "";
        public const string DestinationSiteURL = "";
        public const string DestinationLibraryName = "";

    }
}

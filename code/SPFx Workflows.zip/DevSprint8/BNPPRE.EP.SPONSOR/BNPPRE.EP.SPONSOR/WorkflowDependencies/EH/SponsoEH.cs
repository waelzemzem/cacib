﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Workflow;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.SPONSOR.WorkflowDependencies.EH
{
    public class SponsoEH : SPItemEventReceiver
    {

        /// <summary>
        /// Item Added of Coi list 
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            Guid siteID = properties.SiteId;
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb ElevatedWeb = wSite.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentitem = properties.ListItem;
                            //this.EventFiringEnabled = false;
                            ////BNPTools.ApplyPermissions(currentuser, ElevatedWeb, currentitem, "ListSponsor", "SponsoQLocalCountry");
                            //this.EventFiringEnabled = true; 

                            //SPWorkflowManager wfManager = properties.ListItem.ParentList.ParentWeb.Site.WorkflowManager;
                            //SPWorkflowAssociationCollection wfAssociationCollection = properties.ListItem.ParentList.WorkflowAssociations;

                            //foreach (SPWorkflowAssociation wfAssociation in wfAssociationCollection)
                            //{
                            //    if (wfAssociation.BaseId == new Guid("2CB74DAD-898E-4879-B832-2D145053D6C7"))
                            //    {
                            //        wfManager.StartWorkflow(properties.ListItem, wfAssociation, wfAssociation.AssociationData, true);
                            //        break;
                            //    }
                            //}
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in ListSponsor EH item added : " + ex.Message);
                        }
                    }
                }
            });
        }


        /// <summary>
        /// Item Updated of Coi list
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            Guid siteID = properties.SiteId;
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb ElevatedWeb = wSite.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentitem = properties.ListItem;

                            //BNPTools.ApplyPermissions(currentuser, ElevatedWeb, currentitem, "ListSponsor", "SponsoQLocalCountry");
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in ListSponsor EH item updated : " + ex.Message);
                        }
                    }
                }
            });

        }

    }
}
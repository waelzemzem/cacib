﻿using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.SPONSOR.WorkflowDependencies.EH
{
    public class SponsoTaskEH : SPItemEventReceiver
    {
        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            using (SPWeb web = properties.OpenWeb())
            {
                try
                {
                    SPListItem currentItem = properties.ListItem;
                    string[] strRelatedItems = currentItem[SPBuiltInFieldId.RelatedItems].ToString().Split(',');
                    string strCurrentItemID = strRelatedItems[0].Split(':')[1];

                    string TaskTitle = currentItem["Title"].ToString();
                    string bmccomment = "", teamcomment = "", csrcomment = "", SponsoLegalTeamComment="", SponsoLocalCeoComment="", globalcomment ="";
                    string bmcreservation = "", teamReservation = "", csrReservation = "", legalteamReservation = "", localceoReservation = "", globalreservation="";

                    if (TaskTitle.Contains("bmc"))
                    {
                        bmccomment = currentItem["SponsorBmcComment"] != null ? currentItem["SponsorBmcComment"].ToString() : "";
                        bmcreservation = currentItem["SponsoBmcReservation"] != null ? currentItem["SponsoBmcReservation"].ToString() : ""; 
                    }
                    if (TaskTitle.Contains("compliance team"))
                    {
                        teamcomment = currentItem["SponsoComplianceTeamComment"] != null ? currentItem["SponsoComplianceTeamComment"].ToString() : "";
                        teamReservation = currentItem["SponsoComplianceTeamReservation"] != null ? currentItem["SponsoComplianceTeamReservation"].ToString() : ""; 
                    }

                    if (TaskTitle.Contains("Global Compliance"))
                    {
                        globalcomment = currentItem["SponsoGlobalTeamComment"] != null ? currentItem["SponsoGlobalTeamComment"].ToString() : "";
                        globalreservation = currentItem["SponsoGlobalTeamCommentReservati"] != null ? currentItem["SponsoGlobalTeamCommentReservati"].ToString() : "";
                    }

                    if (TaskTitle.Contains("csr"))
                    {
                        csrcomment = currentItem["SponsorCsrComment"] != null ? currentItem["SponsorCsrComment"].ToString() : "";
                        csrReservation = currentItem["SponsoCSRteamReservation"] != null ? currentItem["SponsoCSRteamReservation"].ToString() : ""; 
                    }
                    if (TaskTitle.Contains("legal"))
                    {
                        SponsoLegalTeamComment = currentItem["SponsoLegalTeamComment"] != null ? currentItem["SponsoLegalTeamComment"].ToString() : "";
                        legalteamReservation = currentItem["SponsoLegalTeamReservation"]!= null ? currentItem["SponsoLegalTeamReservation"].ToString() : ""; 
                    }
                    if (TaskTitle.Contains("Ceo") || TaskTitle == "Global CEO Sponso Task")
                    {
                        SponsoLocalCeoComment = currentItem["SponsoLocalCeoComment"] != null ? currentItem["SponsoLocalCeoComment"].ToString() : "";
                        localceoReservation = currentItem["SponsoLocalCeoReservation"] != null ? currentItem["SponsoLocalCeoReservation"].ToString() : ""; 
                    }
                    SPList currentList = web.Lists["ListSponsor"];
                    SPListItem currentRelatedItem = currentList.GetItemById(int.Parse(strCurrentItemID));
                    web.AllowUnsafeUpdates = true;
                    if (!string.IsNullOrEmpty(bmccomment))
                        currentRelatedItem["SponsorBmcComment"] = bmccomment;
                    if (!string.IsNullOrEmpty(teamcomment))
                        currentRelatedItem["SponsoComplianceTeamComment"] = teamcomment;
                    if (!string.IsNullOrEmpty(csrcomment))
                        currentRelatedItem["SponsorCsrComment"] = csrcomment;
                    if (!string.IsNullOrEmpty(SponsoLegalTeamComment))
                        currentRelatedItem["SponsoLegalTeamComment"] = SponsoLegalTeamComment;
                    if (!string.IsNullOrEmpty(globalcomment))
                        currentRelatedItem["SponsoGlobalTeamComment"] = globalcomment; 
                    if (!string.IsNullOrEmpty(SponsoLocalCeoComment))
                        currentRelatedItem["SponsoLocalCeoComment"] = SponsoLocalCeoComment;

                    //Reservations 
                    if (!string.IsNullOrEmpty(bmcreservation))
                        currentRelatedItem["SponsoBmcReservation"] = bmcreservation;
                    if (!string.IsNullOrEmpty(teamReservation))
                        currentRelatedItem["SponsoComplianceTeamReservation"] = teamReservation;
                    if (!string.IsNullOrEmpty(csrReservation))
                        currentRelatedItem["SponsoCSRteamReservation"] = csrReservation;
                    if (!string.IsNullOrEmpty(legalteamReservation))
                        currentRelatedItem["SponsoLegalTeamReservation"] = legalteamReservation;
                    if (!string.IsNullOrEmpty(globalreservation))
                        currentRelatedItem["SponsoGlobalTeamCommentReservation"] = globalreservation; 
                    if (!string.IsNullOrEmpty(localceoReservation))
                        currentRelatedItem["SponsoLocalCeoReservation"] = localceoReservation;

                    currentRelatedItem.Update();
                    web.AllowUnsafeUpdates = false;
                }
                catch (Exception ex)
                {
                    BNPTools.WriteInLogFile("Exception in EH : Sponsorship Task" + ex.Message);
                }
            }
        }

    }
}
using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace BNPPRE.EP.SPONSOR.Features.Ep_Sponsor_Eh
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("db5e30d5-b319-4f0f-9dc3-18c74b8fb9e9")]
    public class Ep_Sponsor_EhEventReceiver : SPFeatureReceiver
    {
        string lst_title = "SponsorshipTaskList";
        string _class = "BNPPRE.EP.SPONSOR.WorkflowDependencies.EH.SponsoTaskEH";
        string _className = "SponsoTaskEH";

        string lst_title_sponso = "ListSponsor";
        string _class_sponso = "BNPPRE.EP.SPONSOR.WorkflowDependencies.EH.SponsoEH";
        string _className_sponso = "SponsoEH";

        const SPEventReceiverType eventTypeAdded = SPEventReceiverType.ItemAdded;
        const SPEventReceiverType eventTypeUpdated = SPEventReceiverType.ItemUpdated;

        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                SPListCollection lstCollection = rootweb.Lists;
                SPList ListC = null, ListSponso = null ;
                try
                {
                    ListC = lstCollection.TryGetList(lst_title);
                    ListSponso = lstCollection.TryGetList(lst_title_sponso); 
                }
                catch (Exception ex)
                {
                    BNPTools.WriteInLogFile("Exception in feature ListSponsor EHs : " + ex.Message);
                }
                if (null != ListC)
                {

                    SPEventReceiverDefinition def = ListC.EventReceivers.Add();
                    def.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    def.Class = _class;
                    def.Name = _className;
                    def.Type = SPEventReceiverType.ItemUpdated;
                    def.SequenceNumber = 1000;
                    def.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    def.Update();
                }

                if (null != ListSponso)
                {

                    SPEventReceiverDefinition defAdded = ListSponso.EventReceivers.Add();
                    defAdded.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    defAdded.Class = _class_sponso;
                    defAdded.Name = _className_sponso;
                    defAdded.Type = SPEventReceiverType.ItemAdded;
                    defAdded.SequenceNumber = 1000;
                    defAdded.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    defAdded.Update();

                    SPEventReceiverDefinition defUpdated = ListSponso.EventReceivers.Add();
                    defUpdated.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    defUpdated.Class = _class_sponso;
                    defUpdated.Name = _className_sponso;
                    defUpdated.Type = SPEventReceiverType.ItemUpdated;
                    defUpdated.SequenceNumber = 1000;
                    defUpdated.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    defUpdated.Update();

                }
            });
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                SPListCollection lstCollection = rootweb.Lists;


                SPList ListC = null, ListSponso = null ;
                try
                {
                    ListC = lstCollection.TryGetList(lst_title);
                    ListSponso = lstCollection.TryGetList(lst_title_sponso); 
                }
                catch(Exception ex)
                {
                    BNPTools.WriteInLogFile("Exception in desactivate listSponso feature EHs : " + ex.Message);
                }
                if (null != ListC)
                {
                    DeleteEvents(ListC);
                }
                if (null != ListSponso)
                {
                    DeleteEvents(ListSponso);
                }
            });
        }

        private static void DeleteEvents(SPList list)
        {
            SPEventReceiverDefinitionCollection erdc = list.EventReceivers;
            List<SPEventReceiverDefinition> eventsToDelete = new List<SPEventReceiverDefinition>();

            foreach (SPEventReceiverDefinition erd in erdc)
            {
                if (erd != null)
                {
                    try
                    {
                        eventsToDelete.Add(erd);
                    }
                    catch (Exception) { }
                }
            }
            foreach (SPEventReceiverDefinition er in eventsToDelete)
            {
                if (er.Type == eventTypeAdded || er.Type == eventTypeUpdated)
                {
                    er.Delete();
                }
            }
        }



        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

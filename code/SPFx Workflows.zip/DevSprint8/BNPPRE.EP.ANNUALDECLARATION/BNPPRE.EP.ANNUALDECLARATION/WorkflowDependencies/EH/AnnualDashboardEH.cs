﻿using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.ANNUALDECLARATION.WorkflowDependencies.EH
{
    public class AnnualDashboardEH : SPItemEventReceiver
    {
        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);

             
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite site = new SPSite(properties.SiteId))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        try
                        {
                            SPList splDashboard = web.Lists["AnnualDashboard"];
                            //splDashboard.BreakRoleInheritance(false, false); 
                            SPListItem currentItemDashboard = splDashboard.GetItemById(properties.ListItemId);
                            bool originalCatchValue = SPSecurity.CatchAccessDeniedException;
                            bool originalwebAllowunsafeUpdates = web.AllowUnsafeUpdates;
                            SPSecurity.CatchAccessDeniedException = false;
                            web.AllowUnsafeUpdates = true;
                            currentItemDashboard.BreakRoleInheritance(false);
                            string group = currentItemDashboard["AnnualEmployeeCountry"] != null ? currentItemDashboard["AnnualEmployeeCountry"].ToString() : "";
                            
                            
                           
                            
                            
                            if (!string.IsNullOrEmpty(group))
                            {
                                BNPTools.AssignPermissionTogroup(web, currentItemDashboard, group);
                            }
                            BNPTools.AssignPermissionTogroup(web, currentItemDashboard, "Global Compliance");
                            SPGroup groupOwner = web.SiteGroups.Cast<SPGroup>().Where(g => g.Name.Contains("Owners")).FirstOrDefault();
                            if (groupOwner != null )
                                BNPTools.AssignPermissionTogroup(web, currentItemDashboard, groupOwner.Name);

                            currentItemDashboard.Update();
                            SPSecurity.CatchAccessDeniedException = originalCatchValue;
                            web.AllowUnsafeUpdates = originalwebAllowunsafeUpdates;
                            
                         

                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in Annual Dashboard EH : " + ex.Message); 
                            //SPDiagnosticsService.Local.WriteTrace(0,
                            //                                    new SPDiagnosticsCategory("EP", TraceSeverity.Unexpected, EventSeverity.Error),
                            //                                    TraceSeverity.Unexpected, ex.Message, ex.Message);
                        }
                    }
                }
            });
        }

        /// <summary>
        /// An item was updated
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    using (SPSite site = new SPSite(properties.SiteId))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            try
                            {
                                SPList splDashboard = web.Lists["AnnualDashboard"];
                                //splDashboard.BreakRoleInheritance(false, false); 
                                SPListItem currentItemDashboard = splDashboard.GetItemById(properties.ListItemId);
                                bool originalCatchValue = SPSecurity.CatchAccessDeniedException;
                                bool originalwebAllowunsafeUpdates = web.AllowUnsafeUpdates;
                                SPSecurity.CatchAccessDeniedException = false;
                                web.AllowUnsafeUpdates = true;
                                currentItemDashboard.BreakRoleInheritance(false);
                                //Delete all from item permissions
                                SPRoleAssignmentCollection coll=   currentItemDashboard.RoleAssignments;
                                for (int i = 0; i < coll.Count; i++)
                                {
                                    currentItemDashboard.RoleAssignments.Remove(i);
                                }
                                string group = currentItemDashboard["AnnualEmployeeCountry"] != null ? currentItemDashboard["AnnualEmployeeCountry"].ToString() : "";

                                if (!string.IsNullOrEmpty(group))
                                {
                                    BNPTools.AssignPermissionTogroup(web, currentItemDashboard, group);
                                }
                                BNPTools.AssignPermissionTogroup(web, currentItemDashboard, "Global Compliance");
                                SPGroup groupOwner = web.SiteGroups.Cast<SPGroup>().Where(g => g.Name.Contains("Owners")).FirstOrDefault();
                                if (groupOwner != null)
                                    BNPTools.AssignPermissionTogroup(web, currentItemDashboard, groupOwner.Name);

                                currentItemDashboard.Update();                                
                                SPSecurity.CatchAccessDeniedException = originalCatchValue;
                                web.AllowUnsafeUpdates = originalwebAllowunsafeUpdates;
                            }
                            catch (Exception ex) 
                            {
                                BNPTools.WriteInLogFile("Exception inside ItemUpdated Annual Dahsboard EH : " + ex.Message);
                            }
                           }
                    }
                });
            }
            catch (Exception ex)
            {
                BNPTools.WriteInLogFile("Exception in ItemUpdated Annual Dahsboard EH : " + ex.Message);
            }
        }

      
    }
}

﻿using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.ANNUALDECLARATION.WorkflowDependencies.EH
{
    public class AnnualEH : SPItemEventReceiver
    {
        /// <summary>
        /// An anuual attestation was added
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            SPUser currentuser = properties.Web.CurrentUser;
            SPListItem currentitem = properties.ListItem;

            bool originalCatchValue = SPSecurity.CatchAccessDeniedException;
            SPSecurity.CatchAccessDeniedException = false;
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite site = new SPSite(properties.SiteId))
                {
                    using (SPWeb web = site.OpenWeb(properties.Web.ID))
                    {
                        try
                        {
                           // SPList splAnnual = web.Lists["ListAnnual"];
                          
                            string group = currentitem["Annual_QLocalCountry"] != null ? currentitem["Annual_QLocalCountry"].ToString() : "";

                            web.AllowUnsafeUpdates = true;

                            BNPTools.WriteInLogFile("Check:" + currentitem.GetUserEffectivePermissions(currentuser.ToString()));
                            currentitem.BreakRoleInheritance(false);
                            
                            #region assign role contributor to current user  
                            SPRoleAssignment roleAssignmentCurrentUser = new SPRoleAssignment((SPPrincipal)currentuser);
                            SPRoleDefinition roleAdmin = web.RoleDefinitions.GetByType(SPRoleType.Contributor);
                            roleAssignmentCurrentUser.RoleDefinitionBindings.Add(roleAdmin);
                            currentitem.RoleAssignments.Add(roleAssignmentCurrentUser);
                            #endregion
                            

                            if (!string.IsNullOrEmpty(group))
                            {
                                BNPTools.AssignPermissionTogroup(web, currentitem, group);
                            }
                            BNPTools.AssignPermissionTogroup(web, currentitem, "Global Compliance");
                            SPGroup groupOwner = web.SiteGroups.Cast<SPGroup>().Where(g => g.Name.Contains("Owners")).FirstOrDefault();
                            if (groupOwner != null)
                                BNPTools.AssignPermissionTogroup(web, currentitem, groupOwner.Name);

                            currentitem.Update();
                            web.AllowUnsafeUpdates = false;
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in Annual EH : " + ex.Message);
                        }
                        finally
                        {
                            SPSecurity.CatchAccessDeniedException = originalCatchValue;
                        }
                    }
                }
            });
        }




        /// <summary>
        /// An annual attestation  was updated
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            SPUser currentuser = properties.Web.CurrentUser;
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite site = new SPSite(properties.SiteId))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        try
                        {
                            SPList splAnnual = web.Lists["ListAnnual"];
                            SPListItem currentitem = properties.ListItem;
                            string group = currentitem["Annual_QLocalCountry"] != null ? currentitem["Annual_QLocalCountry"].ToString() : "";

                            web.AllowUnsafeUpdates = true;
                            currentitem.BreakRoleInheritance(false);

                            #region assign role contributor to current user  
                            SPRoleAssignment roleAssignmentCurrentUser = new SPRoleAssignment((SPPrincipal)currentuser);
                            SPRoleDefinition roleAdmin = web.RoleDefinitions.GetByType(SPRoleType.Contributor);
                            roleAssignmentCurrentUser.RoleDefinitionBindings.Add(roleAdmin);
                            currentitem.RoleAssignments.Add(roleAssignmentCurrentUser);
                            #endregion

                            if (!string.IsNullOrEmpty(group))
                            {
                                BNPTools.AssignPermissionTogroup(web, currentitem, group);
                            }
                            BNPTools.AssignPermissionTogroup(web, currentitem, "Global Compliance");
                            SPGroup groupOwner = web.SiteGroups.Cast<SPGroup>().Where(g => g.Name.Contains("Owners")).FirstOrDefault();
                            if (groupOwner != null)
                                BNPTools.AssignPermissionTogroup(web, currentitem, groupOwner.Name);

                            currentitem.Update();
                            web.AllowUnsafeUpdates = false;
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in Annual EH (ItemUpdated): " + ex.Message);
                        }
                    }
                }
            });
        }


    }
}

﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.ANNUALDECLARATION.Jobs
{
    class ReminderAA : SPJobDefinition
    {
        public ReminderAA() : base()
        {

        }

        public ReminderAA(string jobName, SPService service, SPServer server, SPJobLockType targetType) : base(jobName, service, server, targetType)
        {
            this.Title = "ReminderAA";
        }

        public ReminderAA(string jobName, SPWebApplication webApplication) : base(jobName, webApplication, null, SPJobLockType.ContentDatabase)
        {
            this.Title = "ReminderAA";
        }


        public override void Execute(Guid ContentDatabaseID)
        {
            try
            {
                SPWebApplication webApp = this.Parent as SPWebApplication;
                SPWeb web = webApp.Sites["sites/portalep"].RootWeb;

                SPList splrefep = web.Lists["Lstrefep"];
                SPListItemCollectionPosition itemscollectionposition = null;
                SPQuery query = new SPQuery();
                query.ListItemCollectionPosition = itemscollectionposition;
                BNPTools.WriteInLogFile(DateTime.Now.AddDays(-15).ToString()); 
                query.Query = "<Where><Gt><FieldRef Name='AnnualEmailSentDate'/><Value Type='Date'>"+DateTime.Now.AddDays(-15)+"</Value></Gt></Where>";
                query.ViewXml = @"<View>
                                                   <ViewFields>
                                                        <FieldRef Name='ID'/> 
                                                        <FieldRef Name='RefFirstName'/> 
                                                         <FieldRef Name='RefLastName'/>
                                                        <FieldRef Name='RefContact'/> 
                                                        <FieldRef Name='MailUser'/> 
                                                        <FieldRef Name='RefManager'/> 
                                                        <FieldRef Name='isComex'/> 
                                                        <FieldRef Name='RefPays'/> 
                                                        <FieldRef Name='PESensibility'/> 
                                                        <FieldRef Name='RefDepartment'/> 
                                                        <FieldRef Name='DeclarationUrl'/> 
                                                        <FieldRef Name='AnnualEmailSentDate' />
                                                        <FieldRef Name='SensivityEmailSentDate' />
                                                   </ViewFields>
                                                   <RowLimit>20000</RowLimit>
                                                 </View>";
                SPListItemCollection items = splrefep.GetItems(query);
                itemscollectionposition = items.ListItemCollectionPosition;
                query.ListItemCollectionPosition = items.ListItemCollectionPosition;

                List<SPListItem> wlist = items.Cast<SPListItem>().Where(w => (w["AnnualEmailSentDate"] != null && Convert.ToDateTime(w["AnnualEmailSentDate"]) >= DateTime.Now.AddDays(-15))).ToList();
                string Remindercomplianceen = BNPTools.GetSettingValue(SPContext.Current.Web, "ReminderCompliance_En");

                SPList splCompliances = web.Lists["LstSensiPays"];
                foreach (SPListItem witem in splCompliances.Items)
                {
                    List<SPListItem> wlistCompliance = wlist.Where(w => w["RefPays"].ToString().Contains(witem.Title)).ToList();
                    if (wlistCompliance.Count > 0)
                    {
                        SPUtility.SendEmail(web, "compliance@realestate.bnpparibas", "wael.zemzem@realestate.bnpparibas",
                                           BNPTools.GetGenericMailCompliance(web, witem.Title), "",
                                           "Reminder Annual Attestation : " + wlistCompliance.Count.ToString(), Remindercomplianceen);
                    }
                }                
            }

            catch (Exception ex)
            {
                BNPTools.WriteInLogFile("Exception in job class reminder annual attestation : " + ex.Message);
            }
        }

    }
}

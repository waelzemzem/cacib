﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using NewEthiquePortal.UI.Tools;


namespace BNPPRE.EP.ANNUALDECLARATION.Jobs
{
    class ResetAnnualFields : SPJobDefinition
    {
        public ResetAnnualFields() : base()
        {
        }
        public ResetAnnualFields(string jobName, SPService service, SPServer server, SPJobLockType targetType) : base(jobName, service, server, targetType)
        {
            this.Title = "ResetAnnualFields";
        }
        public ResetAnnualFields(string jobName, SPWebApplication webApplication) : base(jobName, webApplication, null, SPJobLockType.ContentDatabase)
        {
            this.Title = "ResetAnnualFields";
        }
        public override void Execute(Guid ContentDatabaseID)
        {
            try
            {               
                // Write your program here. This will be executed whenever TimerJob runs
                BNPTools.WriteInLogFile("===    ResetAnnualFields START    ===");
                           
                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    int monthNow = DateTime.Now.Month;
                    // get a reference to the current site collection's content database   
                    SPWebApplication webApplication = this.Parent as SPWebApplication;
                    SPContentDatabase contentDb = webApplication.ContentDatabases[ContentDatabaseID];

                    // get a reference to the "Tasks" list in the RootWeb of the first site collection in the content database   
                    SPWeb rootWeb = contentDb.Sites["sites/epchiachia"].RootWeb;
                    //BNPTools.WriteInLogFile("rootWeb : " + rootWeb.Name);
                    string resetAnnualFieldMonth = BNPTools.GetSettingValue(rootWeb, "resetAnnualFieldMonth");

                    if(resetAnnualFieldMonth == monthNow.ToString())
                    {
                        BNPTools.WriteInLogFile("===    Need to Reset   ===  month: " + monthNow.ToString());
                        SPList listAnnualArchive = rootWeb.Lists["LstRefEPAnnualArchive"];
                        SPList listRefEP = rootWeb.Lists["LstRefEP"];
                        SPListItemCollectionPosition itemscollectionposition = null;
                        SPQuery query = new SPQuery();
                        query.ListItemCollectionPosition = itemscollectionposition;

                        query.ViewXml = @"<View>
                                                   <ViewFields>
                                                        <FieldRef Name='LinkTitle' />
                                                        <FieldRef Name='MailUser' />
		                                                <FieldRef Name='RefContact' />
		                                                <FieldRef Name='RefManager' />
                                                        <FieldRef Name='isComex' />
                                                        <FieldRef Name='BusinessLine' />
                                                        <FieldRef Name='MailManager' />
                                                        <FieldRef Name='RefPays' />
                                                        <FieldRef Name='RefDepartment' />
                                                        <FieldRef Name='RefFirstName' />
                                                        <FieldRef Name='RefLastName' />
                                                        <FieldRef Name='isAdmin' />
                                                        <FieldRef Name='FirstConnection' />
                                                        <FieldRef Name='PECategory' />
                                                        <FieldRef Name='PESubcategory' />
                                                        <FieldRef Name='SensiDescription' />
                                                        <FieldRef Name='PESensibility' />
                                                        <FieldRef Name='PTSensibility' />
                                                        <FieldRef Name='GlobalJobCode' />
                                                        <FieldRef Name='LocalJobCode' />
                                                        <FieldRef Name='AssignSensibility' />
                                                        <FieldRef Name='AnnualDeclarationUrl' />
                                                        <FieldRef Name='AnnualEmailSentDate' />
                                                   </ViewFields>
                                                   <RowLimit>20000</RowLimit>
                                                 </View>";



                        SPListItemCollection items = listRefEP.GetItems(query);
                        itemscollectionposition = items.ListItemCollectionPosition;
                        query.ListItemCollectionPosition = items.ListItemCollectionPosition;

                        BNPTools.WriteInLogFile("get items");

                        // Archiving people who have received campagne mail but didn't declare AA ON ANNUAL CAMPAGNE ARCHIVE List
                        List<SPListItem> undoneList = items.Cast<SPListItem>().Where(w => (w["AnnualEmailSentDate"] != null) && (w["AnnualDeclarationUrl"] == null)).ToList();
                        SPListItem newitem;
                        if (undoneList.Count > 0)
                        {
                            BNPTools.WriteInLogFile("there are people who got mail but didnt fill the AA form");
                            bool ballowunsafeupdates = rootWeb.AllowUnsafeUpdates;
                            BNPTools.WriteInLogFile("ballowunsafeupdates (add): " + ballowunsafeupdates.ToString());
                            rootWeb.AllowUnsafeUpdates = true;

                            foreach (SPListItem witem in undoneList)
                            {
                                BNPTools.WriteInLogFile("try to add them on LstRefEPAnnualArchive");

                                try
                                {

                                    BNPTools.WriteInLogFile("Add user Refid:" + witem["RefContact"].ToString());
                                    newitem = listAnnualArchive.Items.Add();
                                    newitem["Title"] = witem["Title"];
                                    newitem["MailUser"] = witem["MailUser"];
                                    newitem["RefManager"] = witem["RefManager"];
                                    newitem["RefContact"] = int.Parse(witem["RefContact"].ToString().Split(';')[0]);
                                    newitem["isComex"] = witem["isComex"];
                                    newitem["BusinessLine"] = witem["BusinessLine"];
                                    newitem["MailManager"] = witem["MailManager"];
                                    newitem["RefPays"] = witem["RefPays"];
                                    newitem["RefDepartment"] = witem["RefDepartment"];
                                    newitem["RefFirstName"] = witem["RefFirstName"];
                                    newitem["RefLastName"] = witem["RefLastName"];
                                    newitem["isAdmin"] = witem["isAdmin"];
                                    newitem["FirstConnection"] = witem["FirstConnection"];
                                    BNPTools.WriteInLogFile("Add FirstConnection:" + witem["FirstConnection"].ToString());
                                    newitem["PECategory"] = witem["PECategory"];
                                    newitem["PESubcategory"] = witem["PESubcategory"];
                                    newitem["SensiDescription"] = witem["SensiDescription"];
                                    newitem["PESensibility"] = witem["PESensibility"];
                                    newitem["PTSensibility"] = witem["PTSensibility"];
                                    newitem["GlobalJobCode"] = witem["GlobalJobCode"];
                                    newitem["LocalJobCode"] = witem["LocalJobCode"];
                                    BNPTools.WriteInLogFile("Add user Sensivity infomation");
                                    //currentitem["RefPosition"] = witem["RefPosition"];
                                    //currentitem["RefBL"] = witem["RefBL"];

                                    newitem["AssignSensibility"] = witem["AssignSensibility"];
                                    newitem["AnnualDeclarationUrl"] = witem["AnnualDeclarationUrl"];
                                    newitem["AnnualEmailSentDate"] = witem["AnnualEmailSentDate"];
                                    newitem["SensivityEmailSentDate"] = witem["SensivityEmailSentDate"];
                                    newitem.Update();

                                }
                                catch (Exception ex)
                                {
                                    BNPTools.WriteInLogFile("Exception in add item on annual archive : " + ex.Message);

                                }

                            }
                            rootWeb.AllowUnsafeUpdates = ballowunsafeupdates;
                        }



                        // Reset AnnualEmailSentDate/AnnualDeclarationUrl/AssignSensibility/FirstConnection
                        List<SPListItem> resetList = items.Cast<SPListItem>().Where(w => (w["AnnualEmailSentDate"] != null) || (w["AnnualDeclarationUrl"] != null)).ToList();
                        if (resetList.Count > 0)
                        {
                            BNPTools.WriteInLogFile("try to reset campagne field");
                            bool ballowunsafeupdates = rootWeb.AllowUnsafeUpdates;
                            BNPTools.WriteInLogFile("ballowunsafeupdates (add): " + ballowunsafeupdates.ToString());
                            rootWeb.AllowUnsafeUpdates = true;

                            foreach (SPListItem witem in resetList)
                            {
                                try
                                {
                                    BNPTools.WriteInLogFile("try to reset campagne field item Userid : " + witem["RefContact"].ToString());
                                    witem["AnnualEmailSentDate"] = null;
                                    witem["AnnualDeclarationUrl"] = null;
                                    witem["AssignSensibility"] = "False";
                                    witem["FirstConnection"] = true;
                                    witem.Update();
                                }
                                catch (Exception ex)
                                {
                                    BNPTools.WriteInLogFile("Exception in Reset Annual Fields on LstRefEP : " + ex.Message);

                                }
                            }

                            rootWeb.AllowUnsafeUpdates = ballowunsafeupdates;
                        }
                        BNPTools.WriteInLogFile("Reset Annual Fields success ");
                    }
                    else
                    {
                        BNPTools.WriteInLogFile("===    NO need to Reset   ===  month: " + monthNow.ToString());
                    }
                    

                });
            
            
            }
            catch (Exception ex)
            {
                BNPTools.WriteInLogFile("Exception in Excute ResetAnnualFields : " + ex.Message);
            }
        }

    }
}

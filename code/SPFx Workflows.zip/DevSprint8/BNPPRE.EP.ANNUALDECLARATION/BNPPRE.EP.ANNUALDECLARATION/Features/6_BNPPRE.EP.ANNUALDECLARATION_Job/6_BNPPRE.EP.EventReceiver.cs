using BNPPRE.EP.ANNUALDECLARATION.Jobs;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using NewEthiquePortal.UI.Tools;
using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace BNPPRE.EP.ANNUALDECLARATION.Features._6_BNPPRE.EP.ANNUALDECLARATION_Job
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("d1923f37-b376-46f1-ba38-5917b1e75563")]
    public class _6_BNPPREEPEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.
        const string JobName = "ResetAnnualFields";
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    BNPTools.WriteInLogFile("Inside activate feature ResetAnnualFields");
                    SPWebApplication oWebApplication = (SPWebApplication)properties.Feature.Parent;
                    foreach (SPJobDefinition jobDefinition in oWebApplication.JobDefinitions)
                    {
                        // If a Job with the same name already exists, delete it.
                        if (jobDefinition.Name == "ResetAnnualFields")
                        {
                            jobDefinition.Delete();
                            break;
                        }
                        if (jobDefinition.Name == "ReminderAA")
                        {
                            jobDefinition.Delete();
                            break; 
                        }
                    }
                    // install the job  
                    ResetAnnualFields timerJobObject = new ResetAnnualFields("ResetAnnualFields", oWebApplication);

                    // Updates the timer schedule values  
                    SPMonthlySchedule Timerschedule = new SPMonthlySchedule();
                    //Timerschedule.BeginMonth = 1;
                    //Timerschedule.EndMonth = 1;
                    Timerschedule.BeginDay = 1;
                    Timerschedule.EndDay = 1;
                    Timerschedule.BeginHour = 4;
                    Timerschedule.EndHour = 10;
                    Timerschedule.BeginMinute = 0;
                    Timerschedule.EndMinute = 0;
                    Timerschedule.BeginSecond = 0;
                    Timerschedule.EndSecond = 0;
                    timerJobObject.Schedule = Timerschedule;
                    oWebApplication.JobDefinitions.Add(timerJobObject);

                    ReminderAA reminderAA = new ReminderAA("ReminderAA", oWebApplication);
                    SPWeeklySchedule TimerscheduleReminderAA = new SPWeeklySchedule();
                    //Timerschedule.BeginMonth = 1;
                    //Timerschedule.EndMonth = 1;
                    TimerscheduleReminderAA.BeginDayOfWeek = DayOfWeek.Monday;
                    TimerscheduleReminderAA.EndDayOfWeek = DayOfWeek.Monday;
                    TimerscheduleReminderAA.BeginHour = 4;
                    TimerscheduleReminderAA.EndHour = 10;
                    TimerscheduleReminderAA.BeginMinute = 0;
                    TimerscheduleReminderAA.EndMinute = 0;
                    TimerscheduleReminderAA.BeginSecond = 0;
                    TimerscheduleReminderAA.EndSecond = 0;
                    reminderAA.Schedule = TimerscheduleReminderAA;
                    oWebApplication.JobDefinitions.Add(reminderAA);
                });
            }
            catch (Exception ex) {
                BNPTools.WriteInLogFile("Exception in FeatureActivate : " + ex.Message);
            }
        

    }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    SPWebApplication oWebApplication = (SPWebApplication)properties.Feature.Parent;
                    // On deactivating the feature, delete the Timer Job  
                    foreach (SPJobDefinition jobDefinition in oWebApplication.JobDefinitions)
                    {
                        if (jobDefinition.Name == "ResetAnnualFeilds")
                        {
                            jobDefinition.Delete();
                        }
                    }
                });
            }
            catch (Exception ex) {
                BNPTools.WriteInLogFile("Exception in FeatureDeactivating : " + ex.Message);
            }
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

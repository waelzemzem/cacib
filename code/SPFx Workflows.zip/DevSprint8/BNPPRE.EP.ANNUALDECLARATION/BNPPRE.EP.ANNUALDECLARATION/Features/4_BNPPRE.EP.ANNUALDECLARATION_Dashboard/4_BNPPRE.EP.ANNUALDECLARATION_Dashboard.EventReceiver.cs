using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace BNPPRE.EP.ANNUALDECLARATION.Features.Ep_Annual_Dashboard
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("cc443400-9546-4852-a4dc-db9465162d62")]
    public class Ep_Annual_DashboardEventReceiver : SPFeatureReceiver
    {
        const string lst_title = "AnnualDashboard";
        const string _class = "BNPPRE.EP.ANNUALDECLARATION.WorkflowDependencies.EH.AnnualDashboardEH";
        const string _className = "AnnualDashboardEH";


        const string lst_title_Annual = "ListAnnual";
        const string _class_Annual = "BNPPRE.EP.ANNUALDECLARATION.WorkflowDependencies.EH.AnnualEH";
        const string _className_Annual = "AnnualEH";

        const SPEventReceiverType eventTypeAdded = SPEventReceiverType.ItemAdded;
        const SPEventReceiverType eventTypeUpdated = SPEventReceiverType.ItemUpdated;

        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                SPListCollection lstCollection = rootweb.Lists;
                BNPTools.WriteInLogFile("Feature Activated 4_BNPPRE.EP.ANNUALDECLARATION_Dashboard.EventReceiver");

                SPList ListC = null;
                SPList ListD = null; 
                try
                {
                    ListC = lstCollection.TryGetList(lst_title);
                    ListD = lstCollection.TryGetList(lst_title_Annual); 
                }
                catch (Exception ex)
                { BNPTools.WriteInLogFile("Exception in 4_BNPPRE.EP.ANNUALDECLARATION_Dashboard.EventReceiver : " + ex.Message); }
                if (null != ListC)
                {

                    SPEventReceiverDefinition def = ListC.EventReceivers.Add();
                    def.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    def.Class = _class;
                    def.Name = _className;
                    def.Type = SPEventReceiverType.ItemAdded;
                    def.SequenceNumber = 1000;
                    def.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    def.Update();

                    SPEventReceiverDefinition defUpdated = ListC.EventReceivers.Add();
                    defUpdated.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    defUpdated.Class = _class;
                    defUpdated.Name = _className;
                    defUpdated.Type = SPEventReceiverType.ItemUpdated;
                    defUpdated.SequenceNumber = 1000;
                    defUpdated.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    defUpdated.Update();
                }
                if (null != ListD)
                {

                    SPEventReceiverDefinition defUpdated_Annual = ListD.EventReceivers.Add();
                    defUpdated_Annual.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    defUpdated_Annual.Class = _class_Annual;
                    defUpdated_Annual.Name = _className_Annual;
                    defUpdated_Annual.Type = SPEventReceiverType.ItemUpdated;
                    defUpdated_Annual.SequenceNumber = 1000;
                    defUpdated_Annual.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    defUpdated_Annual.Update();
                }

            });
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                SPListCollection lstCollection = rootweb.Lists;


                SPList ListC = null, ListD = null ;


                try
                {
                    ListC = lstCollection.TryGetList(lst_title);
                    ListD = lstCollection.TryGetList(lst_title_Annual); 
                }
                catch (Exception ex)
                { BNPTools.WriteInLogFile("Exception in 4_BNPPRE.EP.ANNUALDECLARATION_Dashboard.EventReceiver : " + ex.Message); }
                if (null != ListC)
                {

                    DeleteEvents(ListC);

                }
                if (null != ListD)
                {

                    DeleteEvents(ListD);

                }
            });
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}

        private static void DeleteEvents(SPList list)
        {
            SPEventReceiverDefinitionCollection erdc = list.EventReceivers;
            List<SPEventReceiverDefinition> eventsToDelete = new List<SPEventReceiverDefinition>();

            foreach (SPEventReceiverDefinition erd in erdc)
            {
                if (erd != null)
                {
                    try
                    {
                        eventsToDelete.Add(erd);
                    }
                    catch (Exception ex) { BNPTools.WriteInLogFile("Exception in 4_BNPPRE.EP.ANNUALDECLARATION_Dashboard.EventReceiver : " + ex.Message); }
                }
            }
            foreach (SPEventReceiverDefinition er in eventsToDelete)
            {
                if (er.Type == eventTypeUpdated)
                {
                    er.Delete();
                }
            }
        }

        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

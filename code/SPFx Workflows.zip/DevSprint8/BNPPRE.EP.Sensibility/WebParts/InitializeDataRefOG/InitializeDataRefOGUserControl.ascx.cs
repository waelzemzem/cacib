﻿using BNPPRE.EP.Sensibility.Tools;
using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace BNPPRE.EP.Sensibility.WebParts.InitializeDataRefOG
{
    public partial class InitializeDataRefOGUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnFullData_Click(object sender, EventArgs e)
        {

        }

        protected void btnIncrementalData_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlquery = "Select TOP 3500 * from [BOB_RH_UAT].[rh].[REFOG_BRUT] ORDER BY PERSONNE_DT_MAJ";
                SPWeb web = SPContext.Current.Web; 
                SensibilityTools.UpdateLstrefepfromRefog(web, sqlquery);
                sqlquery = "Select * from [BOB_RH_UAT].[rh].[REFOG_BRUT] ORDER BY PERSONNE_DT_MAJ OFFSET 3500 ROWS FETCH NEXT 3500 ROWS ONLY";
                SensibilityTools.UpdateLstrefepfromRefog(web, sqlquery);

            }
            catch (Exception ex)
            {
                if (ex.Message == "Thread was being aborted.")
                {
                    Thread.ResetAbort();
                }
                BNPTools.WriteInLogFile("Exception in getting lst ref ep from refog : " + ex.Message); 
            }
        }

       

    }
}

﻿using Microsoft.SharePoint;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace BNPPRE.EP.Sensibility.WebParts.EditSensibilityWP
{
    public partial class EditSensibilityWPUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string currentID = HttpContext.Current.Request.QueryString["ID"];
                if (!string.IsNullOrEmpty(currentID))
                {
                    Guid currentsiteID = SPContext.Current.Site.ID;
                    Guid webID = SPContext.Current.Web.ID;
                    SPSecurity.RunWithElevatedPrivileges(delegate
                    {
                        using (SPSite wSite = new SPSite(currentsiteID))
                        {
                            using (SPWeb wWeb = wSite.OpenWeb(webID))
                            {
                                SPList lstSensibility = wWeb.Lists["PESensibility"];
                                SPListItem currentitem = lstSensibility.GetItemById(int.Parse(currentID));
                                try
                                {
                                    this.Compliance.Text = currentitem["PERefPays"].ToString();
                                }
                                catch { }
                                try
                                {
                                    this.Category.Text = currentitem["PECategory"].ToString();
                                }
                                catch { }
                                try
                                {
                                    this.SubCategory.Text = currentitem["PESubcategory"].ToString();
                                }
                                catch { }
                                try
                                {
                                    this.PEDescription.Text = currentitem["SensiDescription"].ToString();
                                }
                                catch { }
                                try
                                {
                                    this.GlobalJobCode.Text = currentitem["GlobalJobCode"].ToString();
                                }
                                catch { }
                                try
                                {
                                    this.LocalJobCode.Text = currentitem["LocalJobCode"].ToString();
                                }
                                catch { }

                            }
                        }
                    });
                }
            }
            catch { }
        }
    }
}

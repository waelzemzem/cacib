﻿$(document).ready(function () {

    //Title
    var t = document.getElementById('Title');
    t.parentElement.parentElement.style.display = 'none'

    //PERefPays 
    var PERefPays = document.getElementById('PERefPays');
    PERefPays.parentElement.parentElement.style.display = 'none'


    //PECategory
    var PECategory = document.getElementById('PECategory');
    PECategory.parentElement.parentElement.style.display = 'none'


    //PESubcategory 
    var PESubcategory = document.getElementById('PESubcategory');
    PESubcategory.parentElement.parentElement.style.display = 'none'


    //SensiDescription 
    var SensiDescription = document.getElementById('SensiDescription');
    SensiDescription.parentElement.parentElement.style.display = 'none'


    //GlobalJobCode 
    var GlobalJobCode = document.getElementById('GlobalJobCode');
    GlobalJobCode.parentElement.parentElement.style.display = 'none'


    //LocalJobCode
    var LocalJobCode = document.getElementById('LocalJobCode');
    LocalJobCode.parentElement.parentElement.style.display = 'none'

});
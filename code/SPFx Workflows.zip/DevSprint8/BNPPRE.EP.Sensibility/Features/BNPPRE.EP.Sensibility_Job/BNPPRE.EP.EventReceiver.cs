using BNPPRE.EP.Sensibility.Jobs;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using NewEthiquePortal.UI.Tools;
using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace BNPPRE.EP.Sensibility.Features.BNPPRE.EP.Sensibility_Job
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("294bf07e-4560-485b-9a50-8c94a2aca014")]
    public class BNPPREEPEventReceiver : SPFeatureReceiver
    {
        const string JobName = "DataRefog";

        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    BNPTools.WriteInLogFile("Inside activate job feature"); 
                    SPWebApplication parentWebApp = (SPWebApplication)properties.Feature.Parent;
                    DeleteExistingJob(JobName, parentWebApp);
                    CreateJob(parentWebApp);
                    BNPTools.WriteInLogFile("Job created"); 
                });
            }
            catch (Exception ex)
            {
                BNPTools.WriteInLogFile("Exception in FeatureActivated job : " + ex.Message); 
            }
        }


        private bool CreateJob(SPWebApplication site)
        {
            bool jobCreated = false;
            try
            {
                DataRefog job = new DataRefog(JobName, site);
                SPMonthlySchedule schedule = new SPMonthlySchedule();
                schedule.BeginDay = 1;
                schedule.EndDay = 1;
                schedule.BeginHour = 1;
                schedule.EndHour = 10; 
                job.Schedule = schedule;

                job.Update();
            }
            catch (Exception)
            {
                return jobCreated;
            }
            return jobCreated;
        }
        public bool DeleteExistingJob(string jobName, SPWebApplication site)
        {
            bool jobDeleted = false;
            try
            {
                foreach (SPJobDefinition job in site.JobDefinitions)
                {
                    if (job.Name == jobName)
                    {
                        job.Delete();
                        jobDeleted = true;
                    }
                }
            }
            catch (Exception)
            {
                return jobDeleted;
            }
            return jobDeleted;
        }

        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            lock (this)
            {
                try
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate ()
                    {
                        SPWebApplication parentWebApp = (SPWebApplication)properties.Feature.Parent;
                        DeleteExistingJob(JobName, parentWebApp);
                    });
                }
                catch (Exception ex)
                {
                    BNPTools.WriteInLogFile("Exception in FeatureDeactivating job : " + ex.Message);
                }
            }
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

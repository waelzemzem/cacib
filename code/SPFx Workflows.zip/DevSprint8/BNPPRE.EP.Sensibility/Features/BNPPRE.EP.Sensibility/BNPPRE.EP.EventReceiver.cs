using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace BNPPRE.EP.Sensibility.Features.BNPPRE.EP.Sensibility
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("540b52fa-4946-4c11-8785-e52fec3c3965")]
    public class BNPPREEPEventReceiver : SPFeatureReceiver
    {
         
        string lst_pesensibility = "PESensibility";
        string _class = "BNPPRE.EP.Sensibility.EHs.PESensibilityEH";
        string _className = "PESensibilityEH";

        const SPEventReceiverType eventTypeAdded = SPEventReceiverType.ItemAdded;
        const SPEventReceiverType eventTypeUpdated = SPEventReceiverType.ItemUpdated;

        // Uncomment the method below to handle the event raised after a feature has been activated.
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try
            {
                BNPTools.WriteInLogFile("A l'interieur de PE Senibility feature eventreceiver EH. ");

                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                    SPListCollection lstCollection = rootweb.Lists;
                    SPList ListC = null;

                    try
                    {
                        ListC = lstCollection.TryGetList(lst_pesensibility);
                    }
                    catch (Exception ex)
                    {
                        NewEthiquePortal.UI.Tools.BNPTools.WriteInLogFile("Exception in feature EHs : " + ex.Message);
                    }
                    if (null != ListC)
                    {

                        //  DeleteEvents(ListC);
                        SPEventReceiverDefinition def_added = ListC.EventReceivers.Add();
                        def_added.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                        def_added.Class = _class;
                        def_added.Name = _className;
                        def_added.Type = SPEventReceiverType.ItemAdded;
                        def_added.SequenceNumber = 1000;
                        def_added.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                        def_added.Update();

                        SPEventReceiverDefinition def = ListC.EventReceivers.Add();
                        def.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                        def.Class = _class;
                        def.Name = _className;
                        def.Type = SPEventReceiverType.ItemUpdated;
                        def.SequenceNumber = 1000;
                        def.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                        def.Update();
                    }
                });
            }
            catch (Exception ex)
            {
                NewEthiquePortal.UI.Tools.BNPTools.WriteInLogFile("Exception in feature PE Sensibility EH : " + ex.Message);
            }
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                SPListCollection lstCollection = rootweb.Lists;


                SPList ListC = null;
                try
                {
                    ListC = lstCollection.TryGetList(lst_pesensibility);
                    //ListC = rootweb.GetList(rootweb.ServerRelativeUrl.TrimEnd('/') + "/Lists/LstRefEp");
                }
                catch //(Exception ex)
                {
                    //Tools.BNPTools.WriteInLogFile("Exception in desactivate feature EHs : " + ex.Message);
                }
                if (null != ListC)
                {
                    DeleteEvents(ListC);
                }
            });
        }

        private static void DeleteEvents(SPList list)
        {
            SPEventReceiverDefinitionCollection erdc = list.EventReceivers;
            List<SPEventReceiverDefinition> eventsToDelete = new List<SPEventReceiverDefinition>();

            foreach (SPEventReceiverDefinition erd in erdc)
            {
                if (erd != null)
                {
                    try
                    {
                        eventsToDelete.Add(erd);
                    }
                    catch (Exception) { }
                }
            }
            foreach (SPEventReceiverDefinition er in eventsToDelete)
            {
                if (er.Type == eventTypeAdded || er.Type == eventTypeUpdated)
                {
                    er.Delete();
                }
            }
        }

        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

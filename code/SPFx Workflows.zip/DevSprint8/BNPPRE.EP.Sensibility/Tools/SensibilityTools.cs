﻿using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BNPPRE.EP.Sensibility.Tools
{
    public static class SensibilityTools
    {
        public static string GetStringFromLookupField(string lookupValue, string legalentity)
        {
            string ret = string.Empty;

            try
            {
                switch (lookupValue)
                {
                    case "FRANCE":
                        lookupValue = "Compliance RE France";
                        break;

                    case "ALLEMAGNE":
                        lookupValue = "Compliance RE Germany";
                        break;

                    case "POLOGNE":
                        lookupValue = "Compliance Poland";
                        break;

                    case "BELGIQUE":
                        lookupValue = "Compliance Belgium";
                        break;

                    case "ROYAUME UNI":
                        lookupValue = "Compliance UK";
                        break;

                    case "ITALIE":
                        lookupValue = "Compliance RE Italy";
                        break;

                    case "ESPAGNE":
                        lookupValue = "Compliance Spain";
                        break;

                    case "IRLANDE":
                        lookupValue = "Compliance Ireland";
                        break;

                    case "LUXEMBOURG":
                        lookupValue = "Compliance RE Luxembourg";
                        break;

                    case "PAYS-BAS":
                        lookupValue = "Compliance Netherlands";
                        break;

                    case "PORTUGAL":
                        lookupValue = "Compliance Portugal";
                        break;
                }
                switch (legalentity)
                {
                    case "BNPP Real Estate Investment Management Germany GmbH":
                        lookupValue = "Compliance REIM Germany";
                        break;
                    case "BNPP Real Estate Investment Management France":
                        lookupValue = "Compliance REIM France";
                        break;
                    case "BNPP Real Estate Investment Management Luxembourg SA":
                        lookupValue = "Compliance REIM Luxembourg";
                        break;
                    case "BNPP Real Estate Investment Management Italy SPA":
                        lookupValue = "Compliance REIM Italy";
                        break;
                }
            }
            catch { }
            ret = lookupValue;
            return ret;
        }

        public static int GetIDFromLookupField(string lookupValue, string legalentity)
        {
            int returnId = 0;

            try
            {
                switch (lookupValue)
                {
                    case "FRANCE":
                        lookupValue = "Compliance RE France";
                        break;

                    case "ALLEMAGNE":
                        lookupValue = "Compliance RE Germany";
                        break;

                    case "POLOGNE":
                        lookupValue = "Compliance Poland";
                        break;

                    case "BELGIQUE":
                        lookupValue = "Compliance Belgium";
                        break;

                    case "ROYAUME UNI":
                        lookupValue = "Compliance UK";
                        break;

                    case "ITALIE":
                        lookupValue = "Compliance RE Italy";
                        break;

                    case "ESPAGNE":
                        lookupValue = "Compliance Spain";
                        break;

                    case "IRLANDE":
                        lookupValue = "Compliance Ireland";
                        break;

                    case "LUXEMBOURG":
                        lookupValue = "Compliance RE Luxembourg";
                        break;

                    case "PAYS-BAS":
                        lookupValue = "Compliance Netherlands";
                        break;

                    case "PORTUGAL":
                        lookupValue = "Compliance Portugal";
                        break;
                }
                switch (legalentity)
                {
                    case "BNPP Real Estate Investment Management Germany GmbH":
                        lookupValue = "Compliance REIM Germany";
                        break;
                    case "BNPP Real Estate Investment Management France":
                        lookupValue = "Compliance REIM France";
                        break;
                    case "BNPP Real Estate Investment Management Luxembourg SA":
                        lookupValue = "Compliance REIM Luxembourg";
                        break;
                    case "BNPP Real Estate Investment Management Italy SPA":
                        lookupValue = "Compliance REIM Italy";
                        break;
                }
                SPList oList = SPContext.Current.Web.Lists["LstSensiPays"];
                if (oList != null)
                {
                    SPQuery query = new SPQuery();
                    query.Query = "<Where><Eq><FieldRef Name='Title'/><Value Type='Text'>" + lookupValue + "</Value></Eq></Where>";
                    SPListItemCollection items = oList.GetItems(query);
                    if (items != null && items.Count > 0)
                    {
                        returnId = items[0].ID;
                    }
                }
            }
            catch { }
            return returnId;
        }

        public static string GetSensibility(SPWeb web, string localjobcodeid, string compliance)
        {
            string sensibility = string.Empty;
            localjobcodeid = localjobcodeid.PadLeft(6, '0');
            SPList wlistSensibility = web.Lists["PESensibility"];
            if (wlistSensibility != null)
            {
                SPQuery query = new SPQuery();
                //if (!string.IsNullOrEmpty(compliance))
                //    query.Query = @"<Where><And><Eq><FieldRef Name='PERefPays' /><Value Type='Text'>" + compliance + "</Value></Eq>" +
                //                "<Eq><FieldRef Name='LocalJobCode'/><Value Type='Text'>" + localjobcodeid + "</Value></Eq></And></Where>";
                //else
                    query.Query = "<Where><Eq><FieldRef Name='LocalJobCode'/><Value Type='Text'>" + localjobcodeid + "</Value></Eq></Where>";
                SPListItemCollection items = wlistSensibility.GetItems(query);
                BNPTools.WriteInLogFile("after get items sensibility");
                if (items != null && items.Count > 0)
                {
                    sensibility = items[0]["PESensibility"] + ";" + items[0]["PTSensibility"] + ";" + items[0]["PECategory"] + ";"
                        + items[0]["PESubcategory"] + ";" + items[0]["SensiDescription"] + ";" + items[0]["GlobalJobCode"];
                }
            }
            return sensibility;
        }

        public static bool UpdateLstrefepfromRefog(SPWeb web, string sqlquery)
        {
            bool isUpdated = true;
            try
            {
                using (SqlConnection myConnection = new SqlConnection())
                {

                    myConnection.ConnectionString = BNPTools.GetSettingValue(web, "ConnectionString");

                    BNPTools.WriteInLogFile("after connection string");
                    SPList splRef = web.Lists["lstrefep"];
                    SPListItemCollectionPosition itemscollectionposition = null;
                    SPQuery spquery = new SPQuery();
                    spquery.ListItemCollectionPosition = itemscollectionposition;

                    string oString = sqlquery;


                    SqlCommand oCmd = new SqlCommand(oString, myConnection);

                    myConnection.Open();
                    BNPTools.WriteInLogFile("connection opened");

                    SPListItem item = null;

                    bool bAllowunsafeUpdates = web.AllowUnsafeUpdates;
                    web.AllowUnsafeUpdates = true;
                    int i = 1;
                    using (SqlDataReader oReader = oCmd.ExecuteReader())
                    {
                        while (oReader.Read())
                        {
                            spquery.Query = @"<Where><And><Eq><FieldRef Name='RefFirstName' /><Value Type='Text'>" + oReader["PERSONNE_PRENOM_USUEL"].ToString() + "</Value></Eq>" +
                                                       "<Eq><FieldRef Name='RefLastName' /><Value Type='Text'>" + oReader["PERSONNE_NOM_USUEL"].ToString() + "</Value></Eq>" +
                                           "</And></Where>";

                            spquery.ViewXml = @"<View>
                                                   <ViewFields>
                                                        <FieldRef Name='RefFirstName'/> 
                                                        <FieldRef Name='RefLastName'/>
                                                   </ViewFields>
                                                   <RowLimit>20000</RowLimit>
                                                 </View>";
                            SPListItemCollection items = splRef.GetItems(spquery);
                            itemscollectionposition = items.ListItemCollectionPosition;
                            spquery.ListItemCollectionPosition = items.ListItemCollectionPosition;
                            SPUser contact = null;
                            string loginname = string.Empty;
                            try
                            {
                                contact = web.EnsureUser(@"BNPPI\" + oReader["I_UID"]);
                               
                                if (contact != null)
                                {
                                    loginname = @"BNPPI\" + oReader["I_UID"];
                                }
                                else
                                {
                                    contact = web.EnsureUser(@"EURO\" + oReader["I_UID"]);
                                    loginname = @"EURO\" + oReader["I_UID"];
                                }
                            }
                            catch (Exception ex)
                            {
                                BNPTools.WriteInLogFile("Exception in get user :  " + loginname + " : " + ex.Message);
                            }

                            BNPTools.WriteInLogFile("get items");
                            List<SPListItem> wlist = items.Cast<SPListItem>().Where(w => w["RefFirstName"].ToString().Equals(oReader["PERSONNE_PRENOM_USUEL"].ToString()) && w["RefLastName"].ToString().Equals(oReader["PERSONNE_NOM_USUEL"].ToString())).ToList();
                            if (wlist.Count >= 1)
                            {
                                //Update current item 
                                item = wlist[0];
                                BNPTools.WriteInLogFile("existing item");
                            }
                            else
                            {
                                try
                                {
                                    BNPTools.WriteInLogFile("non existing item");
                                    // add new item to listrefep 
                                    item = splRef.Items.Add();
                                    item["Title"] = "RefOG-" + i + "-" + oReader["I_UID"].ToString();
                                    item["RefFirstName"] = oReader["PERSONNE_PRENOM_USUEL"].ToString();
                                    item["RefLastName"] = oReader["PERSONNE_NOM_USUEL"].ToString();
                                    item["RefDepartment"] = oReader["UOPRINC_UO_NOM_FR"].ToString();
                                    item["BusinessLine"] = oReader["POLE_UO_NOM_FR"].ToString();
                                    BNPTools.WriteInLogFile("pays : " + oReader["IMMPRINC_PAYS_NOM_FR"]);
                                    item["RefPays"] = SensibilityTools.GetIDFromLookupField(oReader["IMMPRINC_PAYS_NOM_FR"].ToString(), oReader["EJ_NOM"].ToString());
                                    item["MailUser"] = oReader["PERSONNE_EMAIL_GROUPE"].ToString();


                                    //contact = web.EnsureUser(@"BNPPI\" + oReader["I_UID"]);

                                    item["RefContact"] = contact;

                                    BNPTools.WriteInLogFile("before user profile");
                                    SPServiceContext serviceContext = SPServiceContext.GetContext(web.Site);
                                    UserProfileManager upm = new UserProfileManager(serviceContext);

                                    UserProfile UserProfileContact = upm.GetUserProfile(loginname);
                                    SPUser manager = web.EnsureUser(UserProfileContact[PropertyConstants.Manager].ToString());

                                    if (manager != null)
                                    {
                                        item["RefManager"] = manager;
                                        item["MailManager"] = manager.Email;
                                    }
                                    BNPTools.WriteInLogFile("after userprofile ");
                                }
                                catch (Exception ex)
                                {

                                    BNPTools.WriteInLogFile("Exception in initialize data ref og : " + ex.Message);
                                    if (ex.Message == "Thread was being aborted.")
                                    {
                                        Thread.ResetAbort();
                                    }
                                }
                            }
                            BNPTools.WriteInLogFile("emploi_id " + oReader["EMPLOI_ID_REP_EMPLOI"]);
                            string localjobcodeid = oReader["EMPLOI_ID_REP_EMPLOI"] != null ? oReader["EMPLOI_ID_REP_EMPLOI"].ToString() : string.Empty;
                            localjobcodeid = localjobcodeid.PadLeft(6, '0');
                            BNPTools.WriteInLogFile("local job code id : " + localjobcodeid);
                            string compliance = SensibilityTools.GetStringFromLookupField(oReader["IMMPRINC_PAYS_NOM_FR"].ToString(), oReader["EJ_NOM"].ToString());
                            string sensibility = SensibilityTools.GetSensibility(web, localjobcodeid, compliance);
                            BNPTools.WriteInLogFile(sensibility);
                            if (!string.IsNullOrEmpty(sensibility))
                            {
                                item["PESensibility"] = sensibility.Split(';')[0];
                                item["PTSensibility"] = sensibility.Split(';')[1];
                                item["PECategory"] = sensibility.Split(';')[2];
                                item["PESubcategory"] = sensibility.Split(';')[3];
                                item["SensiDescription"] = sensibility.Split(';')[4];
                                item["GlobalJobCode"] = sensibility.Split(';')[5];
                            }

                            item["LocalJobCode"] = localjobcodeid;

                            item.SystemUpdate(); 

                            i++;
                            item.BreakRoleInheritance(false);
                            #region assignment to contact user
                            if (contact != null)
                            {
                                SPRoleAssignment roleAssignmentCurrentUser = new SPRoleAssignment((SPPrincipal)contact);
                                SPRoleDefinition roleReader = web.RoleDefinitions.GetByType(SPRoleType.Reader);
                                roleAssignmentCurrentUser.RoleDefinitionBindings.Add(roleReader);
                                item.RoleAssignments.Add(roleAssignmentCurrentUser);
                            }
                            #endregion

                            BNPTools.AssignPermissionTogroup(web, item, compliance);
                            BNPTools.AssignPermissionTogroup(web, item, "Global Compliance");
                            item.SystemUpdate();
                            BNPTools.WriteInLogFile("item " + i + " updated");
                        }


                    }
                    splRef.Update();
                    web.AllowUnsafeUpdates = bAllowunsafeUpdates;
                    myConnection.Close();

                }
                return isUpdated;
            }
            catch (Exception ex)
            {
                BNPTools.WriteInLogFile("Exception globale in initialize data ref og : " + ex.Message);
                if (ex.Message == "Thread was being aborted.")
                {
                    Thread.ResetAbort();
                }
                isUpdated = false;
                return isUpdated;
            }
        }


    }
}

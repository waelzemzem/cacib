﻿using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.Sensibility.EHs
{
    public class PESensibilityEH : SPItemEventReceiver
    {
        public override void ItemAdded(SPItemEventProperties properties)
        {
            Guid siteID = properties.SiteId;
            Guid webID = properties.Web.ID; 
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb wWeb = wSite.OpenWeb(webID))
                    {
                        SPListItem currentitem = properties.ListItem;
                        BNPTools.ApplyPermissions(currentuser, wWeb, currentitem, "PESensibility", "PERefPays");
                    }
                }
            });
        }



        public override void ItemUpdated(SPItemEventProperties properties)
        {
            Guid siteID = properties.SiteId;
            Guid webID = properties.Web.ID;
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb wWeb = wSite.OpenWeb(webID))
                    {
                        SPListItem currentitem = properties.ListItem;
                        try
                        {
                            BNPTools.ApplyPermissions(currentuser, wWeb, currentitem, "PESensibility", "PERefPays");
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in assign permissions update pe sensibility :" + ex.Message); 
                        }
                        try
                        {
                            SPList splRefEP = wWeb.Lists["LstRefEP"];
                            SPListItemCollectionPosition itemscollectionposition = null;
                            SPQuery spquery = new SPQuery();
                            spquery.ListItemCollectionPosition = itemscollectionposition;
                            spquery.Query = @"<Where><And><Eq><FieldRef Name='LocalJobCode' /><Value Type='Text' > " + currentitem["LocalJobCode"] + "</Value></Eq>" +
                                                          "<Eq><FieldRef Name='RefPays' /><Value Type='Lookup'>" + currentitem["PERefPays"].ToString() + "</Value></Eq>" +
                                                    "</And></Where>";
                            spquery.ViewXml = @"<View>
                                                   <ViewFields>
                                                        <FieldRef Name='LocalJobCode'/>
                                                        <FieldRef Name='RefPays'/>
                                                   </ViewFields>
                                                   <RowLimit>20000</RowLimit>
                                                 </View>";
                            //List<SPListItem> items = splRefEP.Items.Cast<SPListItem>().Where(w => w["LocalJobCode"].ToString().Equals(currentitem["LocalJobCode"])).ToList();  
                            SPListItemCollection items = splRefEP.GetItems(spquery);
                            itemscollectionposition = items.ListItemCollectionPosition;
                            spquery.ListItemCollectionPosition = items.ListItemCollectionPosition;

                            if (items.Count > 0)
                            {
                                wWeb.AllowUnsafeUpdates = true;
                                foreach (SPListItem witem in items)
                                {
                                    if (witem["LocalJobCode"] != null)
                                    {
                                        if (currentitem["PERefPays"].ToString().Equals("Global Compliance"))
                                        {
                                            if (witem["LocalJobCode"].ToString().Equals(currentitem["LocalJobCode"]))
                                            {
                                                witem["PESensibility"] = currentitem["PESensibility"];
                                                witem["PTSensibility"] = currentitem["PTSensibility"];
                                                witem["PECategory"] = currentitem["PECategory"];
                                                witem["PESubcategory"] = currentitem["PESubcategory"];
                                                witem["SensiDescription"] = currentitem["SensiDescription"];
                                                witem["GlobalJobCode"] = currentitem["GlobalJobCode"];
                                                witem.Update();
                                            }
                                        }
                                        else if (witem["LocalJobCode"].ToString().Equals(currentitem["LocalJobCode"]) && witem["RefPays"].ToString().Contains(currentitem["PERefPays"].ToString()))
                                        {
                                            witem["PESensibility"] = currentitem["PESensibility"];
                                            witem["PTSensibility"] = currentitem["PTSensibility"];
                                            witem["PECategory"] = currentitem["PECategory"];
                                            witem["PESubcategory"] = currentitem["PESubcategory"];
                                            witem["SensiDescription"] = currentitem["SensiDescription"];
                                            witem["GlobalJobCode"] = currentitem["GlobalJobCode"];
                                            witem.Update();
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in propager sensibility to individu : " + ex.Message); 
                        }
                    }
                }
            });
        }

    }
}

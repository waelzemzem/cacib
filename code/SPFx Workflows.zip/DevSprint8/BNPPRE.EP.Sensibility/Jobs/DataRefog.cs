﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BNPPRE.EP.Sensibility.Tools;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using NewEthiquePortal.UI.Tools;

namespace BNPPRE.EP.Sensibility.Jobs
{
    class DataRefog : SPJobDefinition
    {
        public DataRefog() : base()
        {

        }

        public DataRefog(string jobName, SPService service, SPServer server, SPJobLockType targetType): base (jobName, service, server, targetType)
        {
            this.Title = "DataRefog"; 
        }

        public DataRefog(string jobName, SPWebApplication webApplication) : base(jobName, webApplication, null, SPJobLockType.ContentDatabase)
        {
            this.Title = "DataRefog"; 
        }


        public override void Execute(Guid ContentDatabaseID)
        {
            try
            {
                SPWebApplication webApp = this.Parent as SPWebApplication;
                SPWeb web = webApp.Sites["sites/ep"].RootWeb;
                // this query to execute first day of month
                //string oString = "DECLARE @startOfCurrentMonth  DATETIME" +
                //"SET @startOfCurrentMonth = DATEADD(month, DATEDIFF(month, 0, CURRENT_TIMESTAMP), 0)" +
                //"Select * from[BOB_RH_UAT].[rh].[REFOG_BRUT]" +
                //"WHERE PERSONNE_DT_MAJ  >= DATEADD(month, -1, @startOfCurrentMonth)";

                string oString =string.Format("Select * from[BOB_RH_UAT].[rh].[REFOG_BRUT]" +
                "WHERE PERSONNE_DT_MAJ  >= '{0}'", BNPTools.GetSettingValue(web, "DateM")); 
                SensibilityTools.UpdateLstrefepfromRefog(web, oString); 

            }
            catch (Exception ex)
            {
                BNPTools.WriteInLogFile("Exception in job class : " + ex.Message);
                if (ex.Message == "Thread was being aborted.")
                {
                    Thread.ResetAbort();
                }
            }
        }

    }
}

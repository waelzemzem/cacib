﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using System;
using System.Collections.Generic;
using System.Security.Permissions;
using System.Web.Script.Serialization;

namespace BNPPRE.EP.PROFMANDATE.WorkflowDependencies.EH
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class MandateProTaskEH : SPItemEventReceiver
    {

        #region constantes
        const string _lstCible = "MandateProTaskList";
        const string _lst = "MandateProList"; 

        const string _ManagerTask = "Task MandatePro manager";
        const string _BmcTask = "Task MandatePro bmc";
        const string _LegalTask = "Task MandatePro legal team";
        const string _LocalTask = "Task MandatePro local compliance";
        const string _LocalCeoTask = "Task MandatePro local ceo";

        const string _ApprovementTask = "Task MandatePro Approvements";
        #endregion

        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);

            
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {



                using (SPWeb web = properties.OpenWeb())
                {
                    try
                    {
                        SPListItem currentItem = properties.ListItem;

                        if (currentItem.ParentList.Title == _lstCible)
                        {

                            string _title = currentItem.Title;

                            //manager outcome
                            string ManagerComment = string.Empty;

                            //bmc outcome
                            string BmcComment = string.Empty;
                            string BmcReservation = string.Empty;

                            // legal outome
                            string LegalComment = string.Empty;
                            string LegalReservation = string.Empty;


                            // local outcome
                            string LocalComment = string.Empty;
                            string LocalReservation = string.Empty;


                            // local ceo outcome
                            string LocalCeoComment = string.Empty;
                            string LocalCeoReservation = string.Empty;



                            switch (_title)
                            {

                                case _ManagerTask:

                                    ManagerComment = currentItem["MandateProManagerComment"] != null ? currentItem["MandateProManagerComment"].ToString() : "";
                                    break;


                                case _BmcTask:

                                    BmcComment = currentItem["MandateProBmcComment"] != null ? currentItem["MandateProBmcComment"].ToString() : "";
                                    BmcReservation = currentItem["MandateProBmcReservation"] != null ? currentItem["MandateProBmcReservation"].ToString() : "";
                                    break;

                                case _LegalTask:

                                    LegalComment = currentItem["MandateProLegalTeamComment"] != null ? currentItem["MandateProLegalTeamComment"].ToString() : "";
                                    LegalReservation = currentItem["MandateProLegalTeamReservation"] != null ? currentItem["MandateProLegalTeamReservation"].ToString() : "";
                                    break;


                                case _LocalTask:

                                    LocalComment = currentItem["MandateProLocalTeamComment"] != null ? currentItem["MandateProLocalTeamComment"].ToString() : "";
                                    LocalReservation = currentItem["MandateProLocalTeamReservation"] != null ? currentItem["MandateProLocalTeamReservation"].ToString() : "";


                                    break;

                                case _LocalCeoTask:

                                    LocalCeoComment = currentItem["MandateProLocalCeoComment"] != null ? currentItem["MandateProLocalCeoComment"].ToString() : "";
                                    LocalCeoReservation = currentItem["MandateProLocalCeoReservation"] != null ? currentItem["MandateProLocalCeoReservation"].ToString() : "";

                                    break;

                                default:
                                    break;
                            }


                            // get id from related item
                            string _strRelatedItem = currentItem[SPBuiltInFieldId.RelatedItems].ToString();
                            List<RelatedItemFieldVal> relatedItems = GetItems(_strRelatedItem);
                            RelatedItemFieldVal r = relatedItems[0];
                            int? _iditem = r.ItemId;

                            if (_iditem != null)
                            {
                                // get related item
                                SPList lst = web.Lists[_lst];
                                SPListItem curRelatedItem = lst.GetItemById(_iditem.Value);

                                // modify related item
                                bool bweballowunsafeupdates = web.AllowUnsafeUpdates; 
                                                              
                                bool toUpdate = false;

                                if (!string.IsNullOrEmpty(ManagerComment))
                                {
                                    curRelatedItem["MandateProManagerComment"] = ManagerComment;
                                    toUpdate = true; 
                                }
                                if (!string.IsNullOrEmpty(BmcComment))
                                {
                                    curRelatedItem["MandateProBmcComment"] = BmcComment;
                                    toUpdate = true;
                                }
                                if (!string.IsNullOrEmpty(BmcReservation))
                                {
                                    curRelatedItem["MandateProBmcReservation"] = BmcReservation;
                                    toUpdate = true;
                                }
                                if (!string.IsNullOrEmpty(LegalComment))
                                {
                                    curRelatedItem["MandateProLegalTeamComment"] = LegalComment;
                                    toUpdate = true;
                                }
                                if (!string.IsNullOrEmpty(LegalReservation))
                                {
                                    curRelatedItem["MandateProLegalTeamReservation"] = LegalReservation;
                                    toUpdate = true;
                                }
                                if (!string.IsNullOrEmpty(LocalComment))
                                {
                                    curRelatedItem["MandateProGlobalTeamComment"] = LocalComment;
                                    toUpdate = true; 
                                }
                                if (!string.IsNullOrEmpty(LocalReservation))
                                {
                                    curRelatedItem["MandateProLocalTeamReservation"] = LocalReservation;
                                    toUpdate = true;
                                }
                                if (!string.IsNullOrEmpty(LocalCeoComment))
                                {
                                    curRelatedItem["MandateProLocalCeoComment"] = LocalCeoComment;
                                    toUpdate = true;
                                }
                                if (!string.IsNullOrEmpty(LocalCeoReservation))
                                {
                                    curRelatedItem["MandateProLocalCeoReservation"] = LocalCeoReservation;
                                    toUpdate = true;
                                }

                                if (toUpdate)
                                {
                                    this.EventFiringEnabled = false;
                                    web.AllowUnsafeUpdates = true;
                                    curRelatedItem.Update();
                                    this.EventFiringEnabled = true;
                                    web.AllowUnsafeUpdates = bweballowunsafeupdates;
                                }                               
                                
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0,
                                                              new SPDiagnosticsCategory("EP - Mandat Pro", TraceSeverity.Unexpected, EventSeverity.Error),
                                                              TraceSeverity.Unexpected, ex.Message, ex.Message);
                    }
                }
            });

        }


        public List<RelatedItemFieldVal> GetItems(string jsonString)
        {
            JavaScriptSerializer deserializer = new JavaScriptSerializer();
            object deserializeOutput = deserializer.Deserialize<List<RelatedItemFieldVal>>(jsonString);
            List<RelatedItemFieldVal> l = ((List<RelatedItemFieldVal>)deserializeOutput);
            return l;
         
        }

        public string GetItems(List<RelatedItemFieldVal> relatedItems)
        {
            string jsonString = string.Empty;
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            jsonString = serializer.Serialize(relatedItems);
            return jsonString;
        }

    }
}
﻿using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.PROFMANDATE.WorkflowDependencies.EH
{
   public class MandateProEH : SPItemEventReceiver
    {

        /// <summary>
        /// Item Added of mandat pro list 
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            Guid siteID = properties.SiteId;
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb ElevatedWeb = wSite.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentitem = properties.ListItem;
                            //BNPTools.ApplyPermissions(currentuser, ElevatedWeb, currentitem, "MandateProList", "MandateProQLocalCountry");
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in Mandat pro EH item added : " + ex.Message);
                        }
                    }
                }
            });
        }


        /// <summary>
        /// Item Updated of MandatePro  list
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            Guid siteID = properties.SiteId;
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb ElevatedWeb = wSite.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentitem = properties.ListItem;
                            //BNPTools.ApplyPermissions(currentuser, ElevatedWeb, currentitem, "MandateProList", "MandateProQLocalCountry");
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in Mandat pro EH item updated : " + ex.Message);
                        }
                    }
                }
            });

        }

    }
}
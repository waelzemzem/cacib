﻿using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.Gift.Workflow_Dependencies.EH
{
    public class GiftTaskEH : SPItemEventReceiver
    {
        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            Guid webID = properties.Web.ID;
            Guid siteID = properties.SiteId;
            string currentusername = properties.Web.CurrentUser.Name;
            string currentuseruid = properties.Web.CurrentUser.LoginName;
            if (currentuseruid.Contains("|"))
                currentuseruid = currentuseruid.Split('|')[1]; 
            SPSecurity.RunWithElevatedPrivileges(delegate
            {
                using (SPSite site = new SPSite(siteID))
                {
                    using (SPWeb web = site.OpenWeb(webID))
                    {
                        try
                        {
                            SPListItem currentItem = properties.ListItem;
                            string[] strRelatedItems = currentItem[SPBuiltInFieldId.RelatedItems].ToString().Split(',');
                            string strCurrentItemID = strRelatedItems[0].Split(':')[1];

                            string TaskTitle = currentItem["Title"].ToString();
                            string commentManager = currentItem["GiftManagerComment"] != null ? currentItem["GiftManagerComment"].ToString() : "";
                            string commentLocalCompliance = currentItem["GiftLocalComplianceComment"] != null ? currentItem["GiftLocalComplianceComment"].ToString() : "";
                            string commentGlobalCompliance = currentItem["GiftGlobalComplianceComment"] != null ? currentItem["GiftGlobalComplianceComment"].ToString() : "";

                            string restrictedpep = currentItem["RestrictedPEP"] != null ? currentItem["RestrictedPEP"].ToString() : "No"; 

                            SPList currentList = web.Lists["Gift"];
                            SPListItem currentRelatedItem = currentList.GetItemById(int.Parse(strCurrentItemID));
                           

                            SPList registergiftsInvit = web.Lists["RegisterGiftsInvitations"];
                            SPQuery queryregister = new SPQuery();
                            queryregister.Query = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + currentRelatedItem.Title + "</Value></Eq></Where>";
                            SPListItem currentregistergift = registergiftsInvit.GetItems(queryregister).Cast<SPListItem>().FirstOrDefault();
                            web.AllowUnsafeUpdates = true;
                            if (TaskTitle.Contains("Manager"))
                            {
                                currentRelatedItem["GiftManagerComment"] = commentManager;
                                if (currentusername != "SharePoint App")
                                {
                                    currentregistergift["GiftManagerDate"] = DateTime.Now;
                                    currentregistergift["GiftManagerRationale"] = commentManager; 
                                    currentregistergift["GiftManagerName"] = currentusername;
                                    currentregistergift["GiftManagerUID"] = currentuseruid.Split('\\')[1];
                                    currentregistergift["GiftManagerDecision"] = currentItem["GiftOutcomeManager"];
                                }
                            }
                            if (TaskTitle.Contains("Local Compliance"))
                            {
                                currentRelatedItem["GiftLocalComplianceComment"] = commentLocalCompliance;
                                currentRelatedItem["RestrictedPEP"] = restrictedpep; 
                                if (currentusername != "SharePoint App")
                                {
                                    currentregistergift["GiftCPLRationale"] = commentLocalCompliance; 
                                    currentregistergift["GiftCPLDate"] = DateTime.Now;
                                    currentregistergift["GiftCPLName"] = currentusername;
                                    currentregistergift["GiftCPLUID"] = currentuseruid.Split('\\')[1];
                                    currentregistergift["GiftCPLDecision"] = currentItem["GiftOutcomeLocalCompliance"]; 
                                }
                            }
                            if (TaskTitle.Contains("Global Compliance"))
                            {
                                currentRelatedItem["GiftGlobalComplianceComment"] = commentGlobalCompliance;
                                if (currentusername != "SharePoint App")
                                {
                                    currentregistergift["GiftGCPLRationale"] = commentGlobalCompliance;
                                    currentregistergift["GiftGCPLDate"] = DateTime.Now;
                                    currentregistergift["GiftGCPLName"] = currentusername;
                                    currentregistergift["GiftGCPLUID"] = currentuseruid.Split('\\')[1];
                                    currentregistergift["GiftGCPLDecision"] = currentItem["GiftOutcomeGlobalCompliance"];
                                }
                            }

                            if (currentusername != "SharePoint App")
                            {
                                currentregistergift.Update();
                            }

                            currentRelatedItem.Update();
                            web.AllowUnsafeUpdates = false;
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in EH : Gift Task" + ex.Message);
                        }
                    }
                }
            }); 
           
        }
    }
}

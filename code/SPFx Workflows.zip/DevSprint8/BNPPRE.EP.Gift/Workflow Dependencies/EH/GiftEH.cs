﻿using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.Gift.Workflow_Dependencies.EH
{
    public class GiftEH : SPItemEventReceiver
    {

        /// <summary>
        /// Item Added of Gift list 
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            Guid siteID = properties.SiteId;
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb ElevatedWeb = wSite.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentitem = properties.ListItem;
                            addregistergift(ElevatedWeb, currentitem, "add");
                           //BNPTools.ApplyPermissions(currentuser, ElevatedWeb, currentitem, "Gift", "GiftQLocalCountry");
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in Gift EH item added : " + ex.Message);
                        }
                    }
                }
            });
        }

        /// <summary>
        /// Add Gift to register
        /// </summary>
        /// <param name="ElevatedWeb"></param>
        /// <param name="currentitem"></param>
        private static void addregistergift(SPWeb ElevatedWeb, SPListItem currentitem, string update)
        {
            SPFieldUserValue userValue = new SPFieldUserValue(ElevatedWeb, currentitem[SPBuiltInFieldId.Author].ToString());
            SPUser author = userValue.User;
            BNPTools.WriteInLogFile("after uservalue gift L54");
            SPList lstrefep = ElevatedWeb.Lists["LstRefEP"];
            SPListItemCollectionPosition itemscollectionposition = null;
            SPQuery query = new SPQuery();
            query.ListItemCollectionPosition = itemscollectionposition;
            query.Query = "<Where>" +
                               "<Eq><FieldRef Name='MailUser' /><Value Type='Text'>" + author.Email + "</Value></Eq>" +
                         "</Where>";
            query.ViewXml = @"<View>
                                                   <ViewFields>
                                                        <FieldRef Name='RefFirstName'/> 
                                                        <FieldRef Name='RefLastName'/>
                                                        <FieldRef Name='RefContact'/> 
                                                        <FieldRef Name='MailUser'/> 
                                                        <FieldRef Name='RefManager'/> 
                                                        <FieldRef Name='isComex'/> 
                                                        <FieldRef Name='RefPays'/> 
                                                        <FieldRef Name='BusinessLine'/> 
                                                        <FieldRef Name='RefDepartment'/> 
                                                   </ViewFields>
                                                   <RowLimit>20000</RowLimit>
                                                 </View>";
            SPListItemCollection items = lstrefep.GetItems(query);
            itemscollectionposition = items.ListItemCollectionPosition;
            query.ListItemCollectionPosition = items.ListItemCollectionPosition;

            List<SPListItem> wlist = items.Cast<SPListItem>().Where(w => ((w["MailUser"] != null) && (w["MailUser"].ToString().ToLower().Equals(author.Email.ToLower())))).ToList();
            SPListItem lstrefepAuthor = null;
            if (wlist.Count > 0)
            {
                lstrefepAuthor = wlist[0];
            }
            string group = lstrefepAuthor["RefPays"].ToString().Split('#')[1];
            BNPTools.WriteInLogFile("L63 Item updated of gift  " + group);
            SPList registerGiftInvit = ElevatedWeb.Lists["RegisterGiftsInvitations"];
            BNPTools.WriteInLogFile("L65 Item Added of gift");

            SPQuery queryManager = new SPQuery();
            queryManager.Query = "<Where>" +
                               "<Eq><FieldRef Name='MailUser' /><Value Type='Text'>" + currentitem["GiftManager"] + "</Value></Eq>" +
                            "</Where>";
            SPListItem lstrefepManager = lstrefep.GetItems(queryManager).Cast<SPListItem>().FirstOrDefault();
            BNPTools.WriteInLogFile("L72 Item Added of gift");
            ElevatedWeb.AllowUnsafeUpdates = true;
            SPListItem newitem = registerGiftInvit.Items.Add();
            newitem["Title"] = currentitem.Title;
            newitem["RegisterEmployeeDate"] = currentitem[SPBuiltInFieldId.Created_x0020_Date];
            newitem["RegisterEmployeeUID"] = author.LoginName.Split('|')[1].Split('\\')[1];
            newitem["RegisterEmployeeName"] = author.Name;


            BNPTools.WriteInLogFile("L81 Item Added of gift");
            newitem["RegisterEmployeeBusinessLine"] = lstrefepAuthor["BusinessLine"];
            newitem["RegisterEmployeeEntity"] = lstrefepAuthor["RefDepartment"];

            newitem["Typeofrelation"] = currentitem["GiftQ16"];
            newitem["FullNameRelation"] = currentitem["GiftQ7"];
            newitem["ThirdPartyName"] = currentitem["GiftQ7"];
            newitem["TypeofGiftInvitation"] = currentitem["GiftQ1"];
            newitem["NatureofGiftInvitation"] = currentitem["Gift_Type"];
            newitem["ReceivedorGiven"] = currentitem["GiftQ2"];
            newitem["EstimatedValue"] = currentitem["GiftQ12"];
            newitem["GiftPEP"] = currentitem["GiftQ6_1"];
            newitem["HighRisk"] = currentitem["Gift_Q38"];
            newitem["KYStatus"] = currentitem["Gift_Q40"];
            //newitem["Travel"] = currentitem[""];
            newitem["IntragroupInvitation"] = currentitem["Gift_Q30"];
            //newitem["GuestNumber"] = currentitem[""];
            //newitem["DescriptionGuest"] = currentitem[""];
            //newitem["BackgroundRelationship"] = currentitem[""];
            //newitem["RationaleInvitation"] = currentitem[""]; 

            if (lstrefepManager != null)
            { 
                //Manager
                SPFieldUserValue managerValue = new SPFieldUserValue(ElevatedWeb, lstrefepManager["RefContact"].ToString());
                SPUser Manager = managerValue.User;
                //newitem["GiftManagerDate"] = DateTime.Now;
                newitem["GiftManagerUID"] = Manager.LoginName.Split('|')[1].Split('\\')[1];
                newitem["GiftManagerName"] = lstrefepManager["RefFirstName"] + " " + lstrefepManager["RefLastName"];
            }   
            else
            {
                newitem["GiftManagerUID"] = currentitem["GiftManager"];
                newitem["GiftManagerName"] = currentitem["GiftManager"].ToString().Split('@')[0]; 
            }

            if (update == "update")
            {
                newitem["GiftManagerRationale"] = currentitem["GiftManagerComment"];
                newitem["GiftCPLRationale"] = currentitem["GiftLocalComplianceComment"]; 
            }
            //this.EventFiringEnabled = false; 
            newitem.Update();
            BNPTools.WriteInLogFile("Item Added");
            newitem.BreakRoleInheritance(false);


            if (!string.IsNullOrEmpty(group))
            {
                BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, group);
            }
            BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, "Global Compliance");
            SPGroup groupOwner = ElevatedWeb.SiteGroups.Cast<SPGroup>().Where(g => g.Name.Contains("Owners")).FirstOrDefault();
            if (groupOwner != null)
                BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, groupOwner.Name);
            BNPTools.WriteInLogFile("Item Permission assigned");
            ElevatedWeb.AllowUnsafeUpdates = false;
        }

        /// <summary>
        /// Item Updated of Gift list
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            Guid siteID = properties.SiteId;
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb ElevatedWeb = wSite.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentitem = properties.ListItem;

                            //BNPTools.ApplyPermissions(currentuser, ElevatedWeb, currentitem, "Gift", "GiftQLocalCountry");
                            SPList splregisterGiftsInvitations = ElevatedWeb.Lists["RegisterGiftsInvitations"];
                            SPQuery query = new SPQuery();
                            query.Query = "<Where>" +
                                                    "<Eq><FieldRef Name='Title' /><Value Type='Text'>" + currentitem.Title + "</Value></Eq>" +
                                              "</Where>";
                            SPListItem registergiftItem = splregisterGiftsInvitations.GetItems(query).Cast<SPListItem>().FirstOrDefault();
                            if (registergiftItem == null)
                            {
                                BNPTools.WriteInLogFile("Inside gift eh item updated -- before addregistercoi");
                                addregistergift(ElevatedWeb, currentitem, "update");
                            }
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in Gift EH item updated : " + ex.Message);
                        }
                    }
                }
            });

        }

    }
}

﻿using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.Gift.Workflow_Dependencies.EH
{
    public class InvitationEH : SPItemEventReceiver
    {

        /// <summary>
        /// Item Added of Invitation list 
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            Guid siteID = properties.SiteId;
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb ElevatedWeb = wSite.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentitem = properties.ListItem;
                           //BNPTools.ApplyPermissions(currentuser, ElevatedWeb, currentitem, "Invitation", "InvitationQLocalCoutry");
                            addregisterinvitation(ElevatedWeb, currentitem, "add");
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in Gift EH item added : " + ex.Message);
                        }
                    }
                }
            });
        }

        /// <summary>
        /// Add Gift to register
        /// </summary>
        /// <param name="ElevatedWeb"></param>
        /// <param name="currentitem"></param>
        private static void addregisterinvitation(SPWeb ElevatedWeb, SPListItem currentitem, string update)
        {
            SPFieldUserValue userValue = new SPFieldUserValue(ElevatedWeb, currentitem[SPBuiltInFieldId.Author].ToString());
            SPUser author = userValue.User;
            BNPTools.WriteInLogFile("after uservalue invitation L54");
            SPList lstrefep = ElevatedWeb.Lists["LstRefEP"];
            SPListItemCollectionPosition itemscollectionposition = null;
            SPQuery query = new SPQuery();
            query.ListItemCollectionPosition = itemscollectionposition;
            query.Query = "<Where>" +
                               "<Eq><FieldRef Name='MailUser' /><Value Type='Text'>" + author.Email + "</Value></Eq>" +
                         "</Where>";
            query.ViewXml = @"<View>
                                                   <ViewFields>
                                                        <FieldRef Name='RefFirstName'/> 
                                                        <FieldRef Name='RefLastName'/>
                                                        <FieldRef Name='RefContact'/> 
                                                        <FieldRef Name='MailUser'/> 
                                                        <FieldRef Name='RefManager'/> 
                                                        <FieldRef Name='isComex'/> 
                                                        <FieldRef Name='RefPays'/> 
                                                        <FieldRef Name='BusinessLine'/> 
                                                        <FieldRef Name='RefDepartment'/> 
                                                   </ViewFields>
                                                   <RowLimit>20000</RowLimit>
                                                 </View>";
            SPListItemCollection items = lstrefep.GetItems(query);
            itemscollectionposition = items.ListItemCollectionPosition;
            query.ListItemCollectionPosition = items.ListItemCollectionPosition;

            List<SPListItem> wlist = items.Cast<SPListItem>().Where(w => ((w["MailUser"] != null) && (w["MailUser"].ToString().ToLower().Equals(author.Email.ToLower())))).ToList();
            SPListItem lstrefepAuthor = null;
            if (wlist.Count > 0)
            {
                lstrefepAuthor = wlist[0];
            }
            string group = lstrefepAuthor["RefPays"].ToString().Split('#')[1];
            BNPTools.WriteInLogFile("L63 Item updated of invitation  " + group);
            SPList registerGiftInvit = ElevatedWeb.Lists["RegisterGiftsInvitations"];
            SPQuery queryregister = new SPQuery(); 
            queryregister.Query = "<Where>" +
                                        "<Eq><FieldRef Name='Title' /><Value Type='Text'>" + currentitem.Title + "</Value></Eq>" +
                                   "</Where>";
            SPListItem registeritem =  registerGiftInvit.GetItems(queryregister).Cast<SPListItem>().FirstOrDefault();
            if (registeritem == null)
            {
                BNPTools.WriteInLogFile("L65 Item Added of invitation");

                SPQuery queryManager = new SPQuery();
                queryManager.Query = "<Where>" +
                                   "<Eq><FieldRef Name='MailUser' /><Value Type='Text'>" + currentitem["InvitationManager"] + "</Value></Eq>" +
                                "</Where>";
                SPListItem lstrefepManager = lstrefep.GetItems(queryManager).Cast<SPListItem>().FirstOrDefault();
                BNPTools.WriteInLogFile("L72 Item Added of invitation");

                ElevatedWeb.AllowUnsafeUpdates = true;
                SPListItem newitem = registerGiftInvit.Items.Add();
                newitem["Title"] = currentitem.Title;
                newitem["RegisterEmployeeDate"] = currentitem[SPBuiltInFieldId.Created_x0020_Date];
                newitem["RegisterEmployeeUID"] = author.LoginName.Split('|')[1].Split('\\')[1];
                newitem["RegisterEmployeeName"] = author.Name;


                BNPTools.WriteInLogFile("L81 Item Added of invitation");
                newitem["RegisterEmployeeBusinessLine"] = lstrefepAuthor["BusinessLine"];
                newitem["RegisterEmployeeEntity"] = lstrefepAuthor["RefDepartment"];

                newitem["Typeofrelation"] = currentitem["InvitationQ10"];
                newitem["FullNameRelation"] = currentitem["InvitationQ3"];
                newitem["ThirdPartyName"] = currentitem["InvitationQ3"];
                newitem["TypeofGiftInvitation"] = currentitem["InvitationQ2"];
                newitem["NatureofGiftInvitation"] = currentitem["InvitationQ7"]; // InvitationQ14
                newitem["ReceivedorGiven"] = currentitem["InvitationQ1"];
                newitem["EstimatedValue"] = currentitem["InvitationQ17"];//InvitationQ8
                newitem["GiftPEP"] = currentitem["InvitationPEP"];
                newitem["HighRisk"] = currentitem["InvitationQ47"];
                newitem["KYStatus"] = currentitem["InvitationQ49"];
                newitem["Travel"] = currentitem["InvitationQ19"];
                newitem["IntragroupInvitation"] = currentitem["InvitationQ9_2"];
                newitem["GuestNumber"] = currentitem["InvitationQ9_1"];
                newitem["DescriptionGuest"] = currentitem["InvitationQ14"];
                //newitem["BackgroundRelationship"] = currentitem[""];
                //newitem["RationaleInvitation"] = currentitem[""]; 

                if (lstrefepManager != null)
                {
                    //Manager
                    SPFieldUserValue managerValue = new SPFieldUserValue(ElevatedWeb, lstrefepManager["RefContact"].ToString());
                    SPUser Manager = managerValue.User;
                    //newitem["GiftManagerDate"] = DateTime.Now;
                    newitem["GiftManagerUID"] = Manager.LoginName.Split('|')[1].Split('\\')[1];
                    newitem["GiftManagerName"] = lstrefepManager["RefFirstName"] + " " + lstrefepManager["RefLastName"];
                }
                else
                {
                    newitem["GiftManagerUID"] = currentitem["InvitationManager"];
                    newitem["GiftManagerName"] = currentitem["InvitationManager"].ToString().Split('@')[0];
                }

                if (update == "update")
                {
                    newitem["GiftManagerRationale"] = currentitem["InvitationManagerComment"];
                    newitem["GiftCPLRationale"] = currentitem["InvitationLocalComplianceComment"];
                }
                //this.EventFiringEnabled = false; 
                newitem.Update();
                BNPTools.WriteInLogFile("Item Added");
                newitem.BreakRoleInheritance(false);


                if (!string.IsNullOrEmpty(group))
                {
                    BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, group);
                }
                BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, "Global Compliance");
                SPGroup groupOwner = ElevatedWeb.SiteGroups.Cast<SPGroup>().Where(g => g.Name.Contains("Owners")).FirstOrDefault();
                if (groupOwner != null)
                    BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, groupOwner.Name);
                BNPTools.WriteInLogFile("Item Permission assigned");
                ElevatedWeb.AllowUnsafeUpdates = false;
            }
        }

        /// <summary>
        /// Item Updated of Invitation list
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            Guid siteID = properties.SiteId;
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb ElevatedWeb = wSite.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentitem = properties.ListItem;

                            //BNPTools.ApplyPermissions(currentuser, ElevatedWeb, currentitem, "Invitation", "InvitationQLocalCoutry");
                            SPList splregisterGiftsInvitations = ElevatedWeb.Lists["RegisterGiftsInvitations"];
                            SPQuery query = new SPQuery();
                            query.Query = "<Where>" +
                                                    "<Eq><FieldRef Name='Title' /><Value Type='Text'>" + currentitem.Title + "</Value></Eq>" +
                                              "</Where>";
                            SPListItem registergiftItem = splregisterGiftsInvitations.GetItems(query).Cast<SPListItem>().FirstOrDefault();
                            if (registergiftItem == null)
                            {
                                BNPTools.WriteInLogFile("Inside gift eh item updated -- before addregistercoi");
                                addregisterinvitation(ElevatedWeb, currentitem, "update");
                            }
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in Invitation EH item updated : " + ex.Message);
                        }
                    }
                }
            });

        }

    }
}

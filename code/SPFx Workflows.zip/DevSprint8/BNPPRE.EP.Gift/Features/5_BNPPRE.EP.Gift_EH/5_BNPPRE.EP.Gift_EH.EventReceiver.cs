using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace BNPPRE.EP.Gift.Features.EP_Gift_EH
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("8997a18d-1657-4d0e-aea4-1be3eff7c41f")]
    public class EP_Gift_EHEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.
        string lst_title = "GiftWorkflowTaskList";
        string _class = "BNPPRE.EP.Gift.Workflow_Dependencies.EH.GiftTaskEH";
        string _className = "GiftTaskEH";

        string lst_title_gift = "Gift";
        string _class_gift = "BNPPRE.EP.Gift.Workflow_Dependencies.EH.GiftEH";
        string _className_gift = "GiftEH";

        string lst_title_invitation = "Invitation";
        string _class_invitation = "BNPPRE.EP.Gift.Workflow_Dependencies.EH.InvitationEH";
        string _className_invitation = "InvitationEH";

        string lst_title_task_invitation = "InvitationWorkflowTaskList";
        string _class_task_invitation = "BNPPRE.EP.Gift.Workflow_Dependencies.EH.InvitationTaskEH";
        string _className_task_invitation = "InvitationTaskEH";

        const SPEventReceiverType eventTypeAdded = SPEventReceiverType.ItemAdded;
        const SPEventReceiverType eventTypeUpdated = SPEventReceiverType.ItemUpdated;

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                SPListCollection lstCollection = rootweb.Lists;
                SPList ListC = null, ListGift = null, ListTaskInvitation = null , ListInvitation = null ;
                try
                {
                    ListC = lstCollection.TryGetList(lst_title);
                    ListGift = lstCollection.TryGetList(lst_title_gift); 
                    ListTaskInvitation = lstCollection.TryGetList(lst_title_task_invitation);
                    ListInvitation = lstCollection.TryGetList(lst_title_invitation); 
                }
                catch (Exception ex)
                {
                    BNPTools.WriteInLogFile("Exception in feature Gift/Invitations EHs : " + ex.Message);
                }
                if (null != ListC)
                {
                    SPEventReceiverDefinition def = ListC.EventReceivers.Add();
                    def.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    def.Class = _class;
                    def.Name = _className;
                    def.Type = SPEventReceiverType.ItemUpdated;
                    def.SequenceNumber = 1000;
                    def.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    def.Update();
                }
                if (null != ListTaskInvitation)
                {
                    SPEventReceiverDefinition def_Invitation = ListTaskInvitation.EventReceivers.Add();
                    def_Invitation.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    def_Invitation.Class = _class_task_invitation;
                    def_Invitation.Name = _className_task_invitation;
                    def_Invitation.Type = SPEventReceiverType.ItemUpdated;
                    def_Invitation.SequenceNumber = 1000;
                    def_Invitation.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    def_Invitation.Update();
                }

                if (null != ListGift)
                {
                    SPEventReceiverDefinition defGift = ListGift.EventReceivers.Add();
                    defGift.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    defGift.Class = _class_gift;
                    defGift.Name = _className_gift;
                    defGift.Type = SPEventReceiverType.ItemAdded;
                    defGift.SequenceNumber = 1000;
                    defGift.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    defGift.Update();

                    SPEventReceiverDefinition defGiftUpdated = ListGift.EventReceivers.Add();
                    defGiftUpdated.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    defGiftUpdated.Class = _class_gift;
                    defGiftUpdated.Name = _className_gift;
                    defGiftUpdated.Type = SPEventReceiverType.ItemUpdated;
                    defGiftUpdated.SequenceNumber = 1000;
                    defGiftUpdated.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    defGiftUpdated.Update();
                }

                if (null != ListInvitation)
                {
                    SPEventReceiverDefinition defInvitation = ListInvitation.EventReceivers.Add();
                    defInvitation.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    defInvitation.Class = _class_invitation;
                    defInvitation.Name = _className_invitation;
                    defInvitation.Type = SPEventReceiverType.ItemAdded;
                    defInvitation.SequenceNumber = 1000;
                    defInvitation.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    defInvitation.Update();

                    SPEventReceiverDefinition definvitationUpdated = ListInvitation.EventReceivers.Add();
                    definvitationUpdated.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    definvitationUpdated.Class = _class_invitation;
                    definvitationUpdated.Name = _className_invitation;
                    definvitationUpdated.Type = SPEventReceiverType.ItemUpdated;
                    definvitationUpdated.SequenceNumber = 1000;
                    definvitationUpdated.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    definvitationUpdated.Update();
                }
            });
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                SPListCollection lstCollection = rootweb.Lists;


                SPList ListC = null, ListGift = null, ListTaskInvitation = null, List_Invitation = null;
                try
                {
                    ListC = lstCollection.TryGetList(lst_title);
                    List_Invitation = lstCollection.TryGetList(lst_title_invitation);
                    ListGift = lstCollection.TryGetList(lst_title_gift);
                    ListTaskInvitation = lstCollection.TryGetList(lst_title_task_invitation); 
                }
                catch (Exception ex)
                {
                   BNPTools.WriteInLogFile("Exception in desactivate feature Gift/Invitations EHs : " + ex.Message);
                }
                if (null != ListC)
                {
                    DeleteEvents(ListC);
                }
                
                if (null != ListTaskInvitation)
                {
                    DeleteEvents(ListTaskInvitation); 
                }
                
                if (null != ListGift)
                {
                    DeleteEvents(ListGift); 
                }

                if (null != List_Invitation)
                {
                    DeleteEvents(List_Invitation); 
                }
            });
        }

        private static void DeleteEvents(SPList list)
        {
            SPEventReceiverDefinitionCollection erdc = list.EventReceivers;
            List<SPEventReceiverDefinition> eventsToDelete = new List<SPEventReceiverDefinition>();

            foreach (SPEventReceiverDefinition erd in erdc)
            {
                if (erd != null)
                {
                    try
                    {
                        eventsToDelete.Add(erd);
                    }
                    catch (Exception) { }
                }
            }
            foreach (SPEventReceiverDefinition er in eventsToDelete)
            {
                if (er.Type == eventTypeAdded || er.Type == eventTypeUpdated)
                {
                    er.Delete();
                }
            }
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace BNPPRE.EP.OBI.Features._4_BNPPRE.EP.OBI_EH
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("903b48f4-1572-4c97-9ecc-bba3924767ba")]
    public class _4_BNPPREEPEventReceiver : SPFeatureReceiver
    {
        string lst_title = "OBITaskList";
        string lst_obi = "ListOBI"; 
        string _class = "BNPPRE.EP.OBI.WorkflowDependencies.EH.OBITaskEH";
        string _className = "OBITaskEH";
        
        string _class_obi = "BNPPRE.EP.OBI.WorkflowDependencies.EH.OBIEH";
        string _className_obi = "OBIEH";


        const SPEventReceiverType eventTypeAdded = SPEventReceiverType.ItemAdded;
        const SPEventReceiverType eventTypeUpdated = SPEventReceiverType.ItemUpdated;

        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                SPListCollection lstCollection = rootweb.Lists;
                SPList ListC = null;
                SPList ListOBI = null;
                try
                {
                    ListC = lstCollection.TryGetList(lst_title);
                    ListOBI = lstCollection.TryGetList(lst_obi);
                }
                catch //(Exception ex)
                {
                    //Tools.BNPTools.WriteInLogFile("Exception in feature EHs : " + ex.Message);
                }
                if (null != ListC)
                {

                    //  DeleteEvents(ListC);
                    SPEventReceiverDefinition def = ListC.EventReceivers.Add();
                    def.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    def.Class = _class;
                    def.Name = _className;
                    def.Type = SPEventReceiverType.ItemUpdated;
                    def.SequenceNumber = 1000;
                    def.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    def.Update();
                }
                if (null != ListOBI)
                {
                    SPEventReceiverDefinition def_obi_added = ListOBI.EventReceivers.Add();
                    def_obi_added.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    def_obi_added.Class = _class_obi;
                    def_obi_added.Name = _className_obi;
                    def_obi_added.Type = SPEventReceiverType.ItemAdded;
                    def_obi_added.SequenceNumber = 1000;
                    def_obi_added.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    def_obi_added.Update();


                    SPEventReceiverDefinition def_obi = ListOBI.EventReceivers.Add();
                    def_obi.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    def_obi.Class = _class_obi;
                    def_obi.Name = _className_obi;
                    def_obi.Type = SPEventReceiverType.ItemUpdated;
                    def_obi.SequenceNumber = 1000;
                    def_obi.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    def_obi.Update();
                }
            });
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                SPListCollection lstCollection = rootweb.Lists;


                SPList ListC = null;
                try
                {
                    ListC = lstCollection.TryGetList(lst_title);
                    //ListC = rootweb.GetList(rootweb.ServerRelativeUrl.TrimEnd('/') + "/Lists/LstRefEp");
                }
                catch //(Exception ex)
                {
                    //Tools.BNPTools.WriteInLogFile("Exception in desactivate feature EHs : " + ex.Message);
                }
                if (null != ListC)
                {
                    DeleteEvents(ListC);
                }
            });
        }

        private static void DeleteEvents(SPList list)
        {
            SPEventReceiverDefinitionCollection erdc = list.EventReceivers;
            List<SPEventReceiverDefinition> eventsToDelete = new List<SPEventReceiverDefinition>();

            foreach (SPEventReceiverDefinition erd in erdc)
            {
                if (erd != null)
                {
                    try
                    {
                        eventsToDelete.Add(erd);
                    }
                    catch (Exception) { }
                }
            }
            foreach (SPEventReceiverDefinition er in eventsToDelete)
            {
                if (er.Type == eventTypeAdded || er.Type == eventTypeUpdated)
                {
                    er.Delete();
                }
            }
        }

        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

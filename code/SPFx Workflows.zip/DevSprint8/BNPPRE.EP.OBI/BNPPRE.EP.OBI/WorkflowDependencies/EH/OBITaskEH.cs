﻿using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.OBI.WorkflowDependencies.EH
{
    public class OBITaskEH : SPItemEventReceiver
    {
        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            string currentuserloginname = properties.Web.CurrentUser.LoginName.Split('|')[1].Split('\\')[1];
            string currentusername = properties.Web.CurrentUser.Name; 


            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite site = new SPSite(properties.SiteId))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentItem = properties.ListItem;
                            string[] strRelatedItems = currentItem[SPBuiltInFieldId.RelatedItems].ToString().Split(',');
                            string strCurrentItemID = strRelatedItems[0].Split(':')[1];

                            string TaskTitle = currentItem["Title"].ToString();
                            string managercomment = "", localcomment = "", globalcomment = "", obifollowupcomment = "", obiDeadlineFollowUp = "", globalobifollowupcomment = "", globalobiDeadlineFollowUp = "";

                            SPList currentList = web.Lists["ListOBI"];
                            SPListItem currentRelatedItem = currentList.GetItemById(int.Parse(strCurrentItemID));

                            SPList registerobi = web.Lists["RegisterOBIList"];
                            SPQuery queryregister = new SPQuery();
                            queryregister.Query = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + currentRelatedItem.Title + "</Value></Eq></Where>";
                            SPListItem currentregisterobi = registerobi.GetItems(queryregister).Cast<SPListItem>().FirstOrDefault();
                            web.AllowUnsafeUpdates = true;
                            if (TaskTitle.Contains("Manager"))
                            {
                                managercomment = currentItem["ObiManagerComment"] != null ? currentItem["ObiManagerComment"].ToString() : "";
                                currentregisterobi["ManagerNatureofDecision"] = currentItem["ObiOutcomeManager"];//Approved, Rejected, Accepted with reservations
                                currentregisterobi["ManagerRationale"] = currentItem["ObiManagerComment"];
                                currentregisterobi["ManagerDateDecision"] = DateTime.Now;
                            }
                            if (TaskTitle.Contains("local"))
                            {
                                localcomment = currentItem["ObiLocalComment"] != null ? currentItem["ObiLocalComment"].ToString() : "";
                                obifollowupcomment = currentItem["ObiFollowUpActions"] != null ? currentItem["ObiFollowUpActions"].ToString() : "";
                                obiDeadlineFollowUp = currentItem["ObiDeadlineFollowUp"] != null ? currentItem["ObiDeadlineFollowUp"].ToString() : "";
                                if (currentusername != "SharePoint App")
                                {
                                    currentregisterobi["ComplianceOfficerUserID"] = currentuserloginname;
                                    currentregisterobi["ComplianceName"] = currentusername;

                                    currentregisterobi["ComplianceNatureofDecision"] = currentItem["ObiOutcomeFirstPhase"];//Approved, Rejected, Accepted with reservations
                                    currentregisterobi["ComplianceRationale"] = currentItem["ObiLocalComment"];
                                    currentregisterobi["ComplianceMitigations"] = currentItem["ObiFollowUpActions"];
                                    currentregisterobi["ComplianceDateDecision"] = DateTime.Now;
                                    //à mettre à jour 
                                    currentregisterobi["OBITypeList"] = currentItem["OBITypeList"];
                                    currentregisterobi["OBISubTypeList"] = currentItem["OBISubTypeList"];
                                }
                            }
                            if (TaskTitle.Contains("global"))
                            {
                                globalcomment = currentItem["ObiGlobalComment"] != null ? currentItem["ObiGlobalComment"].ToString() : "";
                                globalobifollowupcomment = currentItem["ObiGlobalFollowUpActions"] != null ? currentItem["ObiGlobalFollowUpActions"].ToString() : "";
                                globalobiDeadlineFollowUp = currentItem["ObiGlobaldeadlineFollowUp"] != null ? currentItem["ObiGlobaldeadlineFollowUp"].ToString() : "";

                                if (currentusername != "SharePoint App")
                                {
                                    currentregisterobi["ComplianceOfficerSLUserID"] = currentuserloginname;
                                    currentregisterobi["ComplianceSLName"] = currentusername;

                                    currentregisterobi["ComplianceSLNatureofDecision"] = currentItem["ObiOutcomeSecondPhase"];
                                    currentregisterobi["ComplianceSLRationale"] = currentItem["ObiGlobalComment"];
                                    currentregisterobi["ComplianceSLMitigations"] = currentItem["ObiGlobalFollowUpActions"];
                                    currentregisterobi["ComplianceSLDateDecision"] = DateTime.Now;
                                }
                            }
                            if (currentusername != "SharePoint App")
                                  currentregisterobi.Update();

                            //currentRelatedItem[BNPTools.GetValue("workflowobi")]
                            if (!string.IsNullOrEmpty(managercomment))
                                currentRelatedItem["ObiManagerComment"] = managercomment;
                            if (!string.IsNullOrEmpty(globalcomment))
                            {
                                currentRelatedItem["ObiGlobalComment"] = globalcomment;
                                currentRelatedItem["ObiGlobalFollowUpActions"] = globalobifollowupcomment;
                                currentRelatedItem["ObiGlobaldeadlineFollowUp"] = globalobiDeadlineFollowUp;
                                //Obi_x0020_Global_x0020_Follow_x0020
                            }
                            if (!string.IsNullOrEmpty(localcomment))
                            {
                                currentRelatedItem["ObiLocalComment"] = localcomment;
                                currentRelatedItem["ObiFollowUpActions"] = obifollowupcomment;
                                currentRelatedItem["ObiDeadlineFollowUp"] = obiDeadlineFollowUp;
                            }

                            currentRelatedItem.Update();
                            web.AllowUnsafeUpdates = false;
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in EH : OBI Task" + ex.Message);
                        }
                    }
                }
            });
        }

    }
}
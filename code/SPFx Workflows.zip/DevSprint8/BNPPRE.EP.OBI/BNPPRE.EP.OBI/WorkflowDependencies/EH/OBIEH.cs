﻿using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.OBI.WorkflowDependencies.EH
{
    public class OBIEH : SPItemEventReceiver
    {
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            Guid siteID = properties.SiteId;
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate () {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb ElevatedWeb = wSite.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentitem = properties.ListItem;

                            SPFieldUserValue userValue = new SPFieldUserValue(ElevatedWeb, currentitem[SPBuiltInFieldId.Author].ToString());
                            SPUser author = userValue.User;
                            SPList lstrefep = ElevatedWeb.Lists["LstRefEP"];
                            SPListItemCollectionPosition itemscollectionposition = null;
                            SPQuery query = new SPQuery();
                            query.ListItemCollectionPosition = itemscollectionposition;
                            query.Query = "<Where>" +
                                               "<Eq><FieldRef Name='MailUser' /><Value Type='Text'>" + author.Email + "</Value></Eq>" +
                                         "</Where>";
                            query.ViewXml = @"<View>
                                                   <ViewFields>
                                                        <FieldRef Name='RefFirstName'/> 
                                                        <FieldRef Name='RefLastName'/>
                                                        <FieldRef Name='RefContact'/> 
                                                        <FieldRef Name='MailUser'/> 
                                                        <FieldRef Name='RefManager'/> 
                                                        <FieldRef Name='isComex'/> 
                                                        <FieldRef Name='RefPays'/> 
                                                        <FieldRef Name='BusinessLine'/> 
                                                        <FieldRef Name='RefDepartment'/> 
                                                   </ViewFields>
                                                   <RowLimit>20000</RowLimit>
                                                 </View>";
                            SPListItemCollection items = lstrefep.GetItems(query);
                            itemscollectionposition = items.ListItemCollectionPosition;
                            query.ListItemCollectionPosition = items.ListItemCollectionPosition;

                            List<SPListItem> wlist = items.Cast<SPListItem>().Where(w => ((w["MailUser"] != null) && (w["MailUser"].ToString().ToLower().Equals(author.Email.ToLower())))).ToList();
                            SPListItem lstrefepAuthor = null;
                            if (wlist.Count > 0)
                            {
                                lstrefepAuthor = wlist[0]; 
                            }

                            string group = lstrefepAuthor["RefPays"].ToString().Split('#')[1];

                            //ElevatedWeb.AllowUnsafeUpdates = true;
                            //currentitem.BreakRoleInheritance(false);

                            //#region assign role contributor to current user  
                            //SPRoleAssignment roleAssignmentCurrentUser = new SPRoleAssignment((SPPrincipal)currentuser);
                            //SPRoleDefinition roleAdmin = ElevatedWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                            //roleAssignmentCurrentUser.RoleDefinitionBindings.Add(roleAdmin);
                            //currentitem.RoleAssignments.Add(roleAssignmentCurrentUser);
                            //#endregion

                            //if (!string.IsNullOrEmpty(group))
                            //{
                            //    BNPTools.AssignPermissionTogroup(ElevatedWeb, currentitem, group);
                            //}
                            //BNPTools.AssignPermissionTogroup(ElevatedWeb, currentitem, "Global Compliance");
                            SPGroup groupOwner = ElevatedWeb.SiteGroups.Cast<SPGroup>().Where(g => g.Name.Contains("Owners")).FirstOrDefault();
                            //if (groupOwner != null)
                            //    BNPTools.AssignPermissionTogroup(ElevatedWeb, currentitem, groupOwner.Name);

                            //currentitem.Update();
                            //ElevatedWeb.AllowUnsafeUpdates = false;
                            SPList splregisterobi = ElevatedWeb.Lists["RegisterOBIList"];
                            SPQuery queryregister = new SPQuery();
                            queryregister.Query = "<Where>" +
                                                        "<Eq><FieldRef Name='Title' /><Value Type='Text'>" + currentitem.Title + "</Value></Eq>" +
                                                  "</Where>";
                            SPListItem registerobiItem = splregisterobi.GetItems(queryregister).Cast<SPListItem>().FirstOrDefault();
                            if (registerobiItem == null)
                            {
                                SPListItem newitem = addregister(ElevatedWeb, currentitem, author, lstrefep, lstrefepAuthor);
                                newitem.BreakRoleInheritance(false);

                                if (!string.IsNullOrEmpty(group))
                                {
                                    BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, group);
                                }
                                BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, "Global Compliance");
                                if (groupOwner != null)
                                    BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, groupOwner.Name);
                            }
                            ElevatedWeb.AllowUnsafeUpdates = false;
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in ItemAdded OBIEH : " + ex.Message);
                        }
                    }
                }
            });
        }

        private static SPListItem addregister(SPWeb ElevatedWeb, SPListItem currentitem, SPUser author, SPList lstrefep, SPListItem lstrefepAuthor)
        {
            try
            {
                SPList registerobi = ElevatedWeb.Lists["RegisterOBIList"];
                SPUser currentuser = ElevatedWeb.CurrentUser;


                SPQuery queryManager = new SPQuery();
                queryManager.Query = "<Where>" +
                                   "<Eq><FieldRef Name='MailUser' /><Value Type='Text'>" + currentitem["ObiQManager"] + "</Value></Eq>" +
                                "</Where>";
                SPListItem lstrefepManager = lstrefep.GetItems(queryManager).Cast<SPListItem>().FirstOrDefault();
                //BNPTools.WriteInLogFile("L103 group : " + lstrefepAuthor["RefPays"].ToString());
                //string group = lstrefepAuthor["RefPays"].ToString().Split('#')[1];
                string group = currentitem["ObiQLocalCountry"] != null ? currentitem["ObiQLocalCountry"].ToString() : "";
                BNPTools.WriteInLogFile("L105 group : " + group);
                ElevatedWeb.AllowUnsafeUpdates = true;
                SPListItem newitem = registerobi.Items.Add();
                newitem["Title"] = currentitem.Title;
                newitem["BNPPDirectory"] = author.LoginName.Split('|')[1].Split('\\')[1];
                newitem["EmployeeFirstName"] = author.Name.Split(' ')[0];
                newitem["EmployeeLastName"] = author.Name.Split(' ')[1];
                try { newitem["EmployeeCountryCode"] = lstrefepAuthor["RefPays"].ToString().Split('#')[1].Replace("Compliance", ""); }
                catch { BNPTools.WriteInLogFile("Exception in refpays of author"); }

                try { newitem["EmployeeBusinessLine"] = lstrefepAuthor["BusinessLine"]; }
                catch { BNPTools.WriteInLogFile("Exception in business line of author"); }

                try { newitem["EmployeeJobDescription"] = lstrefepAuthor["RefDepartment"]; }
                catch { BNPTools.WriteInLogFile("Exception in ref department of author"); } 

                //company
                if (currentitem["ObiQ2_2"] != null)
                    newitem["CompanyName"] = currentitem["ObiQ2_2"];
                if (currentitem["ObiQ2_3"] != null)
                    newitem["CompanyName"] = currentitem["ObiQ2_3"];

                newitem["CompanyRegistrationNumber"] = "";
                newitem["CompanyClientRMPM"] = "";
                newitem["CompanyISINCode"] = currentitem["ObiQ3_1"];
                newitem["CompanyCountryISOCode"] = "";
                try
                {
                    if (currentitem["ObiQ2_4"] != null)
                    {
                        if (currentitem["ObiQ2_4"].ToString() == "True")
                            newitem["ListedCompany"] = "Yes";
                        else
                            newitem["ListedCompany"] = "No";
                    }
                }
                catch { BNPTools.WriteInLogFile("Exception in ListedCompany"); }
                newitem["CompanyTypeClient"] = "";
                newitem["CompanyActivity"] = currentitem["ObiQ7"];
                //Business Interest 
                newitem["OBITypeList"] = "";
                newitem["OBISubTypeList"] = "";
                newitem["DescriptionActivity"] = currentitem["ObiQ3"];
                newitem["StartingDate"] = currentitem["ObiQ5"];
                newitem["EmployeeEndDate"] = currentitem["ObiQ5_1"];
                newitem["TimeSpent"] = currentitem["ObiQ10"];
                newitem["InvestmentMade"] = "";
                newitem["Revenue"] = currentitem["ObiQ9_1"];
                if (lstrefepManager != null)
                {
                    //Manager
                    SPFieldUserValue managerValue = new SPFieldUserValue(ElevatedWeb, lstrefepManager["RefContact"].ToString());
                    SPUser Manager = managerValue.User;
                    BNPTools.WriteInLogFile("begin Inside manager  ");
                    newitem["ManagerUserID"] = Manager.LoginName.Split('|')[1].Split('\\')[1];
                    newitem["ManagerName"] = lstrefepManager["RefFirstName"] + " " + lstrefepManager["RefLastName"];
                    newitem["ManagerPosition"] = lstrefepManager["RefDepartment"];
                    BNPTools.WriteInLogFile("end Inside manager  ");
                }

                newitem.Update();
                BNPTools.WriteInLogFile("Item Added");
                newitem.BreakRoleInheritance(false);


                if (!string.IsNullOrEmpty(group))
                {
                    BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, group);
                }
                BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, "Global Compliance");
                SPGroup groupOwner = ElevatedWeb.SiteGroups.Cast<SPGroup>().Where(g => g.Name.Contains("Owners")).FirstOrDefault();
                if (groupOwner != null)
                    BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, groupOwner.Name);
                BNPTools.WriteInLogFile("Item Permission assigned");
                ElevatedWeb.AllowUnsafeUpdates = false;
                return newitem;
            }
            catch (Exception ex)
            {
                BNPTools.WriteInLogFile("exception in OBI EH addregister : " + ex.Message);
                return null; 
            }
        }

        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            SPUser currentuser = properties.Web.CurrentUser;


            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPWeb ElevatedWeb = properties.OpenWeb())
                {
                    try
                    {
                        SPListItem currentItem = properties.ListItem;

                        SPList splregisterobi = ElevatedWeb.Lists["RegisterOBIList"];
                        SPQuery queryregister = new SPQuery();
                        queryregister.Query = "<Where>" +
                                                    "<Eq><FieldRef Name='Title' /><Value Type='Text'>" + currentItem.Title + "</Value></Eq>" +
                                              "</Where>";
                        SPListItem registerobiItem = splregisterobi.GetItems(queryregister).Cast<SPListItem>().FirstOrDefault();
                        SPFieldUserValue userValue = new SPFieldUserValue(ElevatedWeb, currentItem[SPBuiltInFieldId.Author].ToString());
                        SPUser author = userValue.User;

                        SPList lstrefep = ElevatedWeb.Lists["LstRefEP"];
                        SPQuery query = new SPQuery();
                        query.Query = "<Where>" +
                                           "<Eq><FieldRef Name='MailUser' /><Value Type='Text'>" + author.Email + "</Value></Eq>" +
                                     "</Where>";
                        SPListItem lstrefepAuthor = lstrefep.GetItems(query).Cast<SPListItem>().FirstOrDefault();
                        if (registerobiItem == null)
                        {
                            addregister(ElevatedWeb, currentItem, author, lstrefep, lstrefepAuthor); 
                        }
                        if (currentItem["Actif"] != null)
                        {
                            string isActif = currentItem["Actif"].ToString();
                            if (isActif == "False")
                            {
                                //Dashboard
                                SPList lstDashboard = ElevatedWeb.Lists["Dashboard"];
                                SPQuery querydashboard = new SPQuery();
                                querydashboard.Query = "<Where><And>" +
                                               "<Eq><FieldRef Name='Title' /><Value Type='Text'>" + currentItem.ID + "</Value></Eq>" +
                                               "<Eq><FieldRef Name='DeclarationType' /><Value Type='Text'>OBI</Value></Eq>" +
                                             "</And></Where>";
                               SPListItemCollection itemsDashboard = lstDashboard.GetItems(querydashboard);
                                if (itemsDashboard.Count == 1)
                                {
                                    SPListItem itemDashbaord = itemsDashboard[0];
                                    ElevatedWeb.AllowUnsafeUpdates = true;
                                    itemDashbaord["Actif"] = false;
                                    itemDashbaord.Update();
                                    ElevatedWeb.AllowUnsafeUpdates = false;
                                }
                                //Delete register obi related to the current item 
                               
                                ElevatedWeb.AllowUnsafeUpdates = true; 
                                registerobiItem.Delete();
                                BNPTools.WriteInLogFile("register obi item deleted"); 
                                ElevatedWeb.AllowUnsafeUpdates = false;
                            }
                        }


                        
                        string group = currentItem["ObiQLocalCountry"] != null ? currentItem["ObiQLocalCountry"].ToString() : "";
                        BNPTools.WriteInLogFile("end if , group : "+ group);  
                        ElevatedWeb.AllowUnsafeUpdates = true;
                        currentItem.BreakRoleInheritance(false);

                        #region assign role contributor to current user  
                        SPRoleAssignment roleAssignmentCurrentUser = new SPRoleAssignment((SPPrincipal)currentuser);
                        SPRoleDefinition roleAdmin = ElevatedWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                        roleAssignmentCurrentUser.RoleDefinitionBindings.Add(roleAdmin);
                        currentItem.RoleAssignments.Add(roleAssignmentCurrentUser);
                        #endregion

                        if (!string.IsNullOrEmpty(group))
                        {
                            BNPTools.AssignPermissionTogroup(ElevatedWeb, currentItem, group);
                        }
                        BNPTools.AssignPermissionTogroup(ElevatedWeb, currentItem, "Global Compliance");
                        SPGroup groupOwner = ElevatedWeb.SiteGroups.Cast<SPGroup>().Where(g => g.Name.Contains("Owners")).FirstOrDefault();
                        if (groupOwner != null)
                            BNPTools.AssignPermissionTogroup(ElevatedWeb, currentItem, groupOwner.Name);

                        currentItem.Update();
                        ElevatedWeb.AllowUnsafeUpdates = false;

                    }
                    catch (Exception ex)
                    {
                        BNPTools.WriteInLogFile("Exception in EH : OBI List " + ex.Message);
                    }
                }
            });
        }



    }
}

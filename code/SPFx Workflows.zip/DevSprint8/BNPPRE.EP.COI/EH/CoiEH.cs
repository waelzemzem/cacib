﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace BNPPRE.EP.COI.EH
{
    public class CoiEH : SPItemEventReceiver
    {
        const string _lstCible = "WorkflowCOITaskList";

        const string _ManagerTask = "Task COI manager";
        const string _LocalTask = "Task COI local compliance";
        const string _GlobalTask = "Task COI global compliance";
        const string _ApprovementTask = "Task COI Approvements";


        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {



                using (SPWeb web = properties.OpenWeb())
                {
                    try
                    {
                        SPListItem currentItem = properties.ListItem;

                        if (currentItem.ParentList.Title == _lstCible)
                        {

                            string _title = currentItem.Title;

                            //manager outcome
                            string ManagerComment = string.Empty;

                            // local outcome (first phase)
                            string LocalComment = string.Empty, AdditionalProtectionMeasures = string.Empty, FollowUpMeasures = string.Empty, DeadlineFollowUp = string.Empty;


                            // global outcome( second phase)
                            string CoiGlobalAdditionalProtection = string.Empty, CoiGlobalDeadline = string.Empty, GlobalComment = string.Empty, CoiGlobalFollowUp = string.Empty;






                            switch (_title)
                            {

                                case _ManagerTask:

                                    ManagerComment = currentItem["ManagerComment"] != null ? currentItem["ManagerComment"].ToString() : "";
                                    break;

                                case _LocalTask:

                                    LocalComment = currentItem["LocalComment"] != null ? currentItem["LocalComment"].ToString() : "";
                                    AdditionalProtectionMeasures = currentItem["AdditionalProtectionMeasures"] != null ? currentItem["AdditionalProtectionMeasures"].ToString() : "";
                                    FollowUpMeasures = currentItem["FollowUpMeasures"] != null ? currentItem["FollowUpMeasures"].ToString() : "";
                                    DeadlineFollowUp = currentItem["DeadlineFollowUp"] != null ? currentItem["DeadlineFollowUp"].ToString() : "";
                                    break;


                                case _GlobalTask:

                                    CoiGlobalAdditionalProtection = currentItem["CoiGlobalAdditionalProtection"] != null ? currentItem["CoiGlobalAdditionalProtection"].ToString() : "";
                                    CoiGlobalDeadline = currentItem["CoiGlobalDeadline"] != null ? currentItem["CoiGlobalDeadline"].ToString() : "";
                                    GlobalComment = currentItem["GlobalComment"] != null ? currentItem["GlobalComment"].ToString() : "";
                                    CoiGlobalFollowUp = currentItem["CoiGlobalFollowUp"] != null ? currentItem["CoiGlobalFollowUp"].ToString() : "";
                                    break;



                                default:
                                    break;
                            }


                            // get id from related item
                            string _strRelatedItem = currentItem[SPBuiltInFieldId.RelatedItems].ToString();
                            string[] strRelatedItems = currentItem[SPBuiltInFieldId.RelatedItems].ToString().Split(',');
                            string strCurrentItemID = strRelatedItems[0].Split(':')[1];
                            //List<RelatedItemFieldVal> relatedItems = GetItems(_strRelatedItem);
                            //RelatedItemFieldVal r = relatedItems[0];
                            int? _iditem = int.Parse(strCurrentItemID);

                            if (_iditem != null)
                            {
                                // get related item
                                SPList lst = web.Lists["ListCOI"];
                                SPListItem curRelatedItem = lst.GetItemById(_iditem.Value);

                                // modify related item
                                web.AllowUnsafeUpdates = true;
                                this.EventFiringEnabled = false;
                                curRelatedItem["ManagerComment"] = ManagerComment;
                                curRelatedItem["LocalComment"] = LocalComment;
                                curRelatedItem["AdditionalProtectionMeasures"] = AdditionalProtectionMeasures;
                                curRelatedItem["FollowUpMeasures"] = FollowUpMeasures;
                                curRelatedItem["DeadlineFollowUp"] = DeadlineFollowUp;
                                curRelatedItem["CoiGlobalAdditionalProtection"] = CoiGlobalAdditionalProtection;
                                curRelatedItem["CoiGlobalDeadline"] = CoiGlobalDeadline;
                                curRelatedItem["GlobalComment"] = GlobalComment;
                                curRelatedItem["CoiGlobalFollowUp"] = CoiGlobalFollowUp;

                                curRelatedItem.Update();
                                this.EventFiringEnabled = true;
                                web.AllowUnsafeUpdates = false;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            });
        }


        //public List<RelatedItemFieldVal> GetItems(string jsonString)
        //{
        //    JavaScriptSerializer deserializer = new JavaScriptSerializer();
        //    object deserializeOutput = deserializer.Deserialize<List<RelatedItemFieldVal>>(jsonString);
        //    List<RelatedItemFieldVal> l = ((List<RelatedItemFieldVal>)deserializeOutput);
        //    return l;
        //    //    List<RelatedItemFieldValue> l = new List<RelatedItemFieldValue>();
        //    //   return l; 

        //}




        //public string GetItems(List<RelatedItemFieldVal> relatedItems)
        //{
        //    string jsonString = string.Empty;
        //    JavaScriptSerializer serializer = new JavaScriptSerializer();
        //    jsonString = serializer.Serialize(relatedItems);
        //    return jsonString;
        //}


    }
}
using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace BNPPRE.EP.COI.Features.Feature1
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("7ca4635b-03a9-4e29-8104-0e03d438ea9e")]
    public class Feature1EventReceiver : SPFeatureReceiver
    {
        const string lst_title = "WorkflowCOITaskList";
        const string _class = "BNPPRE.EP.COI.WorkflowDependencies.EH.COI_TaskEH";
        const string _className = "COI_TaskEH";


        const string lst_title_COI = "ListCOI";
        const string _class_COI = "BNPPRE.EP.COI.WorkflowDependencies.EH.COI_EH";
        const string _className_COI = "COI_EH";

        const SPEventReceiverType eventTypeAdded = SPEventReceiverType.ItemAdded;
        const SPEventReceiverType eventTypeUpdated = SPEventReceiverType.ItemUpdated;

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {

            BNPTools.WriteInLogFile("In FeatureActivated COI EH Custom");

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                SPListCollection lstCollection = rootweb.Lists;


                SPList ListC = null, ListD = null;

                try
                {
                    ListC = lstCollection.TryGetList(lst_title);
                    ListD = lstCollection.TryGetList(lst_title_COI);
                }
                catch (Exception ex)
                {
                    BNPTools.WriteInLogFile("Exception in FeatureActivated COI EH Custom : " + ex.Message);
                }
                if (null != ListC)
                {

                    SPEventReceiverDefinition def = ListC.EventReceivers.Add();
                    def.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    def.Class = _class;
                    def.Name = _className;
                    def.Type = SPEventReceiverType.ItemUpdated;
                    def.SequenceNumber = 1000;
                    def.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    def.Update();
                    BNPTools.WriteInLogFile("Event Handler item updated added for list WorkflowCOITaskList");
                }

                if (null != ListD)
                {
                    SPEventReceiverDefinition def_added = ListD.EventReceivers.Add();
                    def_added.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    def_added.Class = _class_COI;
                    def_added.Name = _className_COI;
                    def_added.Type = SPEventReceiverType.ItemAdded;
                    def_added.SequenceNumber = 1000;
                    def_added.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    def_added.Update();
                    BNPTools.WriteInLogFile("Event Handler itemAdded added for list ListCOI");

                    SPEventReceiverDefinition def_updated = ListD.EventReceivers.Add();
                    def_updated.Assembly = System.Reflection.Assembly.GetExecutingAssembly().FullName;
                    def_updated.Class = _class_COI;
                    def_updated.Name = _className_COI;
                    def_updated.Type = SPEventReceiverType.ItemUpdated;
                    def_updated.SequenceNumber = 1000;
                    def_updated.Synchronization = SPEventReceiverSynchronization.Asynchronous;
                    def_updated.Update();
                    BNPTools.WriteInLogFile("Event Handler itemUpdated added for list ListCOI");

                }

            });
            BNPTools.WriteInLogFile("Out FeatureActivated COI EH Custom");

        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            BNPTools.WriteInLogFile("In FeatureDeactivating COIEH -- Custom");

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                SPWeb rootweb = (SPWeb)properties.Feature.Parent;
                SPListCollection lstCollection = rootweb.Lists;


                SPList ListC = null, ListD = null;


                try
                {
                    ListC = lstCollection.TryGetList(lst_title);
                    ListD = lstCollection.TryGetList(lst_title_COI);
                }
                catch (Exception)
                { }
                if (null != ListC)
                {

                    DeleteEvents(ListC);
                    DeleteEvents(ListD);

                }

            });


            BNPTools.WriteInLogFile("Out FeatureDeactivating COIEH -- Custom");
        }


        private static void DeleteEvents(SPList list)
        {
            SPEventReceiverDefinitionCollection erdc = list.EventReceivers;
            List<SPEventReceiverDefinition> eventsToDelete = new List<SPEventReceiverDefinition>();

            foreach (SPEventReceiverDefinition erd in erdc)
            {
                if (erd != null)
                {
                    try
                    {
                        eventsToDelete.Add(erd);
                    }
                    catch (Exception) { }
                }
            }
            foreach (SPEventReceiverDefinition er in eventsToDelete)
            {
                if (er.Type == eventTypeAdded)
                {
                    er.Delete();
                }
                if (er.Type == eventTypeUpdated)
                {
                    er.Delete();
                }
            }
        }

        // Uncomment the method below to handle the event raised after a feature has been installed.



        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

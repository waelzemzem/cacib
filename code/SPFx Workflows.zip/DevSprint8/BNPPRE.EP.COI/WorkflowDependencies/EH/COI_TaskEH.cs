﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Web.Script.Serialization;

namespace BNPPRE.EP.COI.WorkflowDependencies.EH
{
    public class COI_TaskEH : SPItemEventReceiver
    { 

        #region constantes
        const string _lstCible = "WorkflowCOITaskList";
        const string _ManagerTask = "Task COI manager";
        const string _LocalTask = "COMPOSITE TASK FOR LOCAL COMPLIANCE";
        const string _GlobalTask = "Task COI global compliance";
        const string _ApprovementTask = "Task COI Approvements";
        #endregion

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            string currentusername = properties.Web.CurrentUser.Name;

            if (currentusername != "SharePoint App")
            {
                string currentuserloginname = properties.Web.CurrentUser.LoginName.Split('|')[1];

                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    using (SPWeb web = properties.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentItem = properties.ListItem;

                            if (currentItem.ParentList.Title == _lstCible)
                            {

                                string _title = currentItem.Title;

                                //manager outcome
                                string ManagerComment = string.Empty;

                                // local outcome (first phase)
                                string LocalComment = string.Empty, AdditionalProtectionMeasures = string.Empty, FollowUpMeasures = string.Empty, DeadlineFollowUp = string.Empty;


                                // global outcome( second phase)
                                string CoiGlobalAdditionalProtection = string.Empty, CoiGlobalDeadline = string.Empty, GlobalComment = string.Empty, CoiGlobalFollowUp = string.Empty;


                                // get id from related item
                                string _strRelatedItem = currentItem[SPBuiltInFieldId.RelatedItems].ToString();
                                List<RelatedItemFieldVal> relatedItems = GetItems(_strRelatedItem);
                                RelatedItemFieldVal r = relatedItems[0];
                                int? _iditem = r.ItemId;

                                if (_iditem != null)
                                {
                                    // get related item
                                    SPList lst = web.Lists["ListCOI"];
                                    SPListItem curRelatedItem = lst.GetItemById(_iditem.Value);

                                    SPList registercoi = web.Lists["RegisterCOI"];
                                    SPQuery queryregister = new SPQuery();
                                    queryregister.Query = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + curRelatedItem.Title + "</Value></Eq></Where>";
                                    SPListItem currentregistercoi = registercoi.GetItems(queryregister).Cast<SPListItem>().FirstOrDefault();

                                    // modify related item
                                    web.AllowUnsafeUpdates = true;

                                    switch (_title)
                                    {

                                        case _ManagerTask:

                                            ManagerComment = currentItem["ManagerComment"] != null ? currentItem["ManagerComment"].ToString() : "";
                                            curRelatedItem["ManagerComment"] = ManagerComment;
                                            BNPTools.WriteInLogFile("before update register coi");
                                            if (currentusername != "SharePoint App")
                                            {
                                                currentregistercoi["COIDecision"] = currentItem["CoiOutcomeManager"];//Approved, Rejected, Accepted with reservations
                                                currentregistercoi["COIDecisionRationale"] = currentItem["ManagerComment"];
                                                currentregistercoi["COIManagerDateDecision"] = DateTime.Now;
                                            }
                                            BNPTools.WriteInLogFile("after update register coi");
                                            break;

                                        case _LocalTask:

                                            LocalComment = currentItem["LocalComment"] != null ? currentItem["LocalComment"].ToString() : "";
                                            AdditionalProtectionMeasures = currentItem["AdditionalProtectionMeasures"] != null ? currentItem["AdditionalProtectionMeasures"].ToString() : "";
                                            FollowUpMeasures = currentItem["FollowUpMeasures"] != null ? currentItem["FollowUpMeasures"].ToString() : "";
                                            DeadlineFollowUp = currentItem["DeadlineFollowUp"] != null ? currentItem["DeadlineFollowUp"].ToString() : "";

                                            curRelatedItem["LocalComment"] = LocalComment;
                                            curRelatedItem["AdditionalProtectionMeasures"] = AdditionalProtectionMeasures;
                                            curRelatedItem["FollowUpMeasures"] = FollowUpMeasures;
                                            if (!string.IsNullOrEmpty(DeadlineFollowUp))
                                                curRelatedItem["DeadlineFollowUp"] = DateTime.Parse(DeadlineFollowUp, null, System.Globalization.DateTimeStyles.RoundtripKind);

                                            if (currentusername != "SharePoint App")
                                            {
                                                currentregistercoi["COIComplianceUID"] = currentuserloginname;
                                                currentregistercoi["COIComplianceName"] = currentusername;

                                                currentregistercoi["COIComplianceDecision"] = currentItem["CoiOutcomeFirstPhase"];//Approved, Rejected, Accepted with reservations
                                                currentregistercoi["COIComplianceDecisionRationale"] = currentItem["LocalComment"];
                                                //currentregistercoi["ComplianceMitigations"] = currentItem["ObiFollowUpActions"];
                                                currentregistercoi["COIComplianceDateDecision"] = DateTime.Now;
                                                currentregistercoi["COIComplianceFollowUpMeasures"] = FollowUpMeasures;
                                                currentregistercoi["COIComplianceAdditionalProtectionMeasures"] = AdditionalProtectionMeasures;
                                                if (!string.IsNullOrEmpty(DeadlineFollowUp))
                                                    currentregistercoi["COIComplianceDeadlineFollowUp"] = DateTime.Parse(DeadlineFollowUp, null, System.Globalization.DateTimeStyles.RoundtripKind);
                                            }
                                            break;


                                        case _GlobalTask:

                                            //CoiGlobalAdditionalProtection = currentItem["CoiGlobalAdditionalProtection"] != null ? currentItem["CoiGlobalAdditionalProtection"].ToString() : "";
                                            //CoiGlobalDeadline = currentItem["CoiGlobalDeadline"] != null ? currentItem["CoiGlobalDeadline"].ToString() : "";
                                            GlobalComment = currentItem["GlobalComment"] != null ? currentItem["GlobalComment"].ToString() : "";
                                            //CoiGlobalFollowUp = currentItem["CoiGlobalFollowUp"] != null ? currentItem["CoiGlobalFollowUp"].ToString() : "";

                                            //curRelatedItem["CoiGlobalAdditionalProtection"] = CoiGlobalAdditionalProtection;                                
                                            //curRelatedItem["CoiGlobalDeadline"] = CoiGlobalDeadline;
                                            curRelatedItem["GlobalComment"] = GlobalComment;
                                            //curRelatedItem["CoiGlobalFollowUp"] = CoiGlobalFollowUp;

                                            if (currentusername != "SharePoint App")
                                            {
                                                currentregistercoi["COIGlobalCPLUID"] = currentuserloginname;
                                                currentregistercoi["COIGlobalCPLName"] = currentusername;

                                                currentregistercoi["COIGlobalCPLDecision"] = currentItem["CoiOutcomeSecondPhase"];
                                                currentregistercoi["COIGlobalCPLDecisionRationale"] = currentItem["GlobalComment"];
                                                currentregistercoi["COIGlobalCPLDateDecision"] = DateTime.Now;
                                            }
                                            break;



                                        default:
                                            break;
                                    }
                                    if (currentusername != "SharePoint App")
                                    {
                                        //this.EventFiringEnabled = false;
                                        currentregistercoi.Update();
                                        BNPTools.WriteInLogFile("Line 153 : update register coi item ");
                                        //this.EventFiringEnabled = true;
                                    }
                                    curRelatedItem.Update();
                                    BNPTools.WriteInLogFile("Update related item from coi Task EH");
                                    web.AllowUnsafeUpdates = false;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Error in EH COI : " + ex.Message);
                        }
                    }
                });
            }
            else
            {
                BNPTools.WriteInLogFile("SharePoint User App is useed"); 
            }
        }
        public List<RelatedItemFieldVal> GetItems(string jsonString)
        {
            JavaScriptSerializer deserializer = new JavaScriptSerializer();
            object deserializeOutput = deserializer.Deserialize<List<RelatedItemFieldVal>>(jsonString);
            List<RelatedItemFieldVal> l = ((List<RelatedItemFieldVal>)deserializeOutput);
            return l;
            //    List<RelatedItemFieldValue> l = new List<RelatedItemFieldValue>();
            //   return l; 

        }

        public string GetItems(List<RelatedItemFieldVal> relatedItems)
        {
            string jsonString = string.Empty;
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            jsonString = serializer.Serialize(relatedItems);
            return jsonString;
        }

    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BNPPRE.EP.COI.WorkflowDependencies.EH
{
    public class RelatedItemFieldVal
    {
        public int ItemId { get; set; }
        public Guid WebId { get; set; }
        public Guid ListId { get; set; }

    }
}
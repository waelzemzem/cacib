﻿using Microsoft.SharePoint;
using NewEthiquePortal.UI.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BNPPRE.EP.COI.WorkflowDependencies.EH
{
    public class COI_EH : SPItemEventReceiver
    {
        /// <summary>
        /// Item Added of Coi list 
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            Guid siteID = properties.SiteId;
            SPUser currentuser = properties.Web.CurrentUser;
            BNPTools.WriteInLogFile("Begin Item Added of listcoi --- test"); 
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb ElevatedWeb = wSite.OpenWeb())
                    {
                        BNPTools.WriteInLogFile("L32 Item Added of listcoi");

                        SPListItem currentitem = properties.ListItem;
                                              
                        addregistercoi(ElevatedWeb, currentitem);

                     
                        //BNPTools.ApplyPermissions(currentuser, ElevatedWeb, currentitem, "ListCOI", "CoiQLocalCountry");
                        BNPTools.WriteInLogFile("End item Added COI EH");
                        //this.EventFiringEnabled = true; 

                    }
                }
            });
            }
            catch (Exception ex)
            {
                BNPTools.WriteInLogFile("Exception in COI EH item added : " + ex.Message);
            }
        }

        /// <summary>
        /// Add coi to register
        /// </summary>
        /// <param name="ElevatedWeb"></param>
        /// <param name="currentitem"></param>
        private static void addregistercoi(SPWeb ElevatedWeb, SPListItem currentitem)
        {
            SPFieldUserValue userValue = new SPFieldUserValue(ElevatedWeb, currentitem[SPBuiltInFieldId.Author].ToString());
            SPUser author = userValue.User;
            SPList lstrefep = ElevatedWeb.Lists["LstRefEP"];
            SPListItemCollectionPosition itemscollectionposition = null;
            SPQuery query = new SPQuery();
            query.ListItemCollectionPosition = itemscollectionposition;
            query.Query = "<Where>" +
                               "<Eq><FieldRef Name='MailUser' /><Value Type='Text'>" + author.Email + "</Value></Eq>" +
                         "</Where>";
            query.ViewXml = @"<View>
                                                   <ViewFields>
                                                        <FieldRef Name='RefFirstName'/> 
                                                        <FieldRef Name='RefLastName'/>
                                                        <FieldRef Name='RefContact'/> 
                                                        <FieldRef Name='MailUser'/> 
                                                        <FieldRef Name='RefManager'/> 
                                                        <FieldRef Name='isComex'/> 
                                                        <FieldRef Name='RefPays'/> 
                                                        <FieldRef Name='BusinessLine'/> 
                                                        <FieldRef Name='RefDepartment'/> 
                                                   </ViewFields>
                                                   <RowLimit>20000</RowLimit>
                                                 </View>";
            SPListItemCollection items = lstrefep.GetItems(query);
            itemscollectionposition = items.ListItemCollectionPosition;
            query.ListItemCollectionPosition = items.ListItemCollectionPosition;

            List<SPListItem> wlist = items.Cast<SPListItem>().Where(w => ((w["MailUser"] != null) && (w["MailUser"].ToString().ToLower().Equals(author.Email.ToLower())))).ToList();
            SPListItem lstrefepAuthor = null;
            if (wlist.Count > 0)
            {
                lstrefepAuthor = wlist[0];
            }
            string group = lstrefepAuthor["RefPays"].ToString().Split('#')[1];
            BNPTools.WriteInLogFile("L70 Item updated of listcoi  " +group );
            SPList registerCOI = ElevatedWeb.Lists["RegisterCOI"];
            BNPTools.WriteInLogFile("L45 Item Added of listcoi");

            SPQuery queryManager = new SPQuery();
            queryManager.Query = "<Where>" +
                               "<Eq><FieldRef Name='MailUser' /><Value Type='Text'>" + currentitem["CoiQManager"] + "</Value></Eq>" +
                            "</Where>";
            SPListItem lstrefepManager = lstrefep.GetItems(queryManager).Cast<SPListItem>().FirstOrDefault();
            BNPTools.WriteInLogFile("L50 Item Added of listcoi");
            ElevatedWeb.AllowUnsafeUpdates = true;
            SPListItem newitem = registerCOI.Items.Add();
            newitem["Title"] = currentitem.Title;
            newitem["SubmissionDate"] = DateTime.Now;
            newitem["DeclarationDate"] = DateTime.Now;
            newitem["EmployeeUID"] = author.LoginName.Split('|')[1];
            newitem["EmployeeIdentity"] = author.Name;

            newitem["DateofDetection"] = currentitem["CoiQ2"];
            BNPTools.WriteInLogFile("L60 Item Added of listcoi");
            newitem["COIBusinessLine"] = lstrefepAuthor["BusinessLine"];
            newitem["COIEntity"] = lstrefepAuthor["RefDepartment"];
            newitem["TypeofConflict"] = currentitem["CoiQ1"];
            newitem["COIDescription"] = currentitem["CoiQDescription"];
            newitem["PartiesInvolved"] = currentitem["CoiQ7"];
            newitem["COIReference"] = currentitem["CoiQ4"];
            if (currentitem["CoiQ6"] != null && currentitem["CoiQ6"].ToString() != string.Empty)
                newitem["ComplementaryMitigating"] = currentitem["CoiQ6"];
            else
                newitem["ComplementaryMitigating"] = currentitem["CoiQ9"];


            //Manager
            SPFieldUserValue managerValue = new SPFieldUserValue(ElevatedWeb, lstrefepManager["RefContact"].ToString());
            SPUser Manager = managerValue.User;
            newitem["COIManagerUID"] = Manager.LoginName.Split('|')[1];
            newitem["COIManagerName"] = lstrefepManager["RefFirstName"] + " " + lstrefepManager["RefLastName"];

            //this.EventFiringEnabled = false; 
            newitem.Update();
            BNPTools.WriteInLogFile("Item Added");
            newitem.BreakRoleInheritance(false);


            if (!string.IsNullOrEmpty(group))
            {
                BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, group);
            }
            BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, "Global Compliance");
            SPGroup groupOwner = ElevatedWeb.SiteGroups.Cast<SPGroup>().Where(g => g.Name.Contains("Owners")).FirstOrDefault();
            if (groupOwner != null)
                BNPTools.AssignPermissionTogroup(ElevatedWeb, newitem, groupOwner.Name);
            BNPTools.WriteInLogFile("Item Permission assigned");
            ElevatedWeb.AllowUnsafeUpdates = false;
        }


        /// <summary>
        /// Item Updated of Coi list
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            Guid siteID = properties.SiteId;
            SPUser currentuser = properties.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                using (SPSite wSite = new SPSite(siteID))
                {
                    using (SPWeb ElevatedWeb = wSite.OpenWeb())
                    {
                        try
                        {
                            SPListItem currentitem = properties.ListItem;

                            //BNPTools.ApplyPermissions(currentuser, ElevatedWeb, currentitem, "ListCOI", "CoiQLocalCountry");
                            SPList splregisterCOI = ElevatedWeb.Lists["RegisterCOI"]; 
                            SPQuery query = new SPQuery();
                            query.Query = "<Where>" +
                                                    "<Eq><FieldRef Name='Title' /><Value Type='Text'>" + currentitem.Title + "</Value></Eq>" +
                                              "</Where>";
                            SPListItem registercoiItem = splregisterCOI.GetItems(query).Cast<SPListItem>().FirstOrDefault();
                            if (registercoiItem == null)
                            {
                                BNPTools.WriteInLogFile("Inside coi eh item updated -- before addregistercoi");
                                addregistercoi(ElevatedWeb, currentitem);
                            }

                        }
                        catch (Exception ex)
                        {
                            BNPTools.WriteInLogFile("Exception in COI EH item updated : " + ex.Message);
                        }
                    }
                }
            });

        }

    }
}

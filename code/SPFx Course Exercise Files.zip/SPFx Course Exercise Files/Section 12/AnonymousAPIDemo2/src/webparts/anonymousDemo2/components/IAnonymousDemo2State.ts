export interface IAnonymousDemo2State{

    id:string;
    name:string;
    username:string;
    email:string;
    address:string;
    phone:string;
    website: string;
    company: string;



}

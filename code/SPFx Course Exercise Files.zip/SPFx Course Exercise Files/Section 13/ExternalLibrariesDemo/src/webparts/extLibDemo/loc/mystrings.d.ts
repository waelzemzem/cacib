declare interface IExtLibDemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ExtLibDemoWebPartStrings' {
  const strings: IExtLibDemoWebPartStrings;
  export = strings;
}

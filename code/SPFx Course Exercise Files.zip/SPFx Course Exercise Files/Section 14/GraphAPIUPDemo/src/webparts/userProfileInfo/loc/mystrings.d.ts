declare interface IUserProfileInfoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'UserProfileInfoWebPartStrings' {
  const strings: IUserProfileInfoWebPartStrings;
  export = strings;
}

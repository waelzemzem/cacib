/* tslint:disable */
require("./CalendarEventsDemo.module.css");
const styles = {
  calendarEventsDemo: 'calendarEventsDemo_65d12b10',
  container: 'container_65d12b10',
  row: 'row_65d12b10',
  column: 'column_65d12b10',
  'ms-Grid': 'ms-Grid_65d12b10',
  title: 'title_65d12b10',
  subTitle: 'subTitle_65d12b10',
  description: 'description_65d12b10',
  button: 'button_65d12b10',
  label: 'label_65d12b10'
};

export default styles;
/* tslint:enable */
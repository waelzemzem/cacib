


import * as MicrosoftGraph from '@microsoft/microsoft-graph-types';

export interface ICalendarEventsDemoState{
  events: MicrosoftGraph.Event[];
}
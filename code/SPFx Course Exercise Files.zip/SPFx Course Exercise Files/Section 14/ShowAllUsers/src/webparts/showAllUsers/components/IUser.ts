
export interface IUser {
    displayName: string;
    givenName: string;
    surname: string;
    mail: string;
    mobilePhone: string;
    userPrincipalName: string;
}
define([], function() {
  return {
    "Title": "MyFieldCustomizerExtensionFieldCustomizer"
  }
});
declare interface IMyFieldCustomizerExtensionFieldCustomizerStrings {
  Title: string;
}

declare module 'MyFieldCustomizerExtensionFieldCustomizerStrings' {
  const strings: IMyFieldCustomizerExtensionFieldCustomizerStrings;
  export = strings;
}

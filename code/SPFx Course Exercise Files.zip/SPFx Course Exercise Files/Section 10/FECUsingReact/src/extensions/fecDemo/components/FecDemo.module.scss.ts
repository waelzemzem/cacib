/* tslint:disable */
require("./FecDemo.module.css");
const styles = {
  FecDemo: 'FecDemo_db2e0e79',
  cell: 'cell_db2e0e79'
};

export default styles;
/* tslint:enable */
declare interface IFecDemoFieldCustomizerStrings {
  Title: string;
}

declare module 'FecDemoFieldCustomizerStrings' {
  const strings: IFecDemoFieldCustomizerStrings;
  export = strings;
}

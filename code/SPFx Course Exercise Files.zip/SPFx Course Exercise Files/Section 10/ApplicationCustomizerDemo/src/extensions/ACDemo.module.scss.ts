/* tslint:disable */
require("./ACDemo.module.css");
const styles = {
  acdemoapp: 'acdemoapp_abee9aca',
  topPlaceholder: 'topPlaceholder_abee9aca',
  bottomPlaceholder: 'bottomPlaceholder_abee9aca'
};

export default styles;
/* tslint:enable */
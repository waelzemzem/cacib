/* tslint:disable */
require("./RShowListItems.module.css");
const styles = {
  rShowListItems: 'rShowListItems_9a27fce9',
  container: 'container_9a27fce9',
  row: 'row_9a27fce9',
  column: 'column_9a27fce9',
  'ms-Grid': 'ms-Grid_9a27fce9',
  title: 'title_9a27fce9',
  subTitle: 'subTitle_9a27fce9',
  description: 'description_9a27fce9',
  button: 'button_9a27fce9',
  label: 'label_9a27fce9'
};

export default styles;
/* tslint:enable */
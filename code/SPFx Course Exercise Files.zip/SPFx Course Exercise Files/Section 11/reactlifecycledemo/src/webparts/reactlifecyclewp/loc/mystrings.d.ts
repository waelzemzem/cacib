declare interface IReactlifecyclewpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ReactlifecyclewpWebPartStrings' {
  const strings: IReactlifecyclewpWebPartStrings;
  export = strings;
}

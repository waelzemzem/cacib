/* tslint:disable */
require("./GetAllListWpDemoWebPart.module.css");
const styles = {
  getAllListWpDemo: 'getAllListWpDemo_235e9212',
  container: 'container_235e9212',
  row: 'row_235e9212',
  column: 'column_235e9212',
  'ms-Grid': 'ms-Grid_235e9212',
  title: 'title_235e9212',
  subTitle: 'subTitle_235e9212',
  description: 'description_235e9212',
  button: 'button_235e9212',
  label: 'label_235e9212'
};

export default styles;
/* tslint:enable */
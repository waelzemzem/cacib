declare interface ITaskListWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'TaskListWebPartStrings' {
  const strings: ITaskListWebPartStrings;
  export = strings;
}

/* tslint:disable */
require('./TaskList.module.css');
const styles = {
  taskList: 'taskList_f9e693bc',
  container: 'container_f9e693bc',
  row: 'row_f9e693bc',
  column: 'column_f9e693bc',
  'ms-Grid': 'ms-Grid_f9e693bc',
  title: 'title_f9e693bc',
  subTitle: 'subTitle_f9e693bc',
  description: 'description_f9e693bc',
  button: 'button_f9e693bc',
  label: 'label_f9e693bc',
};

export default styles;
/* tslint:enable */
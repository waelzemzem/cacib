declare const styles: {
    app: string;
    top: string;
    bottom: string;
};
export default styles;

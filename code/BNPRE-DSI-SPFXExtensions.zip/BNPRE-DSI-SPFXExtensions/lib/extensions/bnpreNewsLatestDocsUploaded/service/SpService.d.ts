import { Documents } from "../models/Documents";
import { PlaceholderContent } from '@microsoft/sp-application-base';
export default class spservices {
    private context;
    constructor(context: PlaceholderContent);
    private onInit();
    getLatestDocuments(webUrl?: string): Promise<any[]>;
    getPathDocument(webUrl: any, ID: any): Promise<any>;
    getLikes(webUrl: any, ID: any): Promise<any>;
    getLatestDocumentsByLibraryInternalName(listTitle: string, listViewTitle: string): Promise<Documents[]>;
}

import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
export interface IBnpreNewsLatestDocsUploadedApplicationCustomizerProperties {
    testMessage: string;
    Header: string;
    Footer: string;
    StyleToggle: string;
    AuthorToggle: string;
    Site: any[];
    listTitle: string;
    listViewTitle: string;
}
/** A Custom Action which can be run during execution of a Client Side Application */
export default class BnpreNewsLatestDocsUploadedApplicationCustomizer extends BaseApplicationCustomizer<IBnpreNewsLatestDocsUploadedApplicationCustomizerProperties> {
    private _topPlaceholder;
    private _bottomPlaceholder;
    onInit(): Promise<void>;
    private _renderPlaceHolders();
    private _onDispose();
}

export interface StylingState {
    News: any[];
    RenderedNews: any[];
}
export interface StylingProps {
    News: any[];
    AuthorToggle: string;
}

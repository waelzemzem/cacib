import * as React from 'react';
import { IReactLatestDocumentsProps } from "./IReactLatestDocumentsProps";
import { IReactLatestDocumentsState } from "./IReactLatestDocumentsState";
export default class ReactLatestDocuments extends React.Component<IReactLatestDocumentsProps, IReactLatestDocumentsState> {
    private _spservices;
    constructor(props: IReactLatestDocumentsProps, state: IReactLatestDocumentsState);
    componentDidMount(): void;
    componentDidUpdate(prevProps: IReactLatestDocumentsProps): void;
    Get(Choice: any): Promise<void>;
    render(): React.ReactElement<IReactLatestDocumentsProps>;
}

import * as React from "react";
import { StylingState, StylingProps } from "./StylingPropsState";
export default class StackStyle extends React.Component<StylingProps, StylingState> {
    constructor(props: StylingProps);
    componentDidMount(): void;
    render(): React.ReactElement<StylingProps>;
}

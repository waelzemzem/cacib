import { PlaceholderContent } from '@microsoft/sp-application-base';
export interface IReactLatestDocumentsProps {
    StyleToggle: string;
    AuthorToggle: string;
    context: PlaceholderContent;
    Site: any[];
    listTitle: string;
    listViewTitle: string;
}

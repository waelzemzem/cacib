export default class Constants {
    static ROOT_ID: string;
    static CONTENT_TYPE_ID: string;
}

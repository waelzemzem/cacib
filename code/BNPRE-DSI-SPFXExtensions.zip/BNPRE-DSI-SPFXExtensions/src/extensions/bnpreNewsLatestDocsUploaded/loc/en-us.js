define([], function() {
  return {
    "Title": "BnpreNewsLatestDocsUploadedApplicationCustomizer",
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "PageNameProjectSpace": "Projects Space",
    "PageNameApplicationsPatrimory": "Applications patrimory",
    "LibraryNameReferenceDocument": "Reference documents",
    "LibraryNameTemplate": "Template library",
    "LibraryNameApplicationMapping": "Application Mapping",  
    "LibraryNameGeneralInformation": "General Information",

    "TickerTitleText": "Headlines - Latest documents",
    "CreatedText" : " Created at ",
    "AuthorText": " by ",

    "ModifiedText" : " Last modified at ",
    "EditorText":" by ",
  }
});
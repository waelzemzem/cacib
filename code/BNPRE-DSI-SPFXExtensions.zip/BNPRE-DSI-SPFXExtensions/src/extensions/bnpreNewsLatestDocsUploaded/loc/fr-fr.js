define([], function() {
  return {
    "Title": "Documents DSI Application - Ticker ",
    "PropertyPaneDescription": "La description",
    "BasicGroupName": "Nom de group",
    "DescriptionFieldLabel": "Description du champ",
    "PageNameProjectSpace": "Espace Projets",
    "PageNameApplicationsPatrimory": "Patrimoine des applications",
    "LibraryNameReferenceDocument": "Documents de référence",
    "LibraryNameTemplate": "Bibliothèque de templates",
    "LibraryNameApplicationMapping": "Cartographies applicatives",  
    "LibraryNameGeneralInformation": "Informations générales",

    "TickerTitleText": "A la Une - derniers documents",
    "CreatedText" : " Créé le ",
    "AuthorText": " par ",

    "ModifiedText" : " Dernière modification le ",
    "EditorText":" par ",

  }
});
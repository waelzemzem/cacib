function MyFunction () {
    alert(" my function called SPFX");
    return false;
}

$('.demo3').easyTicker({
    visible: 1,
    interval: 4000
  });
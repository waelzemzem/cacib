/* tslint:disable */
require('./BnpreNewsLatestDocsUploadedApplicationCustomizer.module.css');
const styles = {
  app: 'app_55d4888e',
  top: 'top_55d4888e',
  bottom: 'bottom_55d4888e',
};

export default styles;
/* tslint:enable */
export default class Constants {
    public static ROOT_ID = 'newsTicker';
    public static CONTENT_TYPE_ID = '0x01010039BC5324DD35CF4DBDEB3B7095400500';
  }
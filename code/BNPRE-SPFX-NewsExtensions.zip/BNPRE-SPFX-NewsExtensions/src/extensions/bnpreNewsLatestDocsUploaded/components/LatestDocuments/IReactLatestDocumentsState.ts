export interface IReactLatestDocumentsState {
    SPGuid: string;
    News: any[];
    Reload: boolean;
  }  
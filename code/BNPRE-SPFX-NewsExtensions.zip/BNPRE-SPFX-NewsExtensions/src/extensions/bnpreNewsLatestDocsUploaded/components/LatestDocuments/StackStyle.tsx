import * as React from "react";
import { StylingState, StylingProps } from "./StylingPropsState";
import * as strings from 'BnpreNewsLatestDocsUploadedApplicationCustomizerStrings';
import * as $ from 'jquery';
require('./../../css/sptickerStyle.css');
require('spticker');

export default class StackStyle extends React.Component<
  StylingProps,
  StylingState
> {
  constructor(props: StylingProps) {
    super(props);
    this.state = {
      News: [],
      RenderedNews: [],
    };
  }

  public componentDidMount() {


  }
  public render(): React.ReactElement<StylingProps> {
    var i = 0;
    // JQuery
    $(document).ready(function () {
      $('.ticker-container ul div').each(function (i) {
        if ($(window).width() >= 500) {
          $(this).find('li').width($(window).width() - parseInt($(this).css('left')));
        }
        if (i == 0) {
          $(this).addClass('ticker-active');
        } else {
          // console.dir( ($(this).find('li')) + ": "+ $(this).attr('class'));
          $(this).addClass('not-active');
        }
        if ($(this).find('li').height() > 30) {
          $(this).find('li').css({
            'height': '20px',
            'width': '200%',
            'text-align': 'left',
            'padding-left': '5px'
          });
          $(this).find('li').css('width', $(this).find('li span').width());
        }
      });
    });

    return (
      <div className="ticker-container">
        <div className="ticker-caption">
          <p> {strings.TickerTitleText}</p>
        </div>
        <ul>
          {this.props.News.map((Post) => {
            // i = i + 1;
            return (
              <div>
                <li> 
                   <a href={Post.Url} target="_blank">{Post.Name}  </a> &ndash;
                  <span >{strings.CreatedText} {Post.Created}</span><span>{strings.AuthorText} {Post.Author}</span> &ndash;
                  <span >{strings.ModifiedText} {Post.Modified}</span><span>{strings.EditorText} {Post.Editor}</span> 

                </li>
              </div>
            );
          })}
        </ul>
      </div>
    );
  }
}
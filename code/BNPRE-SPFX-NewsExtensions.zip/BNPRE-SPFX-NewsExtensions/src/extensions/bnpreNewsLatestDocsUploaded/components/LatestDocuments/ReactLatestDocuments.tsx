import * as React from 'react';
import { IReactLatestDocumentsProps } from "./IReactLatestDocumentsProps";
import { IReactLatestDocumentsState } from "./IReactLatestDocumentsState";
import StackStyle from './StackStyle';
import spservices from "../../services/SpService";
import IEnvirenmentItem from '../../models/IEnvirenmentItem';

export default class ReactLatestDocuments extends React.Component<IReactLatestDocumentsProps, IReactLatestDocumentsState>{

  private _spservices: spservices;
  constructor(props: IReactLatestDocumentsProps, state: IReactLatestDocumentsState) {
    super(props);

    this.state = {
      SPGuid: '',
      News: [],
      Reload: false,
    }
  }

  public componentWillMount(): void {
    this._spservices = new spservices();
  }

  public componentDidMount() {
    this.Get('Default');
  }

  public componentDidUpdate(prevProps: IReactLatestDocumentsProps) {
    if (prevProps.Site !== this.props.Site) {
      this.Get('Default');
    }
  }

  private getitemsBylibrary = async (itemsEnvirenmentSettings: IEnvirenmentItem[]): Promise<any> => {
    let response = [];
    response = await Promise.all(itemsEnvirenmentSettings.map(async (item) => {
      return await this._spservices.getLatestDocumentsByLibrary(item)
    }));
    return response;
  }

  public async Get(Choice) {
    var e: any[] = [];
    let result, concatResult = [];
    if (this.props.Site === undefined || this.props.Site.length < 1 || (Choice === 'Default' && this.props.Site.length < 1)) {
      // get items list settings
      let itemsEnvirenmentSettings = await this._spservices.getEnvirenmentSettings();

      result = await this.getitemsBylibrary(itemsEnvirenmentSettings);

      for (let item of result) {
        if (item.length > 0) {
          concatResult = concatResult.concat(item);
        }
      }
      concatResult.map((doc) => {
        e.push({
          Id: doc.Id,
          Name: doc.Title,
          Author: doc.Author,
          Editor: doc.Editor,
          Created: doc.Created,
          Modified: doc.Modified,
          Url: doc.FileRef + "?web=1"
        });
        if (this.state.Reload === true) {
          this.setState({ News: e, Reload: false });
        }
        else {
          this.setState({ News: e });
        }
      });
    }
    this.setState({ News: e });
  }

  public render(): React.ReactElement<IReactLatestDocumentsProps> {
    return (
      <div style={{ height: '100%', width: '100%' }}>
        {<StackStyle News={this.state.News} AuthorToggle={this.props.AuthorToggle}></StackStyle>}
      </div>)
  }
}


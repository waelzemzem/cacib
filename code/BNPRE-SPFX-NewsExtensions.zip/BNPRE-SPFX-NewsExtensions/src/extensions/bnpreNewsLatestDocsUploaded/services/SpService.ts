import { sp, Web } from "@pnp/sp";
import Constants from "../helpers/Constants";
import ISpService from "./ISpService";
import IEnvirenmentItem from "../models/IEnvirenmentItem";
import ISPEnvirenmentItem from "../models/ISPEnvirenmentItem";
import { IDocumentsItem } from "../models/IDocumentsItem";
import { ISPDocumentsItem } from "../models/ISPDocumentsItem"

export default class spservices implements ISpService {


  // Get Items of list settings Latest Documents
  public async getEnvirenmentSettings(): Promise<IEnvirenmentItem[]> {
    // old sp.web.lists.getByTitle("Settings list latest Documents")
   // sp.web.getList("/Lists/SettingsListLatestDocuments") 
 
    return  sp.web.lists.getByTitle("Settings list latest Documents")
      .items
      .select("Title,SiteUrl")
      .usingCaching()
      .get()
      .then(
        (items: ISPEnvirenmentItem[]): IEnvirenmentItem[] => {
          const siteEnvItems: IEnvirenmentItem[] = [];
          items.forEach(
            (item: ISPEnvirenmentItem): void => {
              siteEnvItems.push({
                libraryName: item.Title,
                url: item.SiteUrl
              });
            }
          );
          return siteEnvItems;
        }
      );
  }

 public async getLatestDocuments(envItems?: IEnvirenmentItem[]): Promise<IDocumentsItem[]> {
    try {
      // define a date interval (10 jours)
      let today: string = (new Date()).toISOString();
      today = `${today.substring(0, today.indexOf('T'))}T00:00:00Z`
      let pastDate = new Date(new Date().setDate(new Date().getDate() - 10)).toISOString();
    
      // Request to list library   
      var documentsItems: IDocumentsItem[] = [];

      envItems.map(async (env) => {
        const items = await sp.web.getList(env.url + env.libraryName).items
          .select("id,Title,Created,Modified,FileRef,ContentTypeId"
                , "AuthorId,Author/ID,Author/Title"
                , "EditorId,Editor/ID,Editor/Title"
                , "FileLeafRef, File/Name")
          .expand("Author,Editor,File")
          .filter(`datetime'${pastDate}' le Modified`)
          .get()
          .then(
            (items: ISPDocumentsItem[]) => {
              items.forEach(
                (item: ISPDocumentsItem): void => {
                  documentsItems.push({
                    Id: item.Id,
                    Title: item.File.Name,
                    Created: (item.Created).split('T')[0],
                    Modified: (item.Modified).split('T')[0],
                    FileRef: item.FileRef,
                    ContentTypeId: item.ContentTypeId,
                    Author: item.Author.Title,
                    Editor: item.Editor.Title,
                    FileName: item.File.Name,
                    FileLeafRef: item.FileLeafRef
                  });
                }
              );
            }
          );
      });
      // Old
      // var Res = [];
      // Items.map(item => {
      //   // var UrlDocument = webUrl.split('/sites/')[0] + item.FileRef;
      //   // var CreatedDate = (item.Created).split('T')[0];
      //   // var ModifiedDate = (item.Modified).split('T')[0];
      //   if (!item.ContentTypeId.startsWith(Constants.CONTENT_TYPE_ID)) {
      //     Res.push({
      //       Id: item.Id,
      //       Name: item.File.Name,
      //       Author: item.Author.Title,
      //       Editor: item.Editor.Title,
      //       Created: (item.Created).split('T')[0],
      //       Modified: (item.Modified).split('T')[0],
      //       Url: webUrl.split('/sites/')[0] + item.FileRef
      //     });
      //   }
      // });
      // return Res;
      return documentsItems;
    }
    catch (error) {
      return Promise.reject(error)
    }
  }

  public async getLatestDocumentsByLibrary(env: IEnvirenmentItem): Promise<IDocumentsItem[]> {
    try {

      // define a date interval (10 jours)
      let today: string = (new Date()).toISOString();
      today = `${today.substring(0, today.indexOf('T'))}T00:00:00Z`
      let pastDate = new Date(new Date().setDate(new Date().getDate() - 10)).toISOString();
      
      // Request to list library   
      var documentsItems: IDocumentsItem[] = [];
      const items = await sp.web.getList(env.url + env.libraryName).items
        .select(
          "id,Title,Created,Modified,FileRef,ContentTypeId"
          , "AuthorId,Author/ID,Author/Title"
          , "EditorId,Editor/ID,Editor/Title"
          , "FileLeafRef, File/Name")
        .expand("Author,Editor,File")
        .filter(`datetime'${pastDate}' le Modified`)
        .get()
        .then(
          (items: ISPDocumentsItem[]) => {
            items.forEach(
              (item: ISPDocumentsItem): void => {
                documentsItems.push({
                  Id: item.Id,
                  Title: item.File.Name,
                  Created: (item.Created).split('T')[0],
                  Modified: (item.Modified).split('T')[0],
                  FileRef: item.FileRef,
                  ContentTypeId: item.ContentTypeId,
                  Author: item.Author.Title,
                  Editor: item.Editor.Title,
                  FileName: item.File.Name,
                  FileLeafRef: item.FileLeafRef
                  // IconUrl: "item.IconUrl"
                });
              }
            );
          }
        );
      return documentsItems;
    }
    catch (error) {
      return Promise.reject(error)
    }
  }

 public async getPathDocument(webUrl, UserId): Promise<any> {
    try {
      let siteWeb = new Web(webUrl);
      let userId: any = await siteWeb.getUserById(UserId).get();
      return userId;
    }
    catch (error) {
      return Promise.reject(error);
    }
  }

  public async getLikes(webUrl, ID): Promise<any> {
    try {
      let siteWeb = new Web(webUrl);
      // let siteWeb = new Web(Site);
      let Likes: any = await siteWeb.lists.getByTitle("Site%20Pages").items.getById(ID).getLikedByInformation();
      return Likes.likeCount;
    }

    catch (error) {
      return Promise.reject(error);
    }
  }

  public async getLatestDocumentsByLibraryInternalName(listTitle: string, listViewTitle: string): Promise<IDocumentsItem[]> {

    //  // Get xml schema for the "Published News" view
    //  const list = sp.web.lists.getByTitle(listTitle);
    //  const view = await list.views.getByTitle(listViewTitle)();
    //  if (!view) return [];

    //  const items = await list.getItemsByCAMLQuery({ViewXml: view.ListViewXml});
    //  return items.map(item => (<Documents>{
    //   ID: item['Title'],
    //   FileLeafRef: item['Title'],
    //   Created:new Date(item['Title']),
    //   Author: item['Title'],
    //   Modified:  new Date(item['Title']),
    //   Editor: item['Title'],
    //   FileRef: item['Title'],
    //   ProjectName: item['Title'],
    //   LibraryName: item['Title'],
    //   ParentFolder: item['Title'],
    //   IconUrl: item['Title']

    //  }));
    return null;

  }

}
import { IDocumentsItem } from "../models/IDocumentsItem";
import IEnvirenmentItem from "../models/IEnvirenmentItem";

export default interface ISpService {
    getEnvirenmentSettings(): Promise<IEnvirenmentItem[]>;
    getLatestDocuments():  Promise<IDocumentsItem[]> ;
}

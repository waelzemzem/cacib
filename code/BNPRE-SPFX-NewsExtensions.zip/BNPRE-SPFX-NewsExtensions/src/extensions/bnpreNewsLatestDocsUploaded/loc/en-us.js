define([], function() {
  return {
    "Title": "BnpreNewsLatestDocsUploadedApplicationCustomizer",
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "PageNameProjectSpace": "Projects Space",
    "PageNameApplicationsPatrimory": "Applications patrimory",
    "LibraryNameReferenceDocument": "Reference documents",
    "LibraryNameTemplate": "Template library",
    "LibraryNameApplicationMapping": "Application Mapping",  
    "LibraryNameGeneralInformation": "General Information",

    "TickerTitleText": "Headlines - Latest documents",
    "CreatedText" : " Published at ",
    "AuthorText": " by ",

    "ModifiedText" : " Modified at ",
    "EditorText":" by ",
  }
});


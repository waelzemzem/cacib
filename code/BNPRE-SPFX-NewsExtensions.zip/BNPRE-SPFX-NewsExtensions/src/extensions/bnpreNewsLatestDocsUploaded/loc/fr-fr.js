define([], function() {
  return {
    "Title": "Documents DSI Application - Ticker ",
    "PropertyPaneDescription": "La description",
    "BasicGroupName": "Nom de group",
    "DescriptionFieldLabel": "Description du champ",
    "PageNameProjectSpace": "Espace Projets",
    "PageNameApplicationsPatrimory": "Patrimoine des applications",
    "LibraryNameReferenceDocument": "Documents de référence",
    "LibraryNameTemplate": "Bibliothèque de templates",
    "LibraryNameApplicationMapping": "Cartographies applicatives",  
    "LibraryNameGeneralInformation": "Informations générales",

    "TickerTitleText": "A la Une - derniers documents",
    "CreatedText" : " Publié le ",
    "AuthorText": " par ",

    "ModifiedText" : " Modifié le ",
    "EditorText":" par ",

  }
});
import { IAuthor } from "./IAuthor";
import { IEditor } from "./IEditor";
import { IFile } from "./IFile";

export type ISPDocumentsItem = {
  Id: string;
  Title: string;
  Created: string;
  Modified: string;
  FileRef: string;
  ContentTypeId: string;
  Author: IAuthor;
  Editor: IEditor;
  Name: string;
  File: IFile;
  FileLeafRef:string;
  // IconUrl: string;
  // ProjectName: string;
  // LibraryName: string;
  // ParentFolder: string;
};
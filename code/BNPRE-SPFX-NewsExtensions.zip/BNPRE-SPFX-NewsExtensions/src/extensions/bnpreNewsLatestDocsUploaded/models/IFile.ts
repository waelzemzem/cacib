export interface IFile {
    Id: number;
    Title: string;
    Name: string;
    Size: number;
  }
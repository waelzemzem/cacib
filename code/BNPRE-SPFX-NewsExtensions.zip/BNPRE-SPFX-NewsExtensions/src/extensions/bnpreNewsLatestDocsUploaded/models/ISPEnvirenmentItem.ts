export default interface ISPEnvirenmentItem {
    Title: string;
    SiteUrl?: string;
}
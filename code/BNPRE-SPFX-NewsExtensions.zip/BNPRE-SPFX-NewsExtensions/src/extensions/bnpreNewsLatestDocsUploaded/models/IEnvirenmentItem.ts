export default interface IEnvirenmentItem {
    libraryName: string;
    url?: string;
}




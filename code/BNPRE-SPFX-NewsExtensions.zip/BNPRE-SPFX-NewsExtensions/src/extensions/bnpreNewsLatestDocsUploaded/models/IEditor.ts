export interface IEditor {
    Id: number;
    Title: string;
  }
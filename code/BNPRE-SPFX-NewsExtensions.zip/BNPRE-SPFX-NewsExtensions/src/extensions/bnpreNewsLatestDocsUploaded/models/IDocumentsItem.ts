export type IDocumentsItem = {
  Id: string;
  Title: string;
  Created: string;
  Modified: string;
  FileRef: string;
  ContentTypeId: string;
  Author: string;
  Editor: string;
  FileName: string;
  FileLeafRef:string;
  // IconUrl: string;
  // ProjectName: string;
  // LibraryName: string;
  // ParentFolder: string;

};





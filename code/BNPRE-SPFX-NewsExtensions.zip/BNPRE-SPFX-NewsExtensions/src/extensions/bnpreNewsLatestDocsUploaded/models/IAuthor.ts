export interface IAuthor {
    Id: number;
    Title: string;
  }
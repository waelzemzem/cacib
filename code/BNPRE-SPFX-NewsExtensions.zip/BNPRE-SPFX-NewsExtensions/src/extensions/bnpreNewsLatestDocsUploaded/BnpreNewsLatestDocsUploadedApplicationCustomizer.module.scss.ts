/* tslint:disable */
require('./BnpreNewsLatestDocsUploadedApplicationCustomizer.module.css');
const styles = {
  app: 'app_9a3e8287',
  top: 'top_9a3e8287',
  bottom: 'bottom_9a3e8287',
};

export default styles;
/* tslint:enable */
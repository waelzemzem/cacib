import * as React from 'react';
import styles from './WebPartRunPage.module.scss';
import { IWebPartRunPageProps } from './IWebPartRunPageProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { SPComponentLoader } from '@microsoft/sp-loader';
import {
  DocumentCard,
  DocumentCardActivity,
  DocumentCardPreview,
  DocumentCardTitle,
  IDocumentCardPreviewProps,
  DocumentCardLocation,
  DocumentCardType
} from 'office-ui-fabric-react/lib/DocumentCard';
import { ImageFit } from 'office-ui-fabric-react/lib/Image';
import * as strings from 'WebPartRunPageWebPartStrings';
require('../css/card-style.css');


export default class WebPartRunPage extends React.Component<IWebPartRunPageProps, {}> {
  public constructor() {
    super();
    let cssURL = '/sites/DocsDSI/Style Library/DocsDSI/Commun/Css/bootstrap.min.css';
    SPComponentLoader.loadCss(cssURL);
    SPComponentLoader.loadScript('/sites/DocsDSI//Style Library/DocsDSI/Commun/Css/bootstrap.rtl.min.css');
    SPComponentLoader.loadCss('/sites/DocsDSI//Style Library/DocsDSI/Commun/Css/bootstrap-utilities.min.css');
  }

  public render(): React.ReactElement<IWebPartRunPageProps> {
    const previewProps: IDocumentCardPreviewProps = {
      previewImages: [
        {
          previewImageSrc: String(require('../img/document-preview.png')),
          // iconSrc: String(require('../img/icon-file.png')),
          imageFit: ImageFit.cover,
           height: 180,
          accentColor: '#124e4b'
        }
      ],
    };

    return (
      <div>
        <div className='container'>
          <div className='row'>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
              <ul className="nav justify-content-end">
                <li className="nav-item">
                  <a href="../Lists/AppsList" className="nav-link" role="button" aria-pressed="true">
                    {strings.NavitemApplicationList}
                  </a>
                </li>
              </ul>
            </nav>
          </div>

          <div className='row'>
            <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../ChangeAdvisoryBoard'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameChangeAdvisoryBoard} />
                </DocumentCard>
              </div>
            </div>
            <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../Asset'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameAsset} />
                </DocumentCard>
              </div>
            </div>
            <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../ServiceReview'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameServiceReview} />
                </DocumentCard>
              </div>
            </div>
            </div>

          <div className='row'>

          <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../RunOtherDocsLibrary'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameRunOtherDocsLibrary} />
                </DocumentCard>
              </div>
            </div>


            <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../RunFileArchitectureSchemeLibrary'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameRunFileArchitectureSchemeLibrary} />
                </DocumentCard>
              </div>
            </div>

            <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../RunFileSchemeOfExploitationLibrary'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameRunFileSchemeOfExploitationLibrary} />
                </DocumentCard>
              </div>
            </div>

            <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../RunFileSchemeOfInstallationLibrary'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameRunFileSchemeOfInstallationLibrary} />
                </DocumentCard>
              </div>
            </div>

            <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../RunSanityCheckApplicationLibrary'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameRunSanityCheckApplicationLibrary} />
                </DocumentCard>
              </div>
            </div>

            <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../RunSupportDocumentationLibrary'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameRunSupportDocumentationLibrary} />
                </DocumentCard>
              </div>
            </div>
            <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../RunUserGuideLibrary'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameRunUserGuideLibrary} />
                </DocumentCard>
              </div>
            </div>
            <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../RunSecurityDocumentLibrary'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameRunSecurityDocumentLibrary} />
                </DocumentCard>
              </div>
            </div>
            <div className='col-6 col-md-3'>
              <div className='card'>
              <DocumentCard onClickHref='../RunNonRegressionTestsBookLibrary'>
                  <DocumentCardPreview {...previewProps} />
                  <DocumentCardTitle title={strings.LibraryNameRunNonRegressionTestsBookLibrary} />
                </DocumentCard>
              </div>
            </div>

          </div>
          </div>
    
      </div>
    );
  }
}

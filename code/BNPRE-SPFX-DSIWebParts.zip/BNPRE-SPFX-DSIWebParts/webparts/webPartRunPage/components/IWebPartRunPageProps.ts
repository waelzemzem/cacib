export interface IWebPartRunPageProps {
  description: string;
}

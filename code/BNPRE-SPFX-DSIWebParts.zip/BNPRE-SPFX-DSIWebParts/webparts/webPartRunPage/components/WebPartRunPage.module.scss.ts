/* tslint:disable */
require('./WebPartRunPage.module.css');
const styles = {
  webPartRunPage: 'webPartRunPage_50b81d75',
  container: 'container_50b81d75',
  title: 'title_50b81d75',
  subTitle: 'subTitle_50b81d75',
  description: 'description_50b81d75',
};

export default styles;
/* tslint:enable */
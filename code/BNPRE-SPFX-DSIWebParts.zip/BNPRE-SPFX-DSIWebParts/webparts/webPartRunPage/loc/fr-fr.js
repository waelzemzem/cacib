define([], function() {
  return {
    "PropertyPaneDescription": "La description",
    "BasicGroupName": "Nom de group",
    "DescriptionFieldLabel": "Description du champ",

    
    "LibraryNameRunOtherDocsLibrary": "Run - Autres fichiers",

    "LibraryNameRunFileArchitectureSchemeLibrary": "Dossier / Schéma d’architecture",
    "LibraryNameRunFileSchemeOfExploitationLibrary": "Dossier / Schéma d’exploitation",
    "LibraryNameRunFileSchemeOfInstallationLibrary": "Dossier / Schéma d’installation",  
    "LibraryNameRunSanityCheckApplicationLibrary": "Sanity check applicatif",
    "LibraryNameRunSupportDocumentationLibrary": "Fiches support",
    "LibraryNameRunUserGuideLibrary": "Manuel utilisateur",
    "LibraryNameRunSecurityDocumentLibrary": "Document sécurité",  
    "LibraryNameRunNonRegressionTestsBookLibrary": "Tests de Non Régression",
    "NavitemCreateNewApplication": "Créer un application",
    "NavitemApplicationList": "Liste des applications",

    "LibraryNameChangeAdvisoryBoard": "Comité des Changements",
    "LibraryNameAsset": "Asset",
    "LibraryNameServiceReview": "Revue des services",
  }
});
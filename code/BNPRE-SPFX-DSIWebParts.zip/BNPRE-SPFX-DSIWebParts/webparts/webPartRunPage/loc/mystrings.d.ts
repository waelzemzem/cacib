declare interface IWebPartRunPageWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;

  LibraryNameRunFileArchitectureSchemeLibrary: string;

  LibraryNameRunOtherDocsLibrary: string;

  LibraryNameRunFileSchemeOfExploitationLibrary: string;
  LibraryNameRunFileSchemeOfInstallationLibrary: string;
  LibraryNameRunSanityCheckApplicationLibrary: string;
  LibraryNameRunSupportDocumentationLibrary: string;
  LibraryNameRunUserGuideLibrary: string;
  LibraryNameRunSecurityDocumentLibrary: string;
  LibraryNameRunNonRegressionTestsBookLibrary: string;
  NavitemCreateNewApplication: string;
  NavitemApplicationList: string;

  LibraryNameChangeAdvisoryBoard: string;
  LibraryNameAsset: string;
  LibraryNameServiceReview: string;
}

declare module 'WebPartRunPageWebPartStrings' {
  const strings: IWebPartRunPageWebPartStrings;
  export = strings;
}

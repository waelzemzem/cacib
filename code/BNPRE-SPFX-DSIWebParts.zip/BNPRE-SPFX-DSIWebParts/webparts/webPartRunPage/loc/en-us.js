define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",   
  
    "LibraryNameRunOtherDocsLibrary": "Run - Other documents",



    "LibraryNameRunFileArchitectureSchemeLibrary": "File / Architecture Scheme",
    "LibraryNameRunFileSchemeOfExploitationLibrary": "File / Scheme of Exploitation",
    "LibraryNameRunFileSchemeOfInstallationLibrary": "File / Scheme of Installation",  
    "LibraryNameRunSanityCheckApplicationLibrary": "Sanity Check Application",
    "LibraryNameRunSupportDocumentationLibrary": "Support Documentation",
    "LibraryNameRunUserGuideLibrary": "User Guide",
    "LibraryNameRunSecurityDocumentLibrary": "Security Document",  
    "LibraryNameRunNonRegressionTestsBookLibrary": "Non Regression Tests book",
    "NavitemCreateNewApplication": "Create new application",
    "NavitemApplicationList": "Applications patrimony list",

    "LibraryNameChangeAdvisoryBoard": "Change Advisory Board (CAB)",
    "LibraryNameAsset": "Asset",
    "LibraryNameServiceReview": "Service Review",

  }
});
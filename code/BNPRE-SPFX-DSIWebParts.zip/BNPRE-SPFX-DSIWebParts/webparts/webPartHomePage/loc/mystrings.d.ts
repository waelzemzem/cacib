declare interface IWebPartHomePageWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  PageNameProjectSpace: string;
  PageNameApplicationsPatrimory: string;
  LibraryNameReferenceDocument: string;
  LibraryNameTemplate: string;
  LibraryNameApplicationMapping: string;
  LibraryNameGeneralInformation: string;
  Thumbnail: string;
  Title: string;
  Description: string;
  Url: string;
}

declare module 'WebPartHomePageWebPartStrings' {
  const strings: IWebPartHomePageWebPartStrings;
  export = strings;
}

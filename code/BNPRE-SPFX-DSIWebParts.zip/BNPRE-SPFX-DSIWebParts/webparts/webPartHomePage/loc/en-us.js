define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "PageNameProjectSpace": "Projects Space",
    "PageNameApplicationsPatrimory": "Applications patrimory",
    "LibraryNameReferenceDocument": "Reference documents",
    "LibraryNameTemplate": "Template library",
    "LibraryNameApplicationMapping": "Application Mapping",  
    "LibraryNameGeneralInformation": "General Information",

    "Thumbnail": "/sites/docsdsi/Style%20Library/DocsDSI/HomePage/SiteAssets/images/check-in-out.png",
    "Title": "Check-out / Check-in files in the documents library",
    "Description": "This feature is enabled in some document libraries, it makes it mandatory to check out files before editing them. Extraction happens automatically when adding or modifying a document",
    "Url": "/sites/docsdsi/SitePages/CheckIn-CheckOut-en.aspx"
  }
});
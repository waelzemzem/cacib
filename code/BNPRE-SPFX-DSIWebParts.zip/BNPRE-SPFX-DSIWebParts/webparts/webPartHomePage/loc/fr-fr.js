define([], function() {
  return {
    "PropertyPaneDescription": "La description",
    "BasicGroupName": "Nom de group",
    "DescriptionFieldLabel": "Description du champ",
    "PageNameProjectSpace": "Espace Projets",
    "PageNameApplicationsPatrimory": "Patrimoine des applications",
    "LibraryNameReferenceDocument": "Documents de référence",
    "LibraryNameTemplate": "Bibliothèque de templates",
    "LibraryNameApplicationMapping": "Cartographies applicatives",  
    "LibraryNameGeneralInformation": "Informations générales",

    "Thumbnail": "/sites/docsdsi/Style%20Library/DocsDSI/HomePage/SiteAssets/images/check-in-out.png",
    "Title": "Extraire / archiver des fichiers dans une bibliothèque de documents",
    "Description": "Cette fonctionnalité est activée dans certaines bibliothèques de documents, elle rendre l’extraction des fichiers obligatoire avant de pouvoir les modifier. L’extraction se fait automatiquement lors de l’ajout ou de la modification d’un document",
    "Url": "/sites/docsdsi/SitePages/CheckIn-CheckOut-fr.aspx"
  
  }
});
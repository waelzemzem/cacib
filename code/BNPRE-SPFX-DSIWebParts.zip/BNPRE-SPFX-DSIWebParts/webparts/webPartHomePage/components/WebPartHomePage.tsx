import * as React from 'react';
import styles from './WebPartHomePage.module.scss';
import { IWebPartHomePageProps } from './IWebPartHomePageProps';
import { SPComponentLoader } from '@microsoft/sp-loader';
import {
  IDocumentCardPreviewProps
} from 'office-ui-fabric-react/lib/DocumentCard';
import { ImageFit } from 'office-ui-fabric-react/lib/Image';
import * as strings from 'WebPartHomePageWebPartStrings';
require('../css/card-style.css');

export default class WebPartHomePage extends React.Component<IWebPartHomePageProps, {}> {

  public constructor() {
    super();
    let cssURL = '/sites/DocsDSI/Style Library/DocsDSI/Commun/Css/bootstrap.min.css';
    SPComponentLoader.loadCss(cssURL);
    //   SPComponentLoader.loadScript('/sites/DocsDSI/Style Library/DocsDSI/Commun/Css/bootstrap.rtl.min.css');
    //   SPComponentLoader.loadCss('/sites/DocsDSI/Style Library/DocsDSI/Commun/Css/bootstrap-utilities.min.css');
  }
  public render(): React.ReactElement<IWebPartHomePageProps> {
    return (
      <div>
        <div className="row row-cols-1  row-cols-lg-3">
          <div className="col mb-5 mb-lg-0 ">
            <div className="card h-50">
              <img className="card-img blur-up x-hidden-focus" alt="" src="/sites/docsdsi/Style%20Library/DocsDSI/HomePage/SiteAssets/images/project.png"></img>
              <p className="mb-0 pb-3 pt-2 text-center depth-16">
                <a href='Projects-Space.aspx' className="btn btn-collapse">{strings.PageNameProjectSpace} </a>
              </p>
            </div>
          </div>
          <div className="col mb-5 mb-lg-0 ">
            <div className="card h-50">
              <img className="card-img" alt="" src="/sites/docsdsi/Style%20Library/DocsDSI/HomePage/SiteAssets/images/apps.png"></img>
              <p className="mb-0 pb-3 pt-2 text-center depth-16">
                <a href='Runs-Space.aspx' className="btn btn-collapse">{strings.PageNameApplicationsPatrimory} </a>
              </p>
            </div>
          </div>
          <div className="col mb-5 mb-lg-0 ">
            <div className="card h-75">
              <div className={styles.ImgContainer}>
                <img src={strings.Thumbnail} className="card-img"></img>
              </div>
              <div className="bg-7fb190">
                <div className={styles.TitleContainer}>
                  <a className={styles.TitleStyling} href={strings.Url}>
                    {strings.Title}</a>
                </div>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  {strings.Description ? strings.Description.substring(0, 182) + '…' : '…'}
                </p>
              </div>
            </div>
          </div>
        </div>
      
        <div className="row row-cols-1  row-cols-lg-4">
          <div className="col mb-5 mb-lg-0 ">
            <div className="card h-50">
              <img className="card-img blur-up x-hidden-focus" alt=""
                src="/sites/docsdsi/Style%20Library/DocsDSI/HomePage/SiteAssets/images/reference-documents.png"></img>
              <p className="mb-0 pb-3 pt-2 text-center depth-16">
                <a href='../AppProceduresDocsLibrary' className="btn btn-collapse">{strings.LibraryNameReferenceDocument} </a>
              </p>
            </div>
          </div>
          <div className="col mb-5 mb-lg-0 ">
            <div className="card h-50">
              <img className="card-img blur-up" alt="" src="/sites/docsdsi/Style%20Library/DocsDSI/HomePage/SiteAssets/images/template-library.png"></img>
              <p className="mb-0 pb-3 pt-2 text-center depth-16">
                <a href='../AppTemplateDocsLibrary' className="btn btn-collapse">{strings.LibraryNameTemplate} </a>
              </p>
            </div>
          </div>
          <div className="col mb-5 mb-lg-0 x-hidden-focus">
            <div className="card h-50">
              <img className="card-img blur-up lazyloaded" alt="" src="/sites/docsdsi/Style%20Library/DocsDSI/HomePage/SiteAssets/images/application-mapping.png"></img>
              <p className="mb-0 pb-3 pt-2 text-center depth-16">
                <a href='../ApplicationMappingLibrary' className="btn btn-collapse">{strings.LibraryNameApplicationMapping} </a>
              </p>
            </div>
          </div>
          <div className="col mb-5 mb-lg-0 x-hidden-focus">
            <div className="card h-50">
              <img className="card-img blur-up lazyloaded" alt=""
                src="/sites/docsdsi/Style%20Library/DocsDSI/HomePage/SiteAssets/images/general-Informations.png"></img>
              <p className="mb-0 pb-3 pt-2 text-center depth-16">
                <a href='../AppGeneralInfDocsLibrary' className="btn btn-collapse">{strings.LibraryNameGeneralInformation} </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

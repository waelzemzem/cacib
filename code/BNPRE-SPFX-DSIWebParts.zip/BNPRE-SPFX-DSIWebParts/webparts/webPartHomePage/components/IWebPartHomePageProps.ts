export interface IWebPartHomePageProps {
  description: string;
}

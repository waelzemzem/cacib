/* tslint:disable */
require('./WebPartHomePage.module.css');
const styles = {
  webPartHomePage: 'webPartHomePage_968e53ac',
  container: 'container_968e53ac',
  row: 'row_968e53ac',
  column: 'column_968e53ac',
  'ms-Grid': 'ms-Grid_968e53ac',
  title: 'title_968e53ac',
  subTitle: 'subTitle_968e53ac',
  description: 'description_968e53ac',
  button: 'button_968e53ac',
  label: 'label_968e53ac',
  'card-img': 'card-img_968e53ac',
  'card-img-bottom': 'card-img-bottom_968e53ac',
  'card-img-top': 'card-img-top_968e53ac',
  ImgContainer: 'ImgContainer_968e53ac',
  Image: 'Image_968e53ac',
  NewsBody: 'NewsBody_968e53ac',
  TitleContainer: 'TitleContainer_968e53ac',
  TitleStyling: 'TitleStyling_968e53ac',
  DescriptionContainer: 'DescriptionContainer_968e53ac',
  'bg-7fb190': 'bg-7fb190_968e53ac',
};

export default styles;
/* tslint:enable */
import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';

import * as strings from 'WebPartProjectsSpacePageWebPartStrings';
import WebPartProjectsSpacePage from './components/WebPartProjectsSpacePage';
import { IWebPartProjectsSpacePageProps } from './components/IWebPartProjectsSpacePageProps';

export interface IWebPartProjectsSpacePageWebPartProps {
  description: string;
}

export default class WebPartProjectsSpacePageWebPart extends BaseClientSideWebPart<IWebPartProjectsSpacePageWebPartProps> {

  public render(): void {
    const element: React.ReactElement<IWebPartProjectsSpacePageProps > = React.createElement(
      WebPartProjectsSpacePage,
      {
        description: this.properties.description
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}

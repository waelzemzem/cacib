define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    
    "LibraryNameProjectsOtherDocsLibrary": "Other Files",
    "LibraryNameProjectsIDCardsDocsLibrary": "ID Cards",
    
    "LibraryNameProjectsCOPILDocsLibrary": "Steering committee",

    "LibraryNameProjectsCOMITDocsLibrary": "COMIT Files",
    "LibraryNameProjectsSVCDocsLibrary": "SVC Files",  
    "LibraryNameProjectsCMATDocsLibrary": "CMAT Files",
    "LibraryNameProjectsCvitDocsLibrary": "CVIT Files ",  
    "LibraryNameProjectsC2IDocsLibrary": "C2I Files",

    "LibraryNameProjectsIRPPDocsLibrary": "IRPP Files",
    "LibraryNameProjectsDemandsDocsLibrary": "Demands Files",
    "LibraryNameProjectsSpecificationsDocsLibrary": "Specifications Files",  
    "LibraryNameProjectsReleaseNotesDocsLibrary": "Release notes Files",
    
    "LibraryNameProjectsTestsBookDocsLibrary": "Tests book Files",
    "LibraryNameProjectsMinutesOfMeetingDocsLibrary": " Minutes / GO,NOGO Files",
    "LibraryNameProjectsDeliveryCardsDocsLibrary": "Delivery cards Files",  
    "LibraryNameProjectsBalanceSheetDocsLibrary": "Balance Sheet Files Files",

    "NavitemCreateNewProject": "Create a new project space",
    "NavitemProjectsList": "List of projects",
  }
});




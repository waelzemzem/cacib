define([], function() {
  return {
    "PropertyPaneDescription": "La description",
    "BasicGroupName": "Nom de group",
    "DescriptionFieldLabel": "Description du champ",

    "LibraryNameProjectsOtherDocsLibrary": "Autres fichiers projet",
    "LibraryNameProjectsIDCardsDocsLibrary": "ID Cards",

    "LibraryNameProjectsCOPILDocsLibrary": "COPIL",

    "LibraryNameProjectsCOMITDocsLibrary": "Fichiers COMIT",
    "LibraryNameProjectsSVCDocsLibrary": "Fichiers SVC",  

    "LibraryNameProjectsCMATDocsLibrary": "Fichiers CMAT",
    "LibraryNameProjectsCvitDocsLibrary": "Fichiers CVIT",  
    "LibraryNameProjectsC2IDocsLibrary": "Fichiers C2I",

    "LibraryNameProjectsIRPPDocsLibrary": "Fichiers IRPP",
    "LibraryNameProjectsDemandsDocsLibrary": "Fichiers Exigences",
    "LibraryNameProjectsSpecificationsDocsLibrary": "Documents Spécifications",  
    "LibraryNameProjectsReleaseNotesDocsLibrary": "Fichiers Release notes",
    
    "LibraryNameProjectsTestsBookDocsLibrary": "Cahier de recette",
    "LibraryNameProjectsMinutesOfMeetingDocsLibrary": "PV / GO,NOGO",
    "LibraryNameProjectsDeliveryCardsDocsLibrary": "Fiches de livraison",  
    "LibraryNameProjectsBalanceSheetDocsLibrary": "Bilan",

    "NavitemCreateNewProject": "Créer un espace projet",
    "NavitemProjectsList": "Liste des projets",

 
  }
});
declare interface IWebPartProjectsSpacePageWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;

  LibraryNameProjectsOtherDocsLibrary: string;

  LibraryNameProjectsIDCardsDocsLibrary: string;


  LibraryNameProjectsCOPILDocsLibrary: string

  LibraryNameProjectsCOMITDocsLibrary: string;
  LibraryNameProjectsCMATDocsLibrary: string;
  LibraryNameProjectsCvitDocsLibrary: string;

  LibraryNameProjectsSVCDocsLibrary: string;


  LibraryNameProjectsC2IDocsLibrary: string;

  LibraryNameProjectsIRPPDocsLibrary: string;
  LibraryNameProjectsDemandsDocsLibrary: string;
  LibraryNameProjectsSpecificationsDocsLibrary: string;
  LibraryNameProjectsReleaseNotesDocsLibrary: string;

  LibraryNameProjectsTestsBookDocsLibrary: string;
  LibraryNameProjectsMinutesOfMeetingDocsLibrary: string;
  LibraryNameProjectsDeliveryCardsDocsLibrary: string;
  LibraryNameProjectsBalanceSheetDocsLibrary: string;

  NavitemCreateNewProject: string;
  NavitemProjectsList: string;

}

declare module 'WebPartProjectsSpacePageWebPartStrings' {
  const strings: IWebPartProjectsSpacePageWebPartStrings;
  export = strings;
}

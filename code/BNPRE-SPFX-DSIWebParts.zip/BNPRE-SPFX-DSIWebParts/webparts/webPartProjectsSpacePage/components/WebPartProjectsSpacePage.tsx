import * as React from 'react';
import styles from './WebPartProjectsSpacePage.module.scss';
import { IWebPartProjectsSpacePageProps } from './IWebPartProjectsSpacePageProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { SPComponentLoader } from '@microsoft/sp-loader';
import {
  DocumentCard,
  DocumentCardActivity,
  DocumentCardPreview,
  DocumentCardTitle,
  IDocumentCardPreviewProps,
  DocumentCardLocation,
  DocumentCardType
} from 'office-ui-fabric-react/lib/DocumentCard';
import { ImageFit } from 'office-ui-fabric-react/lib/Image';
import * as strings from 'WebPartProjectsSpacePageWebPartStrings';
require('../css/card-style.css');


export default class WebPartProjectsSpacePage extends React.Component<IWebPartProjectsSpacePageProps, {}> {
  public constructor() {
    super();
    let cssURL = '/sites/DocsDSI/Style Library/DocsDSI/Commun/Css/bootstrap.min.css';
    SPComponentLoader.loadCss(cssURL);
    SPComponentLoader.loadScript('/sites/DocsDSI//Style Library/DocsDSI/Commun/Css/bootstrap.rtl.min.css');
    SPComponentLoader.loadCss('/sites/DocsDSI//Style Library/DocsDSI/Commun/Css/bootstrap-utilities.min.css');
  }


  public render(): React.ReactElement<IWebPartProjectsSpacePageProps> {
    const previewProps: IDocumentCardPreviewProps = {
      previewImages: [
        {
          previewImageSrc: String(require('../img/document-preview.png')),
          // iconSrc: String(require('../img/icon-file.png')),
          imageFit: ImageFit.cover,
          height: 180,
          accentColor: '#124e4b'
        }
      ],
    };

    return (
      <div>
        <div className='container'>
          <div className='row  px-md-4'>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
              <ul className="nav justify-content-end">
                <li className="nav-item">
                  <a href="../Lists/ProjectsList/NewForm.aspx" className="nav-link active" role="button" aria-pressed="true">
                    {strings.NavitemCreateNewProject}
                  </a>
                </li>
                <li className="nav-item">
                  <a href="../Lists/ProjectsList" className="nav-link active" role="button" aria-pressed="true">
                    {strings.NavitemProjectsList}
                  </a>
                </li>
              </ul>
            </nav>
          </div>
          <div className="row row-cols-1  row-cols-lg-5">

          <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsOtherDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsOtherDocsLibrary} </a>
                </p>
              </div>
            </div>

            <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsIDCard' className="btn btn-collapse">{strings.LibraryNameProjectsIDCardsDocsLibrary} </a>
                </p>
              </div>
            </div>


          <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsCOPILDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsCOPILDocsLibrary} </a>
                </p>
              </div>
            </div>       

            <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsCOMITDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsCOMITDocsLibrary} </a>
                </p>
              </div>
            </div>

            <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsSVCDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsSVCDocsLibrary} </a>
                </p>
              </div>
            </div>


        
         </div>


          <div className="row row-cols-1  row-cols-lg-5">
          <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsCMATDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsCMATDocsLibrary} </a>
                </p>
              </div>
            </div>

          <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsCvitDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsCvitDocsLibrary} </a>
                </p>
              </div>
            </div>

          <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsC2IDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsC2IDocsLibrary} </a>
                </p>
              </div>
            </div>

            <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsIRPPDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsIRPPDocsLibrary} </a>
                </p>
              </div>
            </div>

            <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsDemandsDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsDemandsDocsLibrary} </a>
                </p>
              </div>
            </div>

      



          </div>


          <div className="row row-cols-1  row-cols-lg-5">
          <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsSpecificationsDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsSpecificationsDocsLibrary} </a>
                </p>
              </div>
            </div>
            
          <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsReleaseNotesDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsReleaseNotesDocsLibrary} </a>
                </p>
              </div>
            </div>
            
          <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsTestsBookDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsTestsBookDocsLibrary} </a>
                </p>
              </div>
            </div>
            <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsMinutesOfMeetingDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsMinutesOfMeetingDocsLibrary} </a>
                </p>
              </div>
            </div>

            <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsDeliveryCardsDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsDeliveryCardsDocsLibrary} </a>
                </p>
              </div>
            </div>

        


          </div>

          
          <div className="row row-cols-1  row-cols-lg-5">
          <div className="col mb-5 mb-lg-0 ">
              <div className="card h-50">
                <img className="card-img blur-up x-hidden-focus" alt=""
                  src="/sites/docsdsi/Style%20Library/DocsDSI/Commun/images/folder-green.png"></img>
                <p className="mb-0 pb-3 pt-2 text-center depth-16">
                  <a href='../ProjectsBalanceSheetDocsLibrary' className="btn btn-collapse">{strings.LibraryNameProjectsBalanceSheetDocsLibrary} </a>
                </p>
              </div>
            </div>
          </div>



        </div>
      </div>
    );
  }
}

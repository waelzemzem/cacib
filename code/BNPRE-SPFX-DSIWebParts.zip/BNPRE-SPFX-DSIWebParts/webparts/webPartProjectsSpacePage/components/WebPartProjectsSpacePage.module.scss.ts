/* tslint:disable */
require('./WebPartProjectsSpacePage.module.css');
const styles = {
  webPartProjectsSpacePage: 'webPartProjectsSpacePage_8ca37c9c',
  container: 'container_8ca37c9c',
  row: 'row_8ca37c9c',
  column: 'column_8ca37c9c',
  'ms-Grid': 'ms-Grid_8ca37c9c',
  title: 'title_8ca37c9c',
  subTitle: 'subTitle_8ca37c9c',
  description: 'description_8ca37c9c',
  button: 'button_8ca37c9c',
  label: 'label_8ca37c9c',
};

export default styles;
/* tslint:enable */
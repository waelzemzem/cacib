export interface IWebPartProjectsSpacePageProps {
  description: string;
}
